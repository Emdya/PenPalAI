"use client"

import { useSession } from "next-auth/react"
import { useMockSession } from "@/components/mock-session-provider"

export function useAuth() {
  // Try to use the real session first
  const nextAuthSession = useSession()

  // Fall back to the mock session if needed
  const mockSession = useMockSession()

  // In development, prefer the mock session
  if (process.env.NODE_ENV === "development") {
    return mockSession
  }

  return nextAuthSession
}
