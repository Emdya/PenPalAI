import type { Metadata } from "next"
import { DbInitializer } from "@/components/db-initializer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ApiKeySetup } from "@/components/setup/api-key-setup"
import { StorageSetup } from "@/components/setup/storage-setup"
import { DatabaseSetup } from "@/components/setup/database-setup"

export const metadata: Metadata = {
  title: "Setup | PenPal AI",
  description: "Set up your PenPal AI application",
}

export default function SetupPage() {
  return (
    <div className="container mx-auto py-10">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold">PenPal AI Setup</h1>
          <p className="text-muted-foreground mt-2">
            Complete the following steps to set up your PenPal AI application
          </p>
        </div>

        <Tabs defaultValue="database" className="space-y-6">
          <TabsList className="grid grid-cols-3 w-full">
            <TabsTrigger value="database">Database</TabsTrigger>
            <TabsTrigger value="api-keys">API Keys</TabsTrigger>
            <TabsTrigger value="storage">Storage</TabsTrigger>
          </TabsList>

          <TabsContent value="database" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Database Setup</CardTitle>
                <CardDescription>Initialize your database schema and check connection</CardDescription>
              </CardHeader>
              <CardContent>
                <DatabaseSetup />
                <div className="mt-6">
                  <DbInitializer />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="api-keys" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>API Keys</CardTitle>
                <CardDescription>Configure the necessary API keys for AI features</CardDescription>
              </CardHeader>
              <CardContent>
                <ApiKeySetup />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="storage" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Storage Setup</CardTitle>
                <CardDescription>Configure storage for book covers and user uploads</CardDescription>
              </CardHeader>
              <CardContent>
                <StorageSetup />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
