"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, XCircle, AlertCircle, RefreshCw } from "lucide-react"

export default function TestOpenAI() {
  const [result, setResult] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const testConnection = async () => {
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/test-openai")
      const data = await response.json()
      setResult(data)
    } catch (err) {
      setError("Failed to test OpenAI connection")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    testConnection()
  }, [])

  return (
    <div className="container max-w-3xl py-10">
      <Card>
        <CardHeader>
          <CardTitle>OpenAI Connection Test</CardTitle>
          <CardDescription>
            This page tests your OpenAI API connection and displays environment variables
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center p-6">
              <RefreshCw className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : error ? (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ) : result ? (
            <div className="space-y-4">
              <Alert variant={result.success ? "default" : "destructive"}>
                {result.success ? <CheckCircle className="h-4 w-4 text-green-500" /> : <XCircle className="h-4 w-4" />}
                <AlertTitle>{result.success ? "Success" : "Failed"}</AlertTitle>
                <AlertDescription>{result.message}</AlertDescription>
              </Alert>

              {result.response && (
                <div className="rounded-md bg-muted p-4">
                  <p className="font-mono text-sm">{result.response}</p>
                </div>
              )}

              <div className="rounded-md border p-4">
                <h3 className="font-medium mb-2">Environment Variables</h3>
                <div className="space-y-2">
                  {Object.entries(result.env).map(([key, value]: [string, any]) => (
                    <div key={key} className="flex justify-between">
                      <span className="font-mono text-sm">{key}</span>
                      <span className="font-mono text-sm">{String(value)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : null}
        </CardContent>
        <CardFooter>
          <Button onClick={testConnection} disabled={loading}>
            {loading ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : null}
            Test Connection Again
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
