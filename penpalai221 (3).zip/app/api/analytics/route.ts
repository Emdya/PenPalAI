import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { getBooksByUserId, getWritingStatsByUserId } from "@/lib/db"

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userId = session.user.id

    // Get user's books
    const books = await getBooksByUserId(userId)

    // Get writing stats for the last 90 days
    const writingStats = await getWritingStatsByUserId(userId, 90)

    // Calculate total books and drafts
    const totalBooks = books.length
    const completedBooks = books.filter((book) => book.status === "completed").length
    const draftBooks = totalBooks - completedBooks

    // Calculate total words
    const totalWords = books.reduce((sum, book) => sum + (book.wordCount || 0), 0)

    // Calculate streaks
    const writingDays = new Set(writingStats.map((stat) => stat.date.toISOString().split("T")[0]))
    const sortedDays = Array.from(writingDays).sort()

    let currentStreak = 0
    let longestStreak = 0
    let currentStreakCount = 0

    // Calculate current streak
    const today = new Date().toISOString().split("T")[0]
    const yesterday = new Date(Date.now() - 86400000).toISOString().split("T")[0]

    // Check if wrote today or yesterday to maintain streak
    const wroteRecently = writingDays.has(today) || writingDays.has(yesterday)

    if (sortedDays.length > 0 && wroteRecently) {
      // Start counting from the most recent day
      let currentDate = new Date(sortedDays[sortedDays.length - 1])
      currentStreakCount = 1

      // Go backwards through days
      for (let i = sortedDays.length - 2; i >= 0; i--) {
        const prevDate = new Date(sortedDays[i])
        const diffDays = Math.round((currentDate.getTime() - prevDate.getTime()) / 86400000)

        if (diffDays === 1) {
          // Consecutive day
          currentStreakCount++
          currentDate = prevDate
        } else {
          break
        }
      }

      currentStreak = currentStreakCount
    }

    // Calculate longest streak
    let tempStreak = 1
    for (let i = 1; i < sortedDays.length; i++) {
      const currentDate = new Date(sortedDays[i])
      const prevDate = new Date(sortedDays[i - 1])
      const diffDays = Math.round((currentDate.getTime() - prevDate.getTime()) / 86400000)

      if (diffDays === 1) {
        tempStreak++
      } else {
        if (tempStreak > longestStreak) {
          longestStreak = tempStreak
        }
        tempStreak = 1
      }
    }

    // Check if the last streak is the longest
    if (tempStreak > longestStreak) {
      longestStreak = tempStreak
    }

    // Calculate total writing time (in minutes)
    const totalWritingTime = writingStats.reduce((sum, stat) => sum + (stat.timeSpent || 0), 0)

    // Calculate average words per day (only on days with writing)
    const totalWritingDays = writingDays.size
    const averageWordsPerDay =
      totalWritingDays > 0
        ? Math.round(writingStats.reduce((sum, stat) => sum + (stat.wordCount || 0), 0) / totalWritingDays)
        : 0

    return NextResponse.json({
      totalBooks,
      draftBooks,
      completedBooks,
      totalWords,
      currentStreak,
      longestStreak,
      totalWritingDays,
      averageWordsPerDay,
      totalWritingTime,
    })
  } catch (error) {
    console.error("Error fetching analytics:", error)
    return NextResponse.json({ error: "Failed to fetch analytics data" }, { status: 500 })
  }
}
