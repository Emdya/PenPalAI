import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { sql } from "@/lib/db"
import { randomBytes, timingSafeEqual, scrypt } from "crypto"
import { promisify } from "util"

// Promisify scrypt
const scryptAsync = promisify(scrypt)

// Function to hash password using Node.js built-in crypto
async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex")
  const buf = (await scryptAsync(password, salt, 64)) as Buffer
  return `${buf.toString("hex")}.${salt}`
}

// Function to verify password
async function verifyPassword(storedPassword: string, suppliedPassword: string): Promise<boolean> {
  const [hashedPassword, salt] = storedPassword.split(".")
  const hashedPasswordBuf = Buffer.from(hashedPassword, "hex")
  const suppliedPasswordBuf = (await scryptAsync(suppliedPassword, salt, 64)) as Buffer
  return timingSafeEqual(hashedPasswordBuf, suppliedPasswordBuf)
}

export async function POST(req: NextRequest) {
  try {
    // Check if we're in a browser environment
    if (typeof window !== "undefined") {
      return NextResponse.json({ success: true, message: "Mock success in browser environment" }, { status: 200 })
    }

    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { currentPassword, newPassword } = await req.json()

    if (!currentPassword || !newPassword) {
      return NextResponse.json({ message: "Current password and new password are required" }, { status: 400 })
    }

    // Get the user from the database
    const user = await sql`
      SELECT id, password
      FROM "User"
      WHERE id = ${session.user.id}
    `

    if (!user || user.length === 0) {
      return NextResponse.json({ message: "User not found" }, { status: 404 })
    }

    // Verify the current password
    const isPasswordValid = await verifyPassword(user[0].password, currentPassword)

    if (!isPasswordValid) {
      return NextResponse.json({ message: "Current password is incorrect" }, { status: 400 })
    }

    // Hash the new password
    const hashedPassword = await hashPassword(newPassword)

    // Update the password in the database
    await sql`
      UPDATE "User"
      SET password = ${hashedPassword}, "updatedAt" = CURRENT_TIMESTAMP
      WHERE id = ${session.user.id}
    `

    return NextResponse.json({ success: true, message: "Password updated successfully" }, { status: 200 })
  } catch (error) {
    console.error("Error updating password:", error)
    return NextResponse.json({ message: "Failed to update password" }, { status: 500 })
  }
}
