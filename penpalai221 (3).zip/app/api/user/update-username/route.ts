import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { sql } from "@/lib/db"

export async function POST(req: NextRequest) {
  try {
    // Check if we're in a browser environment
    if (typeof window !== "undefined") {
      return NextResponse.json({ success: true, message: "Mock success in browser environment" }, { status: 200 })
    }

    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { username } = await req.json()

    if (!username || username.trim() === "") {
      return NextResponse.json({ message: "Username cannot be empty" }, { status: 400 })
    }

    // Update the username in the database
    await sql`
      UPDATE "User"
      SET name = ${username}, "updatedAt" = CURRENT_TIMESTAMP
      WHERE id = ${session.user.id}
    `

    return NextResponse.json({ success: true, message: "Username updated successfully" }, { status: 200 })
  } catch (error) {
    console.error("Error updating username:", error)
    return NextResponse.json({ message: "Failed to update username" }, { status: 500 })
  }
}
