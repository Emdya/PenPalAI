import { NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function GET() {
  try {
    // Check if we're in a browser environment
    if (typeof window !== "undefined") {
      return NextResponse.json({
        success: true,
        message: "Mock database schema check in browser environment",
        tables: ["User", "Book", "Chapter", "Scene", "WritingStat", "BookCover", "Achievement", "UserAchievement"],
      })
    }

    // Check if the User table exists
    const userTableCheck = await sql`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public'
        AND table_name = 'User'
      );
    `

    const userTableExists = userTableCheck[0]?.exists || false

    // If the User table doesn't exist, we need to initialize the schema
    if (!userTableExists) {
      return NextResponse.json({
        success: false,
        message: "Database schema not initialized",
        needsInitialization: true,
      })
    }

    // Check all required tables
    const tables = ["User", "Book", "Chapter", "Scene", "WritingStat", "BookCover", "Achievement", "UserAchievement"]
    const tableChecks = await Promise.all(
      tables.map(async (table) => {
        const result = await sql`
          SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_schema = 'public'
            AND table_name = ${table}
          );
        `
        return { table, exists: result[0]?.exists || false }
      }),
    )

    const missingTables = tableChecks.filter((check) => !check.exists).map((check) => check.table)

    if (missingTables.length > 0) {
      return NextResponse.json({
        success: false,
        message: "Some tables are missing from the database schema",
        missingTables,
        needsInitialization: true,
      })
    }

    return NextResponse.json({
      success: true,
      message: "Database schema is properly initialized",
      tables: tables.filter((table) => tableChecks.find((check) => check.table === table)?.exists),
    })
  } catch (error) {
    console.error("Error checking database schema:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to check database schema",
        error: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
