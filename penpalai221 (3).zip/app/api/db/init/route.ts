import { NextResponse } from "next/server"
import { sql } from "@/lib/db"
import fs from "fs"
import path from "path"

// This endpoint should be secured in production
export async function GET() {
  try {
    // Read the SQL file
    const schemaPath = path.join(process.cwd(), "db-schema.sql")
    const schema = fs.readFileSync(schemaPath, "utf8")

    // Execute the SQL
    await sql.query(schema)

    return NextResponse.json({
      success: true,
      message: "Database initialized successfully",
    })
  } catch (error) {
    console.error("Error initializing database:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to initialize database",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
