import { NextResponse } from "next/server"
import { OpenAI } from "openai"

// Initialize OpenAI client directly
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function POST(req: Request) {
  try {
    console.log("AI Chat API called with OpenAI key:", !!process.env.OPENAI_API_KEY)

    // Extract the messages from the request
    let messages
    try {
      const body = await req.json()
      messages = body.messages

      if (!messages || !Array.isArray(messages)) {
        return NextResponse.json({ error: "Invalid messages format" }, { status: 400 })
      }
    } catch (parseError) {
      console.error("Error parsing request body:", parseError)
      return NextResponse.json({ error: "Invalid JSON in request body" }, { status: 400 })
    }

    // Prepare system prompt
    const systemPrompt =
      "You are an AI writing assistant for authors using PenPal AI, a book writing and publishing platform. Your goal is to help authors improve their writing, develop their stories, and overcome creative blocks. Provide thoughtful, specific, and constructive feedback."

    // Format messages for OpenAI
    const formattedMessages = [
      { role: "system", content: systemPrompt },
      ...messages.filter((m) => m.role !== "system"),
    ]

    console.log("Calling OpenAI with messages:", JSON.stringify(formattedMessages))

    // Call OpenAI directly
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: formattedMessages.map((m) => ({
        role: m.role,
        content: m.content,
      })),
    })

    const content = completion.choices[0]?.message?.content || "I couldn't generate a response. Please try again."

    console.log("OpenAI response received:", content.substring(0, 50) + "...")

    return NextResponse.json({
      role: "assistant",
      content: content,
      provider: "openai",
    })
  } catch (error) {
    console.error("Error in AI chat:", error)

    // Check if it's a rate limit error
    const errorMessage = error instanceof Error ? error.message : "Unknown error"
    if (errorMessage.includes("429") || errorMessage.includes("quota")) {
      return NextResponse.json(
        {
          role: "assistant",
          content: "I've reached my usage limit. Please try again later or check your OpenAI API quota.",
          provider: "error",
        },
        { status: 429 },
      )
    }

    return NextResponse.json({
      role: "assistant",
      content: "I'm having trouble connecting to my AI services. Please try again later.",
      provider: "error",
    })
  }
}
