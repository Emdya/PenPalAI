import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"

// Mock outline for preview environment
const MOCK_OUTLINE = `# The Lost Kingdom - Fantasy Novel Outline

## Chapter 1: The Discovery
- Sarah discovers an ancient artifact buried beneath an old oak tree
- First connection with the artifact's mysterious energy
- Introduction to Sarah's grandmother and her secluded house
- Foreshadowing of being watched by unknown entities

## Chapter 2: Family Secrets
- Grandmother reveals partial knowledge of the artifact
- Sarah learns about her family's connection to ancient guardians
- First encounter with antagonistic forces
- Decision to seek more information from a scholar

## Chapter 3: The Scholar
- Meeting with Professor Harlow at the university
- Translation of the artifact's engravings
- Discovery of the artifact's purpose as a key to a hidden realm
- Realization of the danger Sarah is now in

## Chapter 4: Pursuit
- Antagonists attack Sarah and the professor
- Narrow escape using the artifact's power for the first time
- Journey to find the hidden temple mentioned in the engravings
- Meeting a mysterious ally who offers guidance

## Chapter 5: The Temple
- Arrival at the ancient temple deep in the forest
- Solving puzzles to gain entry
- Discovery of a portal to the lost kingdom
- Climactic confrontation with the main antagonist
- Cliffhanger as Sarah is pulled through the portal

## Chapter 6: The Lost Kingdom
- Sarah awakens in a strange, beautiful realm
- Meeting the inhabitants who have been waiting for "the guardian"
- Learning about the kingdom's history and its connection to our world
- Understanding her destiny as the new guardian of the realm

## Chapter 7: Return and Resolution
- Sarah must make a choice between worlds
- Final battle with antagonists who followed her through the portal
- Resolution of family legacy
- Sarah's decision and its consequences
- Epilogue showing the new balance between worlds`

// Helper function to check if we're in a browser environment
function isBrowser() {
  return (
    typeof window !== "undefined" ||
    typeof process === "undefined" ||
    process.env.NEXT_RUNTIME === "edge" ||
    !process.env.OPENAI_API_KEY
  )
}

// Separate implementation for preview environments
async function handlePreviewRequest(title: string) {
  // Customize the mock outline with the provided title
  const customizedOutline = MOCK_OUTLINE.replace("The Lost Kingdom", title)
  return NextResponse.json({ outline: customizedOutline })
}

// Production implementation that uses the AI SDK
async function handleProductionRequest(title: string, genre: string) {
  try {
    // Dynamically import AI SDK only in production
    const { generateText } = await import("ai")
    const { openai } = await import("@ai-sdk/openai")

    const systemPrompt = `You are an expert book outliner. Based on the provided title and genre, create a detailed chapter outline for a book.
    For each chapter:
    1. Provide a compelling chapter title
    2. Write a brief summary of the chapter's main events
    3. List 3-5 key plot points or scenes that should occur in the chapter
    4. Note any character development or important revelations
    
    The outline should follow a satisfying narrative arc appropriate for the genre, with proper pacing, rising action, climax, and resolution.
    Format your response as a structured outline with chapter numbers, titles, and bullet points for key elements.`

    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: `Title: ${title}\nGenre: ${genre}\n\nPlease create a detailed chapter outline for this book.`,
    })

    return NextResponse.json({ outline: text })
  } catch (error) {
    console.error("Error generating chapter outline:", error)
    // Fallback to mock response if OpenAI API fails
    return handlePreviewRequest(title)
  }
}

export async function POST(request: Request) {
  try {
    // Check if we're in a browser environment first
    if (isBrowser()) {
      console.log("Browser environment detected, using mock data")
      return handlePreviewRequest("Your Book")
    }

    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    let title, genre
    try {
      const body = await request.json()
      title = body.title
      genre = body.genre
    } catch (error) {
      console.error("Error parsing request body:", error)
      return NextResponse.json(
        {
          error: "Invalid request body",
          outline: MOCK_OUTLINE,
        },
        { status: 400 },
      )
    }

    if (!title || !genre) {
      return NextResponse.json(
        {
          error: "Title and genre are required",
          outline: MOCK_OUTLINE,
        },
        { status: 400 },
      )
    }

    // Check if we're in a preview environment or if OpenAI API key is missing
    const isPreview =
      !process.env.OPENAI_API_KEY || process.env.NODE_ENV === "development" || process.env.VERCEL_ENV === "preview"

    // Use different handlers for preview and production
    if (isPreview) {
      return handlePreviewRequest(title)
    } else {
      return handleProductionRequest(title, genre)
    }
  } catch (error) {
    console.error("Error generating chapter outline:", error)
    // Return mock outline with a generic title
    return NextResponse.json(
      {
        error: "Internal server error",
        outline: MOCK_OUTLINE.replace("The Lost Kingdom", "Your Book"),
      },
      { status: 500 },
    )
  }
}
