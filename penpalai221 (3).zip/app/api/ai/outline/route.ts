import { NextResponse } from "next/server"
import { generateChapterOutline } from "@/lib/ai-service"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { title, genre } = await request.json()

    if (!title || !genre) {
      return NextResponse.json({ error: "Title and genre are required" }, { status: 400 })
    }

    const result = await generateChapterOutline(title, genre)

    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 500 })
    }

    return NextResponse.json({ outline: result.outline })
  } catch (error) {
    console.error("Error generating chapter outline:", error)
    return NextResponse.json({ error: "Failed to generate chapter outline" }, { status: 500 })
  }
}
