import { NextResponse } from "next/server"
import { OpenAI } from "openai"

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function POST(request: Request) {
  try {
    const { title, author, genre, prompt } = await request.json()

    if (!title || !prompt) {
      return NextResponse.json({ error: "Title and prompt are required" }, { status: 400 })
    }

    // Create a detailed prompt for DALL-E
    const detailedPrompt = `Book cover for "${title}" by ${author}. Genre: ${genre}. ${prompt}. Professional book cover design, high quality, detailed illustration, publishing industry standard.`

    // Generate images using DALL-E
    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt: detailedPrompt,
      n: 1,
      size: "1024x1024",
    })

    // Extract image URLs
    const coverUrls = response.data.map((item) => item.url)

    // For demonstration, we'll duplicate the image to show multiple options
    // In a real implementation, you might want to generate multiple images with different prompts
    const allCovers = [...coverUrls]

    return NextResponse.json({
      covers: allCovers,
      message: "Cover images generated successfully",
    })
  } catch (error: any) {
    console.error("Error generating cover:", error)

    // Return a more helpful error message
    let errorMessage = "Failed to generate cover images"

    if (error.status === 429) {
      errorMessage = "API usage limit reached. Please try again later or contact support to upgrade your plan."
    }

    return NextResponse.json({ error: errorMessage }, { status: error.status === 429 ? 429 : 500 })
  }
}
