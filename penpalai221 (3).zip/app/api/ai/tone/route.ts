import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"

// Mock analysis response for preview environment
const MOCK_TONE_ANALYSIS = `# Tone Analysis

## Primary Emotional Tone
The text has a **mysterious and intriguing** tone. There's an element of wonder and discovery, with undertones of slight apprehension or caution.

## Level of Formality
The writing style is **somewhat casual** with a literary quality. It uses first-person narrative and natural dialogue that feels conversational while maintaining a polished storytelling approach.

## Tone Consistency
The tone is generally consistent throughout the passage, effectively maintaining the sense of mystery and discovery from beginning to end.

## Notable Elements
- Strong use of sensory details ("cold winter morning", "warm sensation")
- Effective balance between description and internal monologue
- Good establishment of intrigue through the artifact's mysterious properties
- Subtle foreshadowing creates tension ("feeling that she was being watched")

## Suggestions
To enhance the tone further, consider:
1. Adding more specific emotional reactions from Sarah to deepen the reader's connection
2. Expanding slightly on the whispers she hears to increase the mystical quality
3. Maintaining this tone as the story progresses to keep readers engaged in the mystery`

// Separate implementation for preview environments
async function handlePreviewRequest() {
  return NextResponse.json({ analysis: MOCK_TONE_ANALYSIS })
}

// Production implementation that uses the AI SDK
async function handleProductionRequest(content: string) {
  try {
    // Use dynamic import to avoid browser issues
    const { generateText } = await import("ai")
    const { openai } = await import("@ai-sdk/openai")

    const systemPrompt = `You are a tone analysis expert. Analyze the provided text and identify:
    1. The primary emotional tone (e.g., melancholic, joyful, tense, mysterious)
    2. The level of formality (very formal, somewhat formal, casual, very casual)
    3. The consistency of tone throughout the passage
    4. Any shifts in tone that might be jarring to readers
    5. Suggestions for maintaining a more consistent tone if needed
    
    Format your response in clear sections with headings. Be specific and provide examples from the text.`

    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: content,
    })

    return NextResponse.json({ analysis: text })
  } catch (error) {
    console.error("Error analyzing tone:", error)
    // Fallback to mock response if OpenAI API fails
    return handlePreviewRequest()
  }
}

export async function POST(request: Request) {
  try {
    // Always check if we're in a browser-like environment first
    const isBrowser = typeof window !== "undefined"
    if (isBrowser) {
      return handlePreviewRequest()
    }

    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    let content
    try {
      const body = await request.json()
      content = body.content
    } catch (e) {
      console.error("Error parsing request body:", e)
      return NextResponse.json({ error: "Invalid request body" }, { status: 400 })
    }

    if (!content || typeof content !== "string") {
      return NextResponse.json({ error: "Content is required" }, { status: 400 })
    }

    // Check if we're in a preview environment or if OpenAI API key is missing
    const isPreview =
      !process.env.OPENAI_API_KEY || process.env.NODE_ENV === "development" || process.env.VERCEL_ENV === "preview"

    // Use different handlers for preview and production
    if (isPreview) {
      return handlePreviewRequest()
    } else {
      // Limit content length to prevent token overflow
      const truncatedContent = content.slice(0, 8000)
      return handleProductionRequest(truncatedContent)
    }
  } catch (error) {
    console.error("Error in tone analysis route:", error)
    // Always return a valid JSON response, even in case of errors
    return NextResponse.json(
      {
        error: "An error occurred during tone analysis",
        analysis: MOCK_TONE_ANALYSIS,
      },
      { status: 500 },
    )
  }
}
