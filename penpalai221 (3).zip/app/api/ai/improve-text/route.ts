import { NextResponse } from "next/server"
import OpenAI from "openai"

// Initialize OpenAI client
let openaiClient: OpenAI | null = null
try {
  if (process.env.OPENAI_API_KEY) {
    openaiClient = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    })
  }
} catch (error) {
  console.error("Failed to initialize OpenAI client:", error)
}

export async function POST(req: Request) {
  try {
    const { originalText, suggestion } = await req.json()

    if (!originalText || originalText.trim().length === 0) {
      return NextResponse.json({ error: "No text provided to improve" }, { status: 400 })
    }

    if (!suggestion || suggestion.trim().length === 0) {
      return NextResponse.json({ error: "No suggestion provided for improvement" }, { status: 400 })
    }

    // System prompt for text improvement
    const systemPrompt = `You are an expert writing coach and editor. Your task is to improve the provided text based on a specific suggestion.
Follow these guidelines:
1. Maintain the original meaning and intent of the text
2. Preserve the author's unique voice and style
3. Implement the specific suggestion to improve the text
4. Keep the length similar to the original text unless the suggestion requires expansion
5. Focus on making the text more engaging, clear, and impactful

Respond ONLY with the improved text, without any explanations, comments, or formatting.`

    // Try to use OpenAI directly for more advanced analysis if available
    if (openaiClient) {
      try {
        const response = await openaiClient.chat.completions.create({
          model: "gpt-4o",
          messages: [
            { role: "system", content: systemPrompt },
            {
              role: "user",
              content: `Original text: "${originalText}"
              
Suggestion for improvement: "${suggestion}"

Please provide an improved version of the text that implements this suggestion.`,
            },
          ],
          temperature: 0.7,
        })

        const improvedText = response.choices[0]?.message?.content || ""

        return NextResponse.json({ improvedText })
      } catch (openaiError) {
        console.error("Error using OpenAI for text improvement:", openaiError)
        // Fall back to mock response
      }
    }

    // Mock improved text if OpenAI is not available
    const improvedText = getMockImprovedText(originalText, suggestion)

    return NextResponse.json({ improvedText })
  } catch (error) {
    console.error("Error improving text:", error)
    return NextResponse.json({ error: "Failed to improve text" }, { status: 500 })
  }
}

// Generate mock improved text based on the original text and suggestion
function getMockImprovedText(originalText: string, suggestion: string): string {
  // Simple mock implementation - in a real scenario, this would be more sophisticated
  if (suggestion.toLowerCase().includes("sensory")) {
    return originalText.replace(
      "The small, metallic object seemed to pulse with an energy that defied explanation.",
      "The small, metallic object seemed to pulse with an energy that defied explanation, its surface cool against her fingertips yet somehow radiating warmth. Intricate engravings caught the light, shifting like liquid silver as she turned it in her palm.",
    )
  } else if (suggestion.toLowerCase().includes("character") || suggestion.toLowerCase().includes("emotion")) {
    return originalText.replace(
      'What are you?" she murmured, turning the artifact over to examine its intricate engravings.',
      "What are you?\" she murmured, turning the artifact over to examine its intricate engravings. Sarah's heart raced with a mixture of scholarly excitement and primal fear, emotions she'd never experienced simultaneously before. Her fingers trembled slightly as they traced the unfamiliar symbols, her academic mind already cataloging similarities to ancient scripts she'd studied.",
    )
  } else if (suggestion.toLowerCase().includes("dream") || suggestion.toLowerCase().includes("timeline")) {
    return originalText.replace(
      "Sarah had been digging there on a whim, guided by a recurring dream that had plagued her for weeks.",
      "Sarah had been digging there on a whim, guided by a recurring dream that had plagued her for the past three months, intensifying with each passing night until she could no longer ignore its pull.",
    )
  } else {
    // Generic improvement
    return (
      originalText +
      " " +
      (originalText.endsWith(".") ? "" : ".") +
      " The significance of this moment wasn't lost on her, though she couldn't possibly comprehend how this discovery would transform everything she thought she knew about her family's legacy."
    )
  }
}
