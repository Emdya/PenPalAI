import { getMockChatResponse } from "@/lib/ai-service"

export async function POST(req: Request) {
  // Create a TransformStream to handle streaming
  const encoder = new TextEncoder()
  const stream = new TransformStream()
  const writer = stream.writable.getWriter()

  // Helper function to write to the stream
  const writeToStream = async (data: any) => {
    try {
      await writer.write(encoder.encode(`data: ${JSON.stringify(data)}\n\n`))
    } catch (error) {
      console.error("Error writing to stream:", error)
    }
  }

  try {
    // Extract the messages from the request
    let messages
    try {
      const body = await req.json()
      messages = body.messages

      if (!messages || !Array.isArray(messages)) {
        await writeToStream({ type: "error", error: "Invalid messages format" })
        await writer.close()
        return new Response(stream.readable, {
          headers: {
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            Connection: "keep-alive",
          },
        })
      }
    } catch (parseError) {
      console.error("Error parsing request body:", parseError)
      await writeToStream({ type: "error", error: "Invalid JSON in request body" })
      await writer.close()
      return new Response(stream.readable, {
        headers: {
          "Content-Type": "text/event-stream",
          "Cache-Control": "no-cache",
          Connection: "keep-alive",
        },
      })
    }

    // Always use mock responses in preview mode or development
    const useMockResponse = true // Simplified for reliability

    // Get the last user message
    const lastUserMessage = [...messages].reverse().find((m) => m.role === "user")
    if (!lastUserMessage) {
      await writeToStream({ type: "error", error: "No user message found" })
      await writer.close()
      return new Response(stream.readable, {
        headers: {
          "Content-Type": "text/event-stream",
          "Cache-Control": "no-cache",
          Connection: "keep-alive",
        },
      })
    }

    // Send metadata
    await writeToStream({ type: "metadata", provider: "mock" })

    // Get mock response and stream it word by word
    const mockResponse = getMockChatResponse(lastUserMessage.content)
    const words = mockResponse.split(" ")

    for (let i = 0; i < words.length; i++) {
      await new Promise((resolve) => setTimeout(resolve, 50))
      await writeToStream({ type: "text-delta", text: words[i] + " " })
    }

    await writeToStream({ type: "done" })
    await writer.close()

    return new Response(stream.readable, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    })
  } catch (error) {
    console.error("Error in stream API:", error)
    try {
      await writeToStream({ type: "error", error: "Internal server error" })
      await writer.close()
    } catch (e) {
      console.error("Error closing writer:", e)
    }
    return new Response(stream.readable, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
      status: 200, // Return 200 even on error, as we're handling it in the stream
    })
  }
}
