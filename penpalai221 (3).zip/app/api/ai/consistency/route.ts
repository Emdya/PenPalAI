import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"

// Mock consistency analysis for preview environment
const MOCK_CONSISTENCY_ANALYSIS = `# Consistency Analysis

## Overall Assessment
The text is generally consistent for the excerpt provided. There are no major inconsistencies in character descriptions, plot elements, or setting details.

## Character Consistency
**Sarah**: The character is consistently portrayed as curious and drawn to the mysterious artifact. Her reactions remain consistent throughout the passage.

## Setting Consistency
The setting transitions from the oak tree where Sarah finds the artifact to her grandmother's house. The descriptions maintain consistency with the "old oak tree" and "grandmother's house" references.

## Plot Elements
The discovery of the artifact and Sarah's reaction to it are consistently described throughout the passage. The mysterious energy and whispers are mentioned early and reinforced later.

## Strengths
- Strong establishment of the artifact's mysterious properties
- Consistent characterization of Sarah as curious but cautious
- Clear sense of setting and movement between locations

## Recommendations
As you continue writing, maintain consistency by:
1. Keeping a record of the artifact's described properties
2. Tracking Sarah's knowledge about the artifact and her family history
3. Maintaining the established tone of mystery and subtle tension`

// Separate implementation for preview environments
async function handlePreviewRequest() {
  return NextResponse.json({ analysis: MOCK_CONSISTENCY_ANALYSIS })
}

// Production implementation that uses the AI SDK
async function handleProductionRequest(content: string) {
  try {
    // Dynamically import AI SDK only in production
    const { generateText } = await import("ai")
    const { openai } = await import("@ai-sdk/openai")

    const systemPrompt = `You are a literary consistency expert. Analyze the provided text and identify any inconsistencies in:
    1. Character descriptions, traits, or behaviors
    2. Plot elements and timeline
    3. Setting details and world-building elements
    4. Narrative voice and perspective
    
    For each inconsistency, provide:
    - A description of the inconsistency
    - The specific locations in the text where it occurs
    - A suggestion for how to resolve it
    
    If no inconsistencies are found, acknowledge the consistency of the text and highlight any particularly strong elements.
    Format your response in clear sections with headings.`

    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: content,
    })

    return NextResponse.json({ analysis: text })
  } catch (error) {
    console.error("Error checking consistency:", error)
    // Fallback to mock response if OpenAI API fails
    return handlePreviewRequest()
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { content } = await request.json()

    if (!content || typeof content !== "string") {
      return NextResponse.json({ error: "Content is required" }, { status: 400 })
    }

    // Check if we're in a preview environment or if OpenAI API key is missing
    const isPreview =
      !process.env.OPENAI_API_KEY || process.env.NODE_ENV === "development" || process.env.VERCEL_ENV === "preview"

    // Use different handlers for preview and production
    if (isPreview) {
      return handlePreviewRequest()
    } else {
      // Limit content length to prevent token overflow
      const truncatedContent = content.slice(0, 8000)
      return handleProductionRequest(truncatedContent)
    }
  } catch (error) {
    console.error("Error checking consistency:", error)
    return handlePreviewRequest()
  }
}
