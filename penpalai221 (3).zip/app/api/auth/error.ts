import { NextResponse } from "next/server"

export function GET(request: Request) {
  return NextResponse.json({ error: "Authentication error" }, { status: 400 })
}

export function POST(request: Request) {
  return NextResponse.json({ error: "Authentication error" }, { status: 400 })
}

export default function handler() {
  return NextResponse.json({ error: "Authentication error" }, { status: 400 })
}
