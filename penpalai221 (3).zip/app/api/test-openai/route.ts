import { NextResponse } from "next/server"
import { OpenAI } from "openai"

export async function GET() {
  try {
    // Check if OpenAI API key is set
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({
        success: false,
        message: "OpenAI API key is not set",
        env: {
          OPENAI_API_KEY: !!process.env.OPENAI_API_KEY,
          NEXT_PUBLIC_DEMO_MODE: process.env.NEXT_PUBLIC_DEMO_MODE,
          NEXT_PUBLIC_FORCE_PRODUCTION: process.env.NEXT_PUBLIC_FORCE_PRODUCTION,
        },
      })
    }

    // Initialize OpenAI client
    const openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    })

    // Make a simple test request
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: "You are a helpful assistant." },
        { role: "user", content: "Say 'OpenAI connection successful!'" },
      ],
    })

    return NextResponse.json({
      success: true,
      message: "OpenAI connection successful",
      response: completion.choices[0]?.message?.content,
      env: {
        OPENAI_API_KEY: !!process.env.OPENAI_API_KEY,
        NEXT_PUBLIC_DEMO_MODE: process.env.NEXT_PUBLIC_DEMO_MODE,
        NEXT_PUBLIC_FORCE_PRODUCTION: process.env.NEXT_PUBLIC_FORCE_PRODUCTION,
      },
    })
  } catch (error) {
    console.error("Error testing OpenAI connection:", error)
    return NextResponse.json({
      success: false,
      message: error instanceof Error ? error.message : "Unknown error",
      env: {
        OPENAI_API_KEY: !!process.env.OPENAI_API_KEY,
        NEXT_PUBLIC_DEMO_MODE: process.env.NEXT_PUBLIC_DEMO_MODE,
        NEXT_PUBLIC_FORCE_PRODUCTION: process.env.NEXT_PUBLIC_FORCE_PRODUCTION,
      },
    })
  }
}
