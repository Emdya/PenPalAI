import { NextResponse } from "next/server"

export async function GET() {
  // Create a safe version of the environment variables (hiding sensitive parts)
  const safeEnv = {
    OPENAI_API_KEY: process.env.OPENAI_API_KEY
      ? "Present (starts with: " + process.env.OPENAI_API_KEY.substring(0, 5) + "...)"
      : "Not set",
    NODE_ENV: process.env.NODE_ENV,
    VERCEL_ENV: process.env.VERCEL_ENV,
    NEXT_PUBLIC_DEMO_MODE: process.env.NEXT_PUBLIC_DEMO_MODE,
    NEXT_PUBLIC_FORCE_PRODUCTION: process.env.NEXT_PUBLIC_FORCE_PRODUCTION,
    DATABASE_URL: process.env.DATABASE_URL ? "Present" : "Not set",
  }

  return NextResponse.json({
    message: "Debug information",
    environment: safeEnv,
    timestamp: new Date().toISOString(),
  })
}
