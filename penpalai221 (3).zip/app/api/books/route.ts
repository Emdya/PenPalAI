import { NextResponse } from "next/server"
import { getBooksByUserId, createBook } from "@/lib/db"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { z } from "zod"

// Define validation schema
const bookSchema = z.object({
  title: z.string().min(1, "Title is required"),
  genre: z.string().nullable().optional(),
  description: z.string().nullable().optional(),
})

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const books = await getBooksByUserId(session.user.id)

    return NextResponse.json({ books })
  } catch (error) {
    console.error("Error fetching books:", error)
    return NextResponse.json({ error: "Failed to fetch books" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()

    // Validate input
    const result = bookSchema.safeParse(body)
    if (!result.success) {
      return NextResponse.json({ error: "Validation failed", details: result.error.format() }, { status: 400 })
    }

    const { title, genre, description } = result.data

    const book = await createBook({
      title,
      genre,
      description,
      userId: session.user.id,
    })

    return NextResponse.json({ book })
  } catch (error) {
    console.error("Error creating book:", error)
    return NextResponse.json({ error: "Failed to create book" }, { status: 500 })
  }
}
