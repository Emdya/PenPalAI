import { NextResponse } from "next/server"
import { checkDatabaseConnection } from "@/lib/db"

// Simple health check endpoint to verify the API and database are working
export async function GET() {
  try {
    // Check database connection
    const dbConnected = await checkDatabaseConnection()

    if (!dbConnected) {
      return NextResponse.json(
        {
          status: "error",
          message: "Database connection failed",
          timestamp: new Date().toISOString(),
        },
        { status: 500 },
      )
    }

    return NextResponse.json({
      status: "ok",
      database: "connected",
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Health check error:", error)
    return NextResponse.json(
      {
        status: "error",
        message: "Health check failed",
        error: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
