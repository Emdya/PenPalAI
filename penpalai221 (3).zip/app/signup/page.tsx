"use client"

import type React from "react"

import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Feather, Mail, Lock, User, BookOpen, Sparkles, ArrowRight, BookText, Bookmark, PenTool } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { motion } from "framer-motion"

export default function SignupPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // For demo purposes, we'll just simulate a successful signup
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Account created successfully!",
        description: "Welcome to PenPal AI. Let's start writing!",
      })

      // Redirect to dashboard
      router.push("/dashboard")
    } catch (error) {
      toast({
        title: "Error creating account",
        description: "Please try again later.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100,
      },
    },
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#4169E1] to-[#0f2137] flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-20 h-20 rounded-full bg-[#D4AF37]/10 backdrop-blur-sm"></div>
        <div className="absolute bottom-20 right-10 w-32 h-32 rounded-full bg-[#D4AF37]/10 backdrop-blur-sm"></div>
        <div className="absolute top-1/3 right-1/4 w-16 h-16 rounded-full bg-[#D4AF37]/20 backdrop-blur-sm"></div>

        {/* Floating book icons */}
        <motion.div
          className="absolute top-20 right-[20%]"
          animate={{
            y: [0, -10, 0],
            rotate: [0, 5, 0],
          }}
          transition={{
            duration: 4,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
        >
          <BookOpen className="h-12 w-12 text-[#D4AF37]/30" />
        </motion.div>

        <motion.div
          className="absolute bottom-[15%] left-[15%]"
          animate={{
            y: [0, 10, 0],
            rotate: [0, -5, 0],
          }}
          transition={{
            duration: 5,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
            delay: 1,
          }}
        >
          <BookText className="h-10 w-10 text-[#D4AF37]/30" />
        </motion.div>

        <motion.div
          className="absolute top-[40%] left-[10%]"
          animate={{
            y: [0, 8, 0],
            rotate: [0, 3, 0],
          }}
          transition={{
            duration: 3.5,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
            delay: 0.5,
          }}
        >
          <Bookmark className="h-8 w-8 text-[#D4AF37]/30" />
        </motion.div>

        <motion.div
          className="absolute top-[30%] right-[10%]"
          animate={{
            y: [0, 6, 0],
            rotate: [0, -4, 0],
          }}
          transition={{
            duration: 4.5,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
            delay: 1.5,
          }}
        >
          <PenTool className="h-9 w-9 text-[#D4AF37]/30" />
        </motion.div>
      </div>

      <div className="absolute top-8 left-8 z-10">
        <Link href="/" className="flex items-center gap-2 transition-transform hover:scale-105">
          <Feather className="h-6 w-6 text-[#D4AF37]" />
          <span className="text-xl font-bold text-white gatsby-heading">PenPal AI</span>
        </Link>
      </div>

      <motion.div className="w-full max-w-md z-10" variants={containerVariants} initial="hidden" animate="visible">
        <motion.div variants={itemVariants} className="mb-8 text-center">
          <div className="inline-block p-4 bg-[#D4AF37]/10 rounded-full mb-4 backdrop-blur-sm border border-[#D4AF37]/30">
            <BookOpen className="h-8 w-8 text-[#D4AF37]" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-white gatsby-heading">Join PenPal AI</h1>
          <p className="text-[#D4AF37]/80 mt-2 gatsby-text">Your AI-powered writing journey begins here</p>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="border-[#D4AF37]/20 shadow-lg bg-white/10 backdrop-blur-md">
            <CardHeader className="space-y-1 pb-4">
              <CardTitle className="text-xl text-white gatsby-heading">Create an account</CardTitle>
              <CardDescription className="text-[#D4AF37]/80">Enter your information to get started</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-white">
                    Full Name
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-2.5 h-4 w-4 text-[#D4AF37]" />
                    <Input
                      id="name"
                      placeholder="John Doe"
                      className="pl-10 bg-white/10 border-[#D4AF37]/30 text-white placeholder:text-white/50 focus:border-[#D4AF37]"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-white">
                    Email
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 h-4 w-4 text-[#D4AF37]" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="name@example.com"
                      className="pl-10 bg-white/10 border-[#D4AF37]/30 text-white placeholder:text-white/50 focus:border-[#D4AF37]"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-white">
                    Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 h-4 w-4 text-[#D4AF37]" />
                    <Input
                      id="password"
                      type="password"
                      className="pl-10 bg-white/10 border-[#D4AF37]/30 text-white focus:border-[#D4AF37]"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                  <p className="text-xs text-[#D4AF37]/60">Password must be at least 8 characters long</p>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="terms"
                    required
                    className="border-[#D4AF37]/50 data-[state=checked]:bg-[#D4AF37] data-[state=checked]:text-[#0f2137]"
                  />
                  <Label htmlFor="terms" className="text-sm font-normal text-white">
                    I agree to the{" "}
                    <Link href="#" className="text-[#D4AF37] hover:text-[#E5C158]">
                      terms of service
                    </Link>{" "}
                    and{" "}
                    <Link href="#" className="text-[#D4AF37] hover:text-[#E5C158]">
                      privacy policy
                    </Link>
                  </Label>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-[#D4AF37] text-[#0f2137] hover:bg-[#E5C158] font-medium"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <span className="flex items-center gap-2">
                      <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                      Creating account...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      Create account
                      <ArrowRight className="h-4 w-4" />
                    </span>
                  )}
                </Button>
              </form>

              <div className="mt-4 flex items-center gap-2">
                <Separator className="flex-1 bg-[#D4AF37]/30" />
                <span className="text-xs text-[#D4AF37]/80">OR</span>
                <Separator className="flex-1 bg-[#D4AF37]/30" />
              </div>

              <div className="mt-4">
                <Button variant="outline" className="w-full border-[#D4AF37]/30 text-white hover:bg-[#D4AF37]/20">
                  <Sparkles className="mr-2 h-4 w-4 text-[#D4AF37]" />
                  Continue with Magic Link
                </Button>
              </div>
            </CardContent>
            <CardFooter className="flex justify-center border-t border-[#D4AF37]/20 px-6 py-4">
              <div className="text-center text-sm text-white/80">
                Already have an account?{" "}
                <Link href="/login" className="font-medium text-[#D4AF37] hover:text-[#E5C158]">
                  Sign in
                </Link>
              </div>
            </CardFooter>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants} className="mt-8 flex justify-center gap-8">
          <div className="text-center">
            <div className="flex justify-center mb-2">
              <div className="rounded-full bg-[#D4AF37]/10 p-2 border border-[#D4AF37]/30">
                <Sparkles className="h-5 w-5 text-[#D4AF37]" />
              </div>
            </div>
            <h3 className="text-sm font-medium text-white">AI-Powered</h3>
            <p className="text-xs text-[#D4AF37]/80">Advanced writing assistance</p>
          </div>

          <div className="text-center">
            <div className="flex justify-center mb-2">
              <div className="rounded-full bg-[#D4AF37]/10 p-2 border border-[#D4AF37]/30">
                <BookOpen className="h-5 w-5 text-[#D4AF37]" />
              </div>
            </div>
            <h3 className="text-sm font-medium text-white">Publishing Tools</h3>
            <p className="text-xs text-[#D4AF37]/80">From draft to publication</p>
          </div>

          <div className="text-center">
            <div className="flex justify-center mb-2">
              <div className="rounded-full bg-[#D4AF37]/10 p-2 border border-[#D4AF37]/30">
                <User className="h-5 w-5 text-[#D4AF37]" />
              </div>
            </div>
            <h3 className="text-sm font-medium text-white">Collaboration</h3>
            <p className="text-xs text-[#D4AF37]/80">Work with others seamlessly</p>
          </div>
        </motion.div>
      </motion.div>
    </div>
  )
}
