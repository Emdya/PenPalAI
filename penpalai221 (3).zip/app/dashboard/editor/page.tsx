"use client"

import { useState } from "react"
import { EditorHeader } from "@/components/editor/editor-header"
import { EditorSidebar } from "@/components/editor/editor-sidebar"
import { EditorContent } from "@/components/editor/editor-content"
import { EditorAIPanel } from "@/components/editor/editor-ai-panel"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

export default function EditorPage() {
  const [error, setError] = useState<string | null>(null)

  // Function to handle errors
  const handleError = (message: string) => {
    setError(message)
  }

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] -m-6">
      {error && (
        <Alert variant="destructive" className="m-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      <EditorHeader />
      <div className="flex flex-1 overflow-hidden">
        <EditorSidebar />
        <EditorContent />
        <EditorAIPanel />
      </div>
    </div>
  )
}
