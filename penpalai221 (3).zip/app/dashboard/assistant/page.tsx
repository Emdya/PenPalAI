import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AIChat } from "@/components/editor/ai-chat"
import { ToneAnalyzer } from "@/components/editor/tone-analyzer"
import { ConsistencyChecker } from "@/components/editor/consistency-checker"
import { ChapterOutlineGenerator } from "@/components/editor/chapter-outline-generator"
import {
  GatsbyCard,
  GatsbyCardHeader,
  GatsbyCardTitle,
  GatsbyCardDescription,
  GatsbyCardContent,
} from "@/components/ui/gatsby-card"
import { GatsbyMusicPlayer } from "@/components/gatsby-music-player"

export default function AIAssistantPage() {
  return (
    <div className="container mx-auto p-4 md:p-8">
      <div className="mb-8 text-center">
        <h1 className="gatsby-heading text-4xl md:text-5xl font-bold mb-2 text-[#0f2137]">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-[#d4af37] to-[#b8860b]">
            AI Writing Assistant
          </span>
        </h1>
        <div className="gatsby-divider w-1/2 mx-auto"></div>
        <p className="gatsby-accent text-lg text-[#0f2137]/80 mt-4">
          Your personal writing companion for crafting the perfect story
        </p>
      </div>

      <Tabs defaultValue="chat" className="w-full">
        <TabsList className="w-full max-w-3xl mx-auto mb-6 bg-[#f8f0e3] border border-[#d4af37]/30">
          {[
            { id: "chat", label: "AI Chat" },
            { id: "tone", label: "Tone Analyzer" },
            { id: "consistency", label: "Consistency Checker" },
            { id: "outline", label: "Chapter Outline" },
          ].map((tab) => (
            <TabsTrigger
              key={tab.id}
              value={tab.id}
              className="gatsby-accent data-[state=active]:bg-[#d4af37] data-[state=active]:text-[#0a0a0a] transition-all duration-300"
            >
              {tab.label}
            </TabsTrigger>
          ))}
        </TabsList>

        <div className="max-w-4xl mx-auto">
          <TabsContent value="chat" className="mt-0">
            <GatsbyCard className="h-[600px]">
              <GatsbyCardHeader>
                <GatsbyCardTitle>Chat with Your Writing Assistant</GatsbyCardTitle>
                <GatsbyCardDescription>
                  Ask questions about your story, get feedback on your writing, or brainstorm ideas.
                </GatsbyCardDescription>
              </GatsbyCardHeader>
              <GatsbyCardContent className="h-[500px]">
                <AIChat />
              </GatsbyCardContent>
            </GatsbyCard>
          </TabsContent>

          <TabsContent value="tone" className="mt-0">
            <GatsbyCard>
              <GatsbyCardHeader>
                <GatsbyCardTitle>Analyze Your Writing Tone</GatsbyCardTitle>
                <GatsbyCardDescription>
                  Get insights into the emotional tone, formality level, and consistency of your writing.
                </GatsbyCardDescription>
              </GatsbyCardHeader>
              <GatsbyCardContent>
                <ToneAnalyzer />
              </GatsbyCardContent>
            </GatsbyCard>
          </TabsContent>

          <TabsContent value="consistency" className="mt-0">
            <GatsbyCard>
              <GatsbyCardHeader>
                <GatsbyCardTitle>Check for Inconsistencies</GatsbyCardTitle>
                <GatsbyCardDescription>
                  Identify inconsistencies in character descriptions, plot elements, settings, and narrative voice.
                </GatsbyCardDescription>
              </GatsbyCardHeader>
              <GatsbyCardContent>
                <ConsistencyChecker />
              </GatsbyCardContent>
            </GatsbyCard>
          </TabsContent>

          <TabsContent value="outline" className="mt-0">
            <GatsbyCard>
              <GatsbyCardHeader>
                <GatsbyCardTitle>Generate Chapter Outlines</GatsbyCardTitle>
                <GatsbyCardDescription>
                  Create detailed chapter outlines based on your book title and genre.
                </GatsbyCardDescription>
              </GatsbyCardHeader>
              <GatsbyCardContent>
                <ChapterOutlineGenerator />
              </GatsbyCardContent>
            </GatsbyCard>
          </TabsContent>
        </div>
      </Tabs>

      <GatsbyMusicPlayer />
    </div>
  )
}
