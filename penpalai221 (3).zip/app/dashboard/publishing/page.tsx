import type { Metadata } from "next"
import PublishingDashboard from "@/components/publishing/publishing-dashboard"

export const metadata: Metadata = {
  title: "Publishing | PenPal AI",
  description: "Prepare and publish your book to major platforms",
}

export default function PublishingPage() {
  return <PublishingDashboard />
}
