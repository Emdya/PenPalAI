import Link from "next/link"
import {
  GatsbyCard,
  GatsbyCardContent,
  GatsbyCardDescription,
  GatsbyCardFooter,
  GatsbyCardHeader,
  GatsbyCardTitle,
} from "@/components/ui/gatsby-card"
import { GatsbyButton } from "@/components/ui/gatsby-button"
import { GatsbyCorner, GatsbyOrnament } from "@/components/gatsby-decorative-elements"
import { IconFrame } from "@/components/ui/icon-frame"
import { BookOpen, PenTool, Sparkles, Users, FileText, BarChart } from "lucide-react"

export default function DashboardPage() {
  return (
    <div className="container mx-auto p-4 md:p-8">
      <div className="mb-8 text-center">
        <h1 className="gatsby-heading text-4xl md:text-5xl font-bold mb-2 text-[#0f2137] font-['Playfair_Display']">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-[#D4AF37] to-[#b8860b]">
            Welcome to PenPal AI
          </span>
        </h1>
        <GatsbyOrnament />
        <p className="gatsby-accent text-lg text-[#0f2137]/80 mt-4">
          Your personal writing companion for crafting the perfect story
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[
          {
            title: "My Projects",
            description: "Access your current writing projects and manuscripts",
            icon: BookOpen,
            href: "/dashboard/projects",
            shape: "default" as const,
          },
          {
            title: "AI Assistant",
            description: "Get help with writing, editing, and brainstorming",
            icon: Sparkles,
            href: "/dashboard/assistant",
            shape: "default" as const,
          },
          {
            title: "Editor",
            description: "Write and edit your manuscripts with powerful tools",
            icon: PenTool,
            href: "/dashboard/editor",
            shape: "default" as const,
          },
          {
            title: "Collaborators",
            description: "Manage your writing partners and collaborators",
            icon: Users,
            href: "/dashboard/collaborators",
            shape: "default" as const,
          },
          {
            title: "Publishing",
            description: "Prepare your work for publication and distribution",
            icon: FileText,
            href: "/dashboard/publishing",
            shape: "default" as const,
          },
          {
            title: "Analytics",
            description: "Track your writing progress and achievements",
            icon: BarChart,
            href: "/dashboard/analytics",
            shape: "default" as const,
          },
        ].map((item, index) => (
          <GatsbyCard key={index} className="relative overflow-hidden group border-[#D4AF37]/30 hover:border-[#D4AF37]">
            <GatsbyCorner position="top-left" />
            <GatsbyCorner position="bottom-right" />
            <GatsbyCardHeader>
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-[#D4AF37]/10 flex items-center justify-center">
                  <item.icon className="h-5 w-5 text-[#D4AF37]" />
                </div>
                <GatsbyCardTitle className="font-['Playfair_Display'] whitespace-nowrap">{item.title}</GatsbyCardTitle>
              </div>
              <GatsbyCardDescription className="font-['Lato']">{item.description}</GatsbyCardDescription>
            </GatsbyCardHeader>
            <GatsbyCardContent className="flex justify-center items-center">
              <IconFrame icon={item.icon} />
            </GatsbyCardContent>
            <GatsbyCardFooter className="justify-end">
              <Link href={item.href}>
                <GatsbyButton shape={item.shape} className="bg-[#D4AF37] text-[#0f2137] hover:bg-[#E5C158] font-medium">
                  Explore
                </GatsbyButton>
              </Link>
            </GatsbyCardFooter>
          </GatsbyCard>
        ))}
      </div>
    </div>
  )
}
