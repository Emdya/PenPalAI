import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { getBooksByUserId } from "@/lib/db"
import { RecentBooks } from "@/components/dashboard/recent-books"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"
import { redirect } from "next/navigation"
import { isBrowser, getMockServerSession } from "@/lib/mock-session"

// Mock books data for browser environments
const mockBooks = [
  {
    id: "mock-book-1",
    title: "The Great Adventure",
    description: "An epic journey through uncharted territories.",
    coverImage: "/placeholder.svg?height=200&width=150",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    userId: "mock-user-id",
    genre: "Adventure",
    wordCount: 45000,
  },
  {
    id: "mock-book-2",
    title: "Mystery at Midnight",
    description: "A thrilling mystery set in a small coastal town.",
    coverImage: "/placeholder.svg?height=200&width=150",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    userId: "mock-user-id",
    genre: "Mystery",
    wordCount: 62000,
  },
]

export default async function BooksPage() {
  // Use mock session in browser environments to avoid crypto errors
  const session = isBrowser() ? await getMockServerSession() : await getServerSession(authOptions)

  if (!session?.user) {
    // In browser preview, don't redirect
    if (isBrowser()) {
      console.log("Using mock session for preview")
    } else {
      redirect("/login")
    }
  }

  // Use mock books in browser environments
  const books = isBrowser() ? mockBooks : await getBooksByUserId(session.user.id)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">My Books</h2>
          <p className="text-muted-foreground">Manage your book projects and manuscripts.</p>
        </div>
        <Link href="/dashboard/books/new">
          <Button className="gap-1">
            <Plus className="h-4 w-4" />
            New Book
          </Button>
        </Link>
      </div>

      <RecentBooks books={books} />
    </div>
  )
}
