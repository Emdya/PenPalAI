"use client"
import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Upload, AlertCircle } from "lucide-react"
import { CoverGallery } from "@/components/covers/cover-gallery"
import { CoverGenerator } from "@/components/covers/cover-generator"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function CoversPage() {
  const [error, setError] = useState<string | null>(null)

  const handleError = (message: string) => {
    setError(message)
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">AI Cover Generator</h2>
        <p className="text-muted-foreground">Create beautiful book covers with AI or upload your own designs.</p>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="generate" className="space-y-4">
        <TabsList>
          <TabsTrigger value="generate">Generate with AI</TabsTrigger>
          <TabsTrigger value="upload">Upload Cover</TabsTrigger>
          <TabsTrigger value="gallery">My Covers</TabsTrigger>
        </TabsList>

        <TabsContent value="generate" className="space-y-4">
          <CoverGenerator />
        </TabsContent>

        <TabsContent value="upload">
          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                  <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground mb-2">
                    Drag and drop your cover image here, or click to browse
                  </p>
                  <Button variant="outline" size="sm">
                    Browse Files
                  </Button>
                  <p className="text-xs text-muted-foreground mt-2">
                    Recommended size: 1600 x 2400 pixels. Max file size: 5MB.
                  </p>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="upload-title">Book Title</Label>
                    <input id="upload-title" className="w-full p-2 border rounded" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="upload-author">Author Name</Label>
                    <input id="upload-author" className="w-full p-2 border rounded" />
                  </div>
                </div>
                <Button className="w-full">Save Cover</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="gallery">
          <CoverGallery />
        </TabsContent>
      </Tabs>
    </div>
  )
}
