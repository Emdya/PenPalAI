import type { Metadata } from "next"
import { SettingsPageContent } from "@/components/settings/settings-page-content"

export const metadata: Metadata = {
  title: "Settings | PenPal AI",
  description: "Manage your account settings and preferences",
}

export default function SettingsPage() {
  return <SettingsPageContent />
}
