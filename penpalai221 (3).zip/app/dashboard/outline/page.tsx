"use client"

import { useState } from "react"
import { ChapterOutlineGenerator } from "@/components/editor/chapter-outline-generator"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

export default function OutlinePage() {
  const [error, setError] = useState<string | null>(null)

  const handleError = (message: string) => {
    setError(message)
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Chapter Outline Generator</h2>
        <p className="text-muted-foreground">
          Generate detailed chapter outlines for your book based on genre and title.
        </p>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <ChapterOutlineGenerator />
    </div>
  )
}
