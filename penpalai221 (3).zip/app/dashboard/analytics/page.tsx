import { WritingStats } from "@/components/dashboard/writing-stats"
import { WritingStreak } from "@/components/dashboard/writing-streak"
import { AnalyticsDashboard } from "@/components/analytics/analytics-dashboard"
import { GatsbyOrnament } from "@/components/gatsby-decorative-elements"
import { ShootingStars } from "@/components/ui/shooting-stars"
import { FloatingBooks } from "@/components/ui/floating-books"

export default function AnalyticsPage() {
  return (
    <div className="container mx-auto p-4 md:p-8 relative">
      <ShootingStars />
      <FloatingBooks count={5} />

      <div className="mb-8 text-center">
        <h1 className="gatsby-heading text-4xl md:text-5xl font-bold mb-2 text-[#0f2137] font-['Playfair_Display']">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-[#D4AF37] to-[#b8860b]">
            Writing Analytics
          </span>
        </h1>
        <GatsbyOrnament />
        <p className="gatsby-accent text-lg text-[#0f2137]/80 mt-4">
          Track your writing journey and celebrate your progress
        </p>
      </div>

      <div className="space-y-8">
        <AnalyticsDashboard />
        <WritingStats />
        <WritingStreak />
      </div>
    </div>
  )
}
