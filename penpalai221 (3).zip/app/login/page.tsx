"use client"

import type React from "react"
import Link from "next/link"
import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Feather, Mail, Lock, ArrowRight, BookOpen, Sparkles, KeyRound, BookText, Bookmark } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { motion } from "framer-motion"

export default function LoginPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()

  useEffect(() => {
    // Check if redirected from signup
    const signupSuccess = searchParams?.get("signup") === "success"
    if (signupSuccess) {
      toast({
        title: "Account created!",
        description: "You can now log in with your credentials.",
      })
    }

    // Check for auth errors
    const errorType = searchParams?.get("error")
    if (errorType) {
      setError("Authentication failed. Please try again.")
    }
  }, [searchParams, toast])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    try {
      // For demo purposes, we'll just simulate a successful login
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Welcome back!",
        description: "You've successfully logged in.",
      })

      // Redirect to dashboard
      router.push("/dashboard")
    } catch (error) {
      setError("Login failed. Please check your credentials and try again.")
    } finally {
      setIsLoading(false)
    }
  }

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100,
      },
    },
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#4169E1] to-[#0f2137] flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-20 h-20 rounded-full bg-[#D4AF37]/10 backdrop-blur-sm"></div>
        <div className="absolute bottom-20 right-10 w-32 h-32 rounded-full bg-[#D4AF37]/10 backdrop-blur-sm"></div>
        <div className="absolute top-1/3 right-1/4 w-16 h-16 rounded-full bg-[#D4AF37]/20 backdrop-blur-sm"></div>

        {/* Floating book icons */}
        <motion.div
          className="absolute top-20 right-[20%]"
          animate={{
            y: [0, -10, 0],
            rotate: [0, 5, 0],
          }}
          transition={{
            duration: 4,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
        >
          <BookOpen className="h-12 w-12 text-[#D4AF37]/30" />
        </motion.div>

        <motion.div
          className="absolute bottom-[15%] left-[15%]"
          animate={{
            y: [0, 10, 0],
            rotate: [0, -5, 0],
          }}
          transition={{
            duration: 5,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
            delay: 1,
          }}
        >
          <BookText className="h-10 w-10 text-[#D4AF37]/30" />
        </motion.div>

        <motion.div
          className="absolute top-[40%] left-[10%]"
          animate={{
            y: [0, 8, 0],
            rotate: [0, 3, 0],
          }}
          transition={{
            duration: 3.5,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
            delay: 0.5,
          }}
        >
          <Bookmark className="h-8 w-8 text-[#D4AF37]/30" />
        </motion.div>
      </div>

      <div className="absolute top-8 left-8 z-10">
        <Link href="/" className="flex items-center gap-2 transition-transform hover:scale-105">
          <Feather className="h-6 w-6 text-[#D4AF37]" />
          <span className="text-xl font-bold text-white gatsby-heading">PenPal AI</span>
        </Link>
      </div>

      <motion.div className="w-full max-w-md z-10" variants={containerVariants} initial="hidden" animate="visible">
        <motion.div variants={itemVariants} className="mb-8 text-center">
          <div className="inline-block p-4 bg-[#D4AF37]/10 rounded-full mb-4 backdrop-blur-sm border border-[#D4AF37]/30">
            <KeyRound className="h-8 w-8 text-[#D4AF37]" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-white gatsby-heading">Welcome Back</h1>
          <p className="text-[#D4AF37]/80 mt-2 gatsby-text">Sign in to continue your writing journey</p>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="border-[#D4AF37]/20 shadow-lg bg-white/10 backdrop-blur-md">
            <CardHeader className="space-y-1 pb-4">
              <CardTitle className="text-xl text-white gatsby-heading">Sign in</CardTitle>
              <CardDescription className="text-[#D4AF37]/80">
                Enter your credentials to access your account
              </CardDescription>
            </CardHeader>
            <CardContent>
              {error && (
                <Alert variant="destructive" className="mb-4 bg-red-500/20 border-red-500/30">
                  <AlertTitle className="text-white">Error</AlertTitle>
                  <AlertDescription className="text-white/80">{error}</AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-white">
                    Email
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 h-4 w-4 text-[#D4AF37]" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="name@example.com"
                      className="pl-10 bg-white/10 border-[#D4AF37]/30 text-white placeholder:text-white/50 focus:border-[#D4AF37]"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password" className="text-white">
                      Password
                    </Label>
                    <Button variant="link" className="h-auto p-0 text-xs text-[#D4AF37] hover:text-[#E5C158]">
                      Forgot password?
                    </Button>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 h-4 w-4 text-[#D4AF37]" />
                    <Input
                      id="password"
                      type="password"
                      className="pl-10 bg-white/10 border-[#D4AF37]/30 text-white focus:border-[#D4AF37]"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-[#D4AF37] text-[#0f2137] hover:bg-[#E5C158] font-medium"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <span className="flex items-center gap-2">
                      <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                      Signing in...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      Sign in
                      <ArrowRight className="h-4 w-4" />
                    </span>
                  )}
                </Button>
              </form>

              <div className="mt-4 flex items-center gap-2">
                <Separator className="flex-1 bg-[#D4AF37]/30" />
                <span className="text-xs text-[#D4AF37]/80">OR</span>
                <Separator className="flex-1 bg-[#D4AF37]/30" />
              </div>

              <div className="mt-4">
                <Button variant="outline" className="w-full border-[#D4AF37]/30 text-white hover:bg-[#D4AF37]/20">
                  <Sparkles className="mr-2 h-4 w-4 text-[#D4AF37]" />
                  Continue with Magic Link
                </Button>
              </div>
            </CardContent>
            <CardFooter className="flex justify-center border-t border-[#D4AF37]/20 px-6 py-4">
              <div className="text-center text-sm text-white/80">
                Don't have an account?{" "}
                <Link href="/signup" className="font-medium text-[#D4AF37] hover:text-[#E5C158]">
                  Sign up
                </Link>
              </div>
            </CardFooter>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants} className="mt-6 text-center">
          <p className="text-sm text-white/60">
            By signing in, you agree to our{" "}
            <Link href="#" className="text-[#D4AF37] hover:text-[#E5C158]">
              Terms of Service
            </Link>{" "}
            and{" "}
            <Link href="#" className="text-[#D4AF37] hover:text-[#E5C158]">
              Privacy Policy
            </Link>
          </p>
        </motion.div>
      </motion.div>
    </div>
  )
}
