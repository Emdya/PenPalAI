"use client"

import { useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AnimatedBook } from "@/components/ui/animated-book"
import {
  Feather,
  BookOpen,
  MessageSquare,
  LineChart,
  Users,
  Palette,
  FileText,
  Sparkles,
  Brain,
  Award,
  ArrowRight,
  ArrowLeft,
  Lightbulb,
  CheckCircle,
  Edit,
} from "lucide-react"

export default function FeaturesPage() {
  const [activeTab, setActiveTab] = useState("writing")
  const [bookOpen, setBookOpen] = useState(false)

  // Error handling
  const [error, setError] = useState<string | null>(null)

  const handleTabChange = (value: string) => {
    setActiveTab(value)
  }

  const features = {
    writing: [
      {
        icon: <MessageSquare className="h-6 w-6" />,
        title: "AI Chatbot Editor",
        description: "Get real-time editing and writing suggestions from our AI assistant.",
      },
      {
        icon: <BookOpen className="h-6 w-6" />,
        title: "Chapter Outlines",
        description: "Generate chapter outlines and scene ideas based on your chosen genre.",
      },
      {
        icon: <LineChart className="h-6 w-6" />,
        title: "Word Count Tracking",
        description: "Track word count per session and visualize your writing progress.",
      },
      {
        icon: <Brain className="h-6 w-6" />,
        title: "Tone & Consistency",
        description: "Analyze tone and check for consistency in characters and plot points.",
      },
    ],
    collaboration: [
      {
        icon: <Users className="h-6 w-6" />,
        title: "Real-time Collaboration",
        description: "Share your drafts and collaborate with others in real-time.",
      },
      {
        icon: <Edit className="h-6 w-6" />,
        title: "Comments & Suggestions",
        description: "Allow collaborators to comment on specific lines and add suggestions.",
      },
      {
        icon: <CheckCircle className="h-6 w-6" />,
        title: "Version Control",
        description: "Track changes and revert to previous versions of your manuscript.",
      },
      {
        icon: <Lightbulb className="h-6 w-6" />,
        title: "Feedback System",
        description: "Get constructive feedback from beta readers and editors.",
      },
    ],
    publishing: [
      {
        icon: <Palette className="h-6 w-6" />,
        title: "AI Cover Generator",
        description: "Generate book covers based on your story with AI image generation.",
      },
      {
        icon: <FileText className="h-6 w-6" />,
        title: "Export Options",
        description: "Export your book in PDF, EPUB, and pre-formatted DOCX formats.",
      },
      {
        icon: <Award className="h-6 w-6" />,
        title: "Publishing Guidance",
        description: "Step-by-step guidance for publishing on major platforms.",
      },
      {
        icon: <Sparkles className="h-6 w-6" />,
        title: "Writing Streaks",
        description: "Track your writing streaks and earn badges for milestones.",
      },
    ],
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted">
      {error && (
        <div className="bg-destructive/10 text-destructive p-4 rounded-md mb-4">
          <p>Error: {error}</p>
          <p>Please try again later or contact support if the problem persists.</p>
        </div>
      )}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex items-center justify-between py-4">
          <Link href="/" className="flex items-center gap-2">
            <Feather className="w-6 h-6 text-primary" />
            <span className="text-xl font-bold">PenPal AI</span>
          </Link>
          <div className="flex items-center gap-4">
            <Link href="/login">
              <Button variant="outline" size="sm">
                Log in
              </Button>
            </Link>
            <Link href="/signup">
              <Button size="sm">Sign up</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="container py-12">
        <div className="text-center mb-12">
          <motion.h1
            className="text-4xl md:text-5xl font-bold tracking-tight mb-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Explore PenPal AI Features
          </motion.h1>
          <motion.p
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            Discover how our AI-powered tools can transform your writing process
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6 }}>
            <AnimatedBook
              autoAnimate={false}
              className="mx-auto"
              onOpen={() => setBookOpen(true)}
              onClose={() => setBookOpen(false)}
            />
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6 }}>
            <h2 className="text-3xl font-bold mb-4">Your Writing Journey Starts Here</h2>
            <p className="text-muted-foreground mb-6">
              PenPal AI combines the power of artificial intelligence with intuitive writing tools to help you write
              better, faster, and with more confidence. From brainstorming to publishing, we're with you every step of
              the way.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/signup">
                <Button size="lg" className="bg-[#D4AF37] text-[#0f2137] hover:bg-[#E5C158] font-medium">
                  Start Free Trial
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link href="/#pricing">
                <Button variant="outline" size="lg" className="w-full sm:w-auto">
                  View Pricing
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>

        <div className="mb-16">
          <Tabs defaultValue="writing" className="w-full" onValueChange={handleTabChange}>
            <div className="flex justify-center mb-8">
              <TabsList className="grid w-full max-w-md grid-cols-3">
                <TabsTrigger value="writing" className="text-sm">
                  Writing Tools
                </TabsTrigger>
                <TabsTrigger value="collaboration" className="text-sm">
                  Collaboration
                </TabsTrigger>
                <TabsTrigger value="publishing" className="text-sm">
                  Publishing
                </TabsTrigger>
              </TabsList>
            </div>

            {Object.entries(features).map(([key, featureList]) => (
              <TabsContent key={key} value={key} className="mt-0">
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
                  {featureList.map((feature, index) => (
                    <motion.div
                      key={feature.title}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                    >
                      <Card className="h-full border-muted-foreground/20 shadow-sm hover:shadow-md transition-all">
                        <CardHeader>
                          <div className="rounded-full bg-primary/10 p-2 w-fit mb-2">{feature.icon}</div>
                          <CardTitle>{feature.title}</CardTitle>
                          <CardDescription>{feature.description}</CardDescription>
                        </CardHeader>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>

        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Writing?</h2>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of authors who have discovered the power of AI-assisted writing with PenPal AI.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/signup">
              <Button size="lg" className="w-full sm:w-auto">
                Get Started Free
              </Button>
            </Link>
            <Link href="/">
              <Button variant="outline" size="lg" className="w-full sm:w-auto">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </main>

      <footer className="border-t py-8 bg-muted/30">
        <div className="container text-center text-sm text-muted-foreground">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Feather className="h-5 w-5 text-primary" />
            <p className="font-medium">PenPal AI</p>
          </div>
          <p>© {new Date().getFullYear()} PenPal AI. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
