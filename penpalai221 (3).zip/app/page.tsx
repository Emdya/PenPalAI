import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Feather, Sparkles, BookOpen, PenTool, Users } from "lucide-react"
import {
  ClientWrapper,
  DynamicBookModel,
  DynamicQuillPenModel,
  DynamicFloatingTextEffect,
} from "@/components/landing/home-client"

export default function HomePage() {
  return (
    <ClientWrapper>
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-md">
        <div className="container flex items-center justify-between py-4">
          <Link href="/" className="flex items-center gap-2">
            <Feather className="w-6 h-6 text-amber-400" />
            <span className="text-xl font-bold gatsby-heading">PenPal AI</span>
          </Link>
          <div className="flex items-center gap-4">
            <Link href="/login">
              <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
                Log in
              </Button>
            </Link>
            <Link href="/signup">
              <Button size="sm" className="bg-amber-400 text-black hover:bg-amber-300">
                Sign up
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main>
        <section className="py-20 relative overflow-hidden">
          {/* Dynamically loaded 3D text effect */}
          <div className="absolute top-20 left-0 right-0 h-[200px] pointer-events-none">
            <DynamicFloatingTextEffect />
          </div>

          <div className="container px-4 md:px-6 relative z-10">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none gatsby-heading">
                    <span className="block text-[#D4AF37]">Write Your Story</span>
                    <span className="block">With AI Assistance</span>
                  </h1>
                  <p className="max-w-[600px] text-gray-200 md:text-xl gatsby-text">
                    PenPal AI helps you write, edit, and publish your book with AI-powered tools and guidance.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/signup">
                    <Button size="lg" className="gap-1.5 bg-[#D4AF37] text-[#0f2137] hover:bg-[#E5C158] font-medium">
                      Start Writing <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/features">
                    <Button
                      size="lg"
                      variant="outline"
                      className="border-[#D4AF37]/30 text-white hover:bg-[#D4AF37]/20"
                    >
                      Explore Features
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="flex items-center justify-center">
                {/* Dynamically loaded 3D book model */}
                <DynamicBookModel />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-black/30 backdrop-blur-sm">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl gatsby-heading">
                  <span className="text-amber-400">Powerful Features</span> for Writers
                </h2>
                <p className="max-w-[900px] text-gray-300 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed gatsby-text">
                  Everything you need to write, edit, and publish your book in one place.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 mt-12">
              {[
                {
                  icon: <Sparkles className="h-6 w-6" />,
                  title: "AI Writing Assistant",
                  description: "Get real-time suggestions and feedback as you write your story.",
                },
                {
                  icon: <BookOpen className="h-6 w-6" />,
                  title: "Chapter Outlines",
                  description: "Generate detailed chapter outlines based on your genre and style.",
                },
                {
                  icon: <PenTool className="h-6 w-6" />,
                  title: "Smart Editor",
                  description: "Write with an editor that understands your story and characters.",
                },
                {
                  icon: <Users className="h-6 w-6" />,
                  title: "Collaboration",
                  description: "Work with co-authors, editors, and beta readers seamlessly.",
                },
              ].map((feature, index) => (
                <div
                  key={index}
                  className="flex flex-col items-start gap-2 rounded-lg border border-[#D4AF37]/20 bg-white/5 p-6 backdrop-blur-sm"
                >
                  <div className="rounded-full bg-[#D4AF37]/10 p-2 text-[#D4AF37]">{feature.icon}</div>
                  <h3 className="text-lg font-semibold text-white gatsby-heading">{feature.title}</h3>
                  <p className="text-sm text-gray-300 gatsby-text">{feature.description}</p>
                </div>
              ))}

              <div className="sm:col-span-2 lg:col-span-1">
                {/* Dynamically loaded 3D quill pen model */}
                <DynamicQuillPenModel />
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 relative">
          <div className="container px-4 md:px-6 text-center">
            <h2 className="text-3xl font-bold mb-6 gatsby-heading">Ready to Start Your Writing Journey?</h2>
            <Link href="/signup">
              <Button size="lg" className="bg-amber-400 text-black hover:bg-amber-300">
                Get Started Free
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <footer className="border-t border-white/10 py-8 bg-black/30 backdrop-blur-sm">
        <div className="container text-center text-sm text-gray-400">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Feather className="h-5 w-5 text-amber-400" />
            <p className="font-medium">PenPal AI</p>
          </div>
          <p>© {new Date().getFullYear()} PenPal AI. All rights reserved.</p>
        </div>
      </footer>
    </ClientWrapper>
  )
}
