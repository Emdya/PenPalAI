import type { NextAuthOptions } from "next-auth"

// Mock auth options for browser environments
export const mockAuthOptions: NextAuthOptions = {
  providers: [],
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },
  pages: {
    signIn: "/login",
    signOut: "/",
    error: "/login",
  },
  callbacks: {
    async jwt({ token }) {
      return token
    },
    async session({ session }) {
      return session
    },
  },
  secret: "MOCK_SECRET_FOR_BROWSER",
}
