export function generateChapterOutline(
  title: string,
  genre: string,
): Promise<{ success: boolean; outline?: string; error?: string }> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const mockOutline = `# Chapter Outline for "${title}" (${genre})\n\n## Chapter 1: The Beginning\n- Introduce the main character\n- Set the scene and establish the initial conflict\n\n## Chapter 2: Rising Action\n- The character faces challenges and obstacles\n- Develop the plot and introduce supporting characters\n\n## Chapter 3: Climax\n- The character confronts the main conflict\n- The stakes are high and the outcome is uncertain\n\n## Chapter 4: Falling Action\n- The character deals with the aftermath of the climax\n- Resolve subplots and tie up loose ends\n\n## Chapter 5: Resolution\n- The character achieves their goal or comes to terms with their situation\n- Provide a sense of closure and leave the reader satisfied`
      resolve({ success: true, outline: mockOutline })
    }, 500)
  })
}

export function getMockChatResponse(input: string): string {
  // This is a placeholder - replace with more sophisticated logic if needed
  if (input.includes("outline")) {
    return "Okay, here's a chapter outline: Chapter 1: The Beginning. Chapter 2: The Journey. Chapter 3: The Climax. Chapter 4: The Resolution."
  } else if (input.includes("tone")) {
    return "The tone of your writing is mysterious and intriguing."
  } else if (input.includes("consistency")) {
    return "I've checked your writing for consistency and found no issues."
  } else if (input.includes("improve")) {
    return "I suggest you add more sensory details to your writing."
  } else {
    return "I am an AI writing assistant. How can I help you today?"
  }
}
