// Helper function to check if we're in a browser environment
export function isBrowser(): boolean {
  return typeof window !== "undefined"
}

// Mock user data for browser environments
const mockUser = {
  id: "mock-user-id",
  name: "Demo User",
  email: "demo@example.com",
  image: "/placeholder.svg?height=40&width=40",
}

// Get a mock server session for browser environments
export function getMockServerSession() {
  return {
    user: mockUser,
    expires: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toISOString(), // 1 week from now
  }
}
