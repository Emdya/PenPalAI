export const gatsbyColors = {
  gold: "#d4af37",
  darkGold: "#b8860b",
  lightGold: "#f5df4d",
  black: "#0a0a0a",
  cream: "#f8f0e3",
  navy: "#0f2137",
  emerald: "#50c878",
  burgundy: "#800020",
  champagne: "#f7e7ce",
}

export const gatsbyGradients = {
  goldShimmer: "linear-gradient(45deg, #d4af37 0%, #f5df4d 50%, #d4af37 100%)",
  navyGold: "linear-gradient(to right, #0f2137 0%, #0f2137 40%, #d4af37 100%)",
  darkLight: "linear-gradient(to bottom, #0a0a0a 0%, #333333 100%)",
}

export const gatsbyPatterns = {
  artDeco: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23d4af37' fill-opacity='0.15'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
  zigzag: `url("data:image/svg+xml,%3Csvg width='40' height='12' viewBox='0 0 40 12' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 6.172L6.172 0h5.656L0 11.828V6.172zm40 5.656L28.172 0h5.656L40 6.172v5.656zM6.172 12l12-12h3.656l12 12h-5.656L20 3.828 11.828 12H6.172zm12 0L20 10.172 21.828 12h-3.656z' fill='%23d4af37' fill-opacity='0.15' fill-rule='evenodd'/%3E%3C/svg%3E")`,
}

export const gatsbyAnimations = {
  shimmer: "shimmer 3s infinite",
  fadeIn: "fadeIn 0.5s ease-in-out",
  slideUp: "slideUp 0.5s ease-out",
  pulse: "pulse 2s infinite",
}
