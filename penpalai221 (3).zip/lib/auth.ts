import type { NextAuthOptions } from "next-auth"
import { mockAuthOptions } from "./mock-auth"
import { timingSafeEqual, scrypt } from "crypto"
import { promisify } from "util"

// Promisify scrypt
const scryptAsync = promisify(scrypt)

// Function to verify password
async function verifyPassword(storedPassword: string, suppliedPassword: string): Promise<boolean> {
  // Handle both formats (bcrypt and our new format)
  if (storedPassword.includes(".")) {
    // Our new format (salt.hash)
    const [hashedPassword, salt] = storedPassword.split(".")
    const hashedPasswordBuf = Buffer.from(hashedPassword, "hex")
    const suppliedPasswordBuf = (await scryptAsync(suppliedPassword, salt, 64)) as Buffer
    return timingSafeEqual(hashedPasswordBuf, suppliedPasswordBuf)
  } else {
    // For compatibility with existing bcrypt passwords, return false
    // This will force users to reset their password
    console.warn("Found old password format, user will need to reset password")
    return false
  }
}

// Check if we're in a browser environment
const isBrowser = () => {
  return typeof window !== "undefined"
}

// For server environments, import and use the real providers
let realAuthOptions: NextAuthOptions | null = null

// Only import these on the server
if (!isBrowser()) {
  const importCredentialsProvider = async () => {
    try {
      // Dynamic import to avoid "CredentialsProvider is not a function" error
      const { default: CredentialsProvider } = await import("next-auth/providers/credentials")
      const { getUserByEmail } = await import("@/lib/db")
      // const { default: bcrypt } = await import("bcryptjs") // Removed bcrypt import

      return {
        providers: [
          CredentialsProvider({
            name: "Credentials",
            credentials: {
              email: { label: "Email", type: "email" },
              password: { label: "Password", type: "password" },
            },
            async authorize(credentials) {
              if (!credentials?.email || !credentials?.password) {
                return null
              }

              try {
                // Find user by email
                const user = await getUserByEmail(credentials.email)

                // If no user found or password doesn't match
                if (!user || !(await verifyPassword(user.password, credentials.password))) {
                  return null
                }

                // Return user without password
                return {
                  id: user.id,
                  name: user.name,
                  email: user.email,
                  image: user.image,
                }
              } catch (error) {
                console.error("Auth error:", error)
                return null
              }
            },
          }),
        ],
        session: {
          strategy: "jwt",
          maxAge: 30 * 24 * 60 * 60, // 30 days
        },
        pages: {
          signIn: "/login",
          signOut: "/",
          error: "/login",
        },
        callbacks: {
          async jwt({ token, user }) {
            if (user) {
              token.id = user.id
            }
            return token
          },
          async session({ session, token }) {
            if (session.user) {
              session.user.id = token.id as string
            }
            return session
          },
        },
        secret: process.env.NEXTAUTH_SECRET || "DEVELOPMENT_SECRET_DO_NOT_USE_IN_PRODUCTION",
      }
    } catch (error) {
      console.error("Error importing auth dependencies:", error)
      return mockAuthOptions
    }
  }

  // Initialize the real auth options
  importCredentialsProvider().then((options) => {
    realAuthOptions = options
  })
}

// Export the appropriate auth options based on environment
export const authOptions: NextAuthOptions = isBrowser() ? mockAuthOptions : realAuthOptions || mockAuthOptions
