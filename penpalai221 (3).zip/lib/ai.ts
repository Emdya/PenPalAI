import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

// Fallback responses in case the AI service is unavailable
const FALLBACK_RESPONSES = {
  chapterOutline: "Unable to generate chapter outline. Please try again later.",
  suggestions: "Unable to generate writing suggestions. Please try again later.",
  toneAnalysis: "Unable to analyze text tone. Please try again later.",
  consistencyCheck: "Unable to check consistency. Please try again later.",
}

export async function generateChapterOutline(genre: string, title: string) {
  if (!process.env.OPENAI_API_KEY) {
    console.warn("Missing OPENAI_API_KEY environment variable")
    return { success: false, error: "AI service not configured" }
  }

  const prompt = `Generate a detailed chapter outline for a ${genre} book titled "${title}". Include 5-7 chapters with brief descriptions of key events in each chapter.`

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt,
    })

    return { success: true, data: text }
  } catch (error) {
    console.error("Error generating chapter outline:", error)
    return { success: false, error: FALLBACK_RESPONSES.chapterOutline }
  }
}

export async function generateWritingSuggestions(content: string) {
  if (!process.env.OPENAI_API_KEY) {
    console.warn("Missing OPENAI_API_KEY environment variable")
    return { success: false, error: "AI service not configured" }
  }

  const prompt = `Analyze the following text and provide 3 specific suggestions to improve it. Focus on enhancing descriptive language, character development, and plot coherence:\n\n${content}`

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt,
    })

    return { success: true, data: text }
  } catch (error) {
    console.error("Error generating writing suggestions:", error)
    return { success: false, error: FALLBACK_RESPONSES.suggestions }
  }
}

export async function analyzeTextTone(content: string) {
  if (!process.env.OPENAI_API_KEY) {
    console.warn("Missing OPENAI_API_KEY environment variable")
    return { success: false, error: "AI service not configured" }
  }

  const prompt = `Analyze the tone of the following text. Identify the primary emotional tone, formality level, and any inconsistencies in tone throughout the passage:\n\n${content}`

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt,
    })

    return { success: true, data: text }
  } catch (error) {
    console.error("Error analyzing text tone:", error)
    return { success: false, error: FALLBACK_RESPONSES.toneAnalysis }
  }
}

export async function checkConsistency(content: string) {
  if (!process.env.OPENAI_API_KEY) {
    console.warn("Missing OPENAI_API_KEY environment variable")
    return { success: false, error: "AI service not configured" }
  }

  const prompt = `Review the following text for consistency issues. Identify any inconsistencies in character names, descriptions, plot details, or timeline. Format your response as a list of issues found:\n\n${content}`

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt,
    })

    return { success: true, data: text }
  } catch (error) {
    console.error("Error checking consistency:", error)
    return { success: false, error: FALLBACK_RESPONSES.consistencyCheck }
  }
}
