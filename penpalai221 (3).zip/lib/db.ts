import { neon, neonConfig } from "@neondatabase/serverless"
import { v4 as uuidv4 } from "uuid"

// Configure neon to use WebSockets in development
if (process.env.NODE_ENV === "development") {
  // Use dynamic import instead of require
  import('ws').then(ws => {
    neonConfig.webSocketConstructor = ws.default
  }).catch(err => {
    console.error('Failed to import WebSocket:', err)
  })
}

// Create a SQL client
const sql = neon(process.env.DATABASE_URL!)

export { sql }

// Check database connection
export async function checkDatabaseConnection() {
  try {
    const result = await sql`SELECT 1 as connection_test`
    return result.length > 0 && result[0].connection_test === 1
  } catch (error) {
    console.error("Database connection error:", error)
    return false
  }
}

// User functions
export async function createUser({ name, email, password }: { name: string; email: string; password: string }) {
  try {
    const id = uuidv4()
    const result = await sql`
      INSERT INTO "User" (id, name, email, password)
      VALUES (${id}, ${name}, ${email}, ${password})
      RETURNING id, name, email, "createdAt"
    `
    return result[0]
  } catch (error) {
    console.error("Error creating user:", error)
    throw error
  }
}

export async function getUserByEmail(email: string) {
  try {
    const result = await sql`
      SELECT id, name, email, password, image, "createdAt", "updatedAt"
      FROM "User"
      WHERE email = ${email}
    `
    return result[0] || null
  } catch (error) {
    console.error("Error fetching user by email:", error)
    throw error
  }
}

export async function getUserById(id: string) {
  try {
    const result = await sql`
      SELECT id, name, email, image, "createdAt", "updatedAt"
      FROM "User"
      WHERE id = ${id}
    `
    return result[0] || null
  } catch (error) {
    console.error("Error fetching user by ID:", error)
    throw error
  }
}

// Book functions
export async function getBooksByUserId(userId: string) {
  try {
    const result = await sql`
      SELECT id, title, genre, description, "coverImage", "wordCount", "chapterCount", "createdAt", "updatedAt"
      FROM "Book"
      WHERE "userId" = ${userId}
      ORDER BY "updatedAt" DESC
    `
    return result
  } catch (error) {
    console.error("Error fetching books by user ID:", error)
    throw error
  }
}

export async function createBook({
  title,
  genre,
  description,
  userId,
}: {
  title: string
  genre: string | null
  description: string | null
  userId: string
}) {
  try {
    const id = uuidv4()
    const result = await sql`
      INSERT INTO "Book" (id, title, genre, description, "userId")
      VALUES (${id}, ${title}, ${genre}, ${description}, ${userId})
      RETURNING id, title, genre, description, "userId", "createdAt", "updatedAt"
    `
    return result[0]
  } catch (error) {
    console.error("Error creating book:", error)
    throw error
  }
}

export async function getBookById(id: string) {
  try {
    const result = await sql`
      SELECT id, title, genre, description, "coverImage", "wordCount", "chapterCount", "userId", "createdAt", "updatedAt"
      FROM "Book"
      WHERE id = ${id}
    `
    return result[0] || null
  } catch (error) {
    console.error("Error fetching book by ID:", error)
    throw error
  }
}

// Chapter functions
export async function getChaptersByBookId(bookId: string) {
  try {
    const result = await sql`
      SELECT id, title, content, "orderIndex", "wordCount", "bookId", "createdAt", "updatedAt"
      FROM "Chapter"
      WHERE "bookId" = ${bookId}
      ORDER BY "orderIndex" ASC
    `
    return result
  } catch (error) {
    console.error("Error fetching chapters by book ID:", error)
    throw error
  }
}

export async function createChapter({
  title,
  content,
  orderIndex,
  bookId,
}: {
  title: string
  content: string | null
  orderIndex: number
  bookId: string
}) {
  try {
    const id = uuidv4()
    const wordCount = content ? content.trim().split(/\s+/).length : 0

    const result = await sql`
      INSERT INTO "Chapter" (id, title, content, "orderIndex", "wordCount", "bookId")
      VALUES (${id}, ${title}, ${content}, ${orderIndex}, ${wordCount}, ${bookId})
      RETURNING id, title, "orderIndex", "wordCount", "bookId", "createdAt", "updatedAt"
    `

    // Update book's chapter count and word count
    await sql`
      UPDATE "Book"
      SET "chapterCount" = (SELECT COUNT(*) FROM "Chapter" WHERE "bookId" = ${bookId}),
          "wordCount" = (SELECT SUM("wordCount") FROM "Chapter" WHERE "bookId" = ${bookId})
      WHERE id = ${bookId}
    `

    return result[0]
  } catch (error) {
    console.error("Error creating chapter:", error)
    throw error
  }
}

// Scene functions
export async function getScenesByChapterId(chapterId: string) {
  try {
    const result = await sql`
      SELECT id, title, content, "orderIndex", "wordCount", "chapterId", "createdAt", "updatedAt"
      FROM "Scene"
      WHERE "chapterId" = ${chapterId}
      ORDER BY "orderIndex" ASC
    `
    return result
  } catch (error) {
    console.error("Error fetching scenes by chapter ID:", error)
    throw error
  }
}

// Writing stats functions
export async function getWritingStatsByUserId(userId: string, days = 30) {
  try {
    const result = await sql`
      SELECT date, "wordCount", "timeSpent", "bookId"
      FROM "WritingStat"
      WHERE "userId" = ${userId}
      AND date >= CURRENT_DATE - ${days} * INTERVAL '1 day'
      ORDER BY date ASC
    `
    return result
  } catch (error) {
    console.error("Error fetching writing stats:", error)
    throw error
  }
}

export async function recordWritingStat({
  userId,
  bookId,
  wordCount,
  timeSpent,
}: {
  userId: string
  bookId: string | null
  wordCount: number
  timeSpent: number
}) {
  try {
    const today = new Date().toISOString().split("T")[0]

    // Check if there's already a record for today
    const existingRecord = await sql`
      SELECT id, "wordCount", "timeSpent"
      FROM "WritingStat"
      WHERE "userId" = ${userId}
      AND "bookId" ${bookId ? sql`= ${bookId}` : sql`IS NULL`}
      AND date = ${today}
    `

    if (existingRecord.length > 0) {
      // Update existing record
      const id = existingRecord[0].id
      const newWordCount = existingRecord[0].wordCount + wordCount
      const newTimeSpent = existingRecord[0].timeSpent + timeSpent

      await sql`
        UPDATE "WritingStat"
        SET "wordCount" = ${newWordCount}, "timeSpent" = ${newTimeSpent}, "updatedAt" = CURRENT_TIMESTAMP
        WHERE id = ${id}
      `

      return { id, wordCount: newWordCount, timeSpent: newTimeSpent }
    } else {
      // Create new record
      const id = uuidv4()
      const result = await sql`
        INSERT INTO "WritingStat" (id, date, "wordCount", "timeSpent", "userId", "bookId")
        VALUES (${id}, ${today}, ${wordCount}, ${timeSpent}, ${userId}, ${bookId})
        RETURNING id, date, "wordCount", "timeSpent"
      `

      return result[0]
    }
  } catch (error) {
    console.error("Error recording writing stat:", error)
    throw error
  }
}

// Book cover functions
export async function getBookCoversByUserId(userId: string) {
  try {
    const result = await sql`
      SELECT id, title, "imageUrl", "bookId", "createdAt"
      FROM "BookCover"
      WHERE "userId" = ${userId}
      ORDER BY "createdAt" DESC
    `
    return result
  } catch (error) {
    console.error("Error fetching book covers:", error)
    throw error
  }
}

export async function createBookCover({
  title,
  imageUrl,
  userId,
  bookId,
}: {
  title: string
  imageUrl: string
  userId: string
  bookId?: string
}) {
  try {
    const id = uuidv4()
    const result = await sql`
      INSERT INTO "BookCover" (id, title, "imageUrl", "userId", "bookId")
      VALUES (${id}, ${title}, ${imageUrl}, ${userId}, ${bookId || null})
      RETURNING id, title, "imageUrl", "userId", "bookId", "createdAt"
    `
    return result[0]
  } catch (error) {
    console.error("Error creating book cover:", error)
    throw error
  }
}

// Achievement functions
export async function getAchievements() {
  try {
    const result = await sql`
      SELECT id, title, description, icon
      FROM "Achievement"
      ORDER BY title ASC
    `
    return result
  } catch (error) {
    console.error("Error fetching achievements:", error)
    throw error
  }
}

export async function getUserAchievements(userId: string) {
  try {
    const result = await sql`
      SELECT a.id, a.title, a.description, a.icon, ua."earnedAt"
      FROM "Achievement" a
      JOIN "UserAchievement" ua ON a.id = ua."achievementId"
      WHERE ua."userId" = ${userId}
      ORDER BY ua."earnedAt" DESC
    `
    return result
  } catch (error) {
    console.error("Error fetching user achievements:", error)
    throw error
  }
}

export async function awardAchievement({
  userId,
  achievementId,
}: {
  userId: string
  achievementId: string
}) {
  try {
    // Check if the user already has this achievement
    const existing = await sql`
      SELECT id FROM "UserAchievement"
      WHERE "userId" = ${userId} AND "achievementId" = ${achievementId}
    `

    if (existing.length > 0) {
      return null // User already has this achievement
    }

    const id = uuidv4()
    const result = await sql`
      INSERT INTO "UserAchievement" (id, "userId", "achievementId")
      VALUES (${id}, ${userId}, ${achievementId})
      RETURNING id, "userId", "achievementId", "earnedAt"
    `

    return result[0]
  } catch (error) {
    console.error("Error awarding achievement:", error)
    throw error
  }
}
