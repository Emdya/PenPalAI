"use client"

// Helper functions for 3D components
import { useState, useEffect } from "react"

// Check if a file exists by making a HEAD request
export async function checkFileExists(url: string): Promise<boolean> {
  try {
    const response = await fetch(url, { method: "HEAD" })
    return response.ok
  } catch (error) {
    console.error(`Error checking if file exists at ${url}:`, error)
    return false
  }
}

// Hook to check if we're in a browser environment
export function useBrowserEnvironment() {
  const [isBrowser, setIsBrowser] = useState(false)

  useEffect(() => {
    setIsBrowser(typeof window !== "undefined")
  }, [])

  return isBrowser
}

// Default model paths with fallbacks
export const MODEL_PATHS = {
  // Set to null by default since we know the models don't exist in the project
  BOOK: null,
  QUILL: null,
  FALLBACK_CUBE: null, // No fallback needed, we'll create a simple cube
}
