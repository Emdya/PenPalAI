"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Book, Edit, Award, Clock } from "lucide-react"
import { GatsbyCorner } from "@/components/gatsby-decorative-elements"
import { IconFrame } from "@/components/ui/icon-frame"

type AnalyticsData = {
  totalBooks: number
  draftBooks: number
  completedBooks: number
  totalWords: number
  currentStreak: number
  longestStreak: number
  totalWritingDays: number
  averageWordsPerDay: number
  totalWritingTime: number // in minutes
}

export function AnalyticsDashboard() {
  const [data, setData] = useState<AnalyticsData>({
    totalBooks: 0,
    draftBooks: 0,
    completedBooks: 0,
    totalWords: 0,
    currentStreak: 0,
    longestStreak: 0,
    totalWritingDays: 0,
    averageWordsPerDay: 0,
    totalWritingTime: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // In a real implementation, this would fetch data from the API
    // For now, we'll simulate loading and then set sample data
    const fetchData = async () => {
      setLoading(true)
      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Sample data - in production this would come from your API
        setData({
          totalBooks: 5,
          draftBooks: 3,
          completedBooks: 2,
          totalWords: 45280,
          currentStreak: 8,
          longestStreak: 14,
          totalWritingDays: 32,
          averageWordsPerDay: 1415,
          totalWritingTime: 2460, // 41 hours
        })
      } catch (error) {
        console.error("Error fetching analytics data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  // Format minutes into hours and minutes
  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return `${hours}h ${mins}m`
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold text-[#0f2137] font-['Playfair_Display']">Writing Overview</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Books Created Card */}
        <Card className="relative overflow-hidden group border-[#D4AF37]/30 hover:border-[#D4AF37]">
          <GatsbyCorner position="top-left" />
          <GatsbyCorner position="bottom-right" />
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-xl font-['Playfair_Display']">
              <Book className="h-5 w-5 text-[#D4AF37]" />
              Books Created
            </CardTitle>
            <CardDescription>Total manuscripts in your library</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold text-[#0f2137]">{loading ? "..." : data.totalBooks}</div>
              <IconFrame icon={Book} size="sm" />
            </div>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span>Drafts</span>
                <span className="font-medium">{loading ? "..." : data.draftBooks}</span>
              </div>
              <Progress value={loading ? 0 : (data.draftBooks / data.totalBooks) * 100} className="h-2" />
              <div className="flex justify-between text-sm">
                <span>Completed</span>
                <span className="font-medium">{loading ? "..." : data.completedBooks}</span>
              </div>
              <Progress value={loading ? 0 : (data.completedBooks / data.totalBooks) * 100} className="h-2" />
            </div>
          </CardContent>
        </Card>

        {/* Words Typed Card */}
        <Card className="relative overflow-hidden group border-[#D4AF37]/30 hover:border-[#D4AF37]">
          <GatsbyCorner position="top-left" />
          <GatsbyCorner position="bottom-right" />
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-xl font-['Playfair_Display']">
              <Edit className="h-5 w-5 text-[#D4AF37]" />
              Words Typed
            </CardTitle>
            <CardDescription>Total words across all manuscripts</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold text-[#0f2137]">
                {loading ? "..." : data.totalWords.toLocaleString()}
              </div>
              <IconFrame icon={Edit} size="sm" />
            </div>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span>Daily Average</span>
                <span className="font-medium">{loading ? "..." : data.averageWordsPerDay.toLocaleString()}</span>
              </div>
              <div className="text-sm text-muted-foreground mt-2">
                That's approximately {loading ? "..." : Math.round(data.totalWords / 250)} pages!
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Writing Streak Card */}
        <Card className="relative overflow-hidden group border-[#D4AF37]/30 hover:border-[#D4AF37]">
          <GatsbyCorner position="top-left" />
          <GatsbyCorner position="bottom-right" />
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-xl font-['Playfair_Display']">
              <Award className="h-5 w-5 text-[#D4AF37]" />
              Current Streak
            </CardTitle>
            <CardDescription>Consecutive days of writing</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold text-[#0f2137]">{loading ? "..." : `${data.currentStreak} days`}</div>
              <IconFrame icon={Award} size="sm" />
            </div>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span>Longest Streak</span>
                <span className="font-medium">{loading ? "..." : `${data.longestStreak} days`}</span>
              </div>
              <Progress value={loading ? 0 : (data.currentStreak / data.longestStreak) * 100} className="h-2" />
              <div className="text-sm text-muted-foreground mt-2">
                You've written on {loading ? "..." : data.totalWritingDays} days total
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Writing Time Card */}
        <Card className="relative overflow-hidden group border-[#D4AF37]/30 hover:border-[#D4AF37]">
          <GatsbyCorner position="top-left" />
          <GatsbyCorner position="bottom-right" />
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-xl font-['Playfair_Display']">
              <Clock className="h-5 w-5 text-[#D4AF37]" />
              Writing Time
            </CardTitle>
            <CardDescription>Total time spent writing</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold text-[#0f2137]">
                {loading ? "..." : `${Math.floor(data.totalWritingTime / 60)}h`}
              </div>
              <IconFrame icon={Clock} size="sm" />
            </div>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span>Per Writing Day</span>
                <span className="font-medium">
                  {loading ? "..." : formatTime(Math.round(data.totalWritingTime / data.totalWritingDays))}
                </span>
              </div>
              <div className="text-sm text-muted-foreground mt-2">
                That's {loading ? "..." : (data.totalWritingTime / 60).toFixed(1)} hours of creativity!
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
