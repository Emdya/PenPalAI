"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProfileSettings } from "@/components/settings/profile-settings"
import { AccountSettings } from "@/components/settings/account-settings"
import { AppearanceSettings } from "@/components/settings/appearance-settings"
import { PrivacySettings } from "@/components/settings/privacy-settings"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/hooks/use-auth"
import { isBrowser, getMockServerSession } from "@/lib/mock-session"
import { ShootingStars } from "@/components/ui/shooting-stars"
import { FloatingBooks } from "@/components/ui/floating-books"
import { WritingQuill } from "@/components/ui/writing-quill"

export function SettingsPageContent() {
  const { data: session, status } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("profile")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Only redirect if we're not in a browser preview and authentication has completed loading
    if (status === "loading") {
      setIsLoading(true)
      return
    }

    setIsLoading(false)

    if (status === "unauthenticated" && !isBrowser()) {
      router.push("/login")
    }
  }, [status, router])

  // Show loading state or mock data in browser preview
  if (isLoading) {
    return (
      <div className="container mx-auto py-10 flex items-center justify-center min-h-[60vh]">
        <div className="animate-pulse text-center">
          <h2 className="text-2xl font-bold">Loading settings...</h2>
          <p className="text-muted-foreground mt-2">Please wait while we load your preferences</p>
        </div>
      </div>
    )
  }

  // Use mock session in browser preview
  const userSession = isBrowser() ? getMockServerSession() : session

  return (
    <div className="container mx-auto py-10 relative overflow-hidden">
      {/* Decorative elements */}
      <ShootingStars />
      <FloatingBooks />
      <WritingQuill />

      <div className="mb-8 relative z-10">
        <h1 className="text-3xl font-bold">Settings</h1>
        <p className="text-muted-foreground">Manage your account settings and preferences</p>
      </div>

      <div className="relative z-10 bg-background/80 backdrop-blur-sm rounded-lg p-6 border shadow-lg">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger
              value="profile"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Profile
            </TabsTrigger>
            <TabsTrigger
              value="account"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Account
            </TabsTrigger>
            <TabsTrigger
              value="appearance"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Appearance
            </TabsTrigger>
            <TabsTrigger
              value="privacy"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Privacy
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-4">
            <ProfileSettings user={userSession?.user} />
          </TabsContent>

          <TabsContent value="account" className="space-y-4">
            <AccountSettings />
          </TabsContent>

          <TabsContent value="appearance" className="space-y-4">
            <AppearanceSettings />
          </TabsContent>

          <TabsContent value="privacy" className="space-y-4">
            <PrivacySettings />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
