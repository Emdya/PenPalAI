"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { isBrowser } from "@/lib/mock-session"
import { Eye, EyeOff, Lock, Globe, Shield } from "lucide-react"
import { motion } from "framer-motion"

export function PrivacySettings() {
  const { toast } = useToast()
  const [isPublic, setIsPublic] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleUpdatePrivacy = async () => {
    setIsLoading(true)

    try {
      // In browser preview, simulate success
      if (isBrowser()) {
        await new Promise((resolve) => setTimeout(resolve, 1000))
        toast({
          title: "Success",
          description: `Your account is now ${isPublic ? "public" : "private"}`,
        })
        setIsLoading(false)
        return
      }

      const response = await fetch("/api/user/update-privacy", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ isPublic }),
      })

      if (!response.ok) {
        throw new Error("Failed to update privacy settings")
      }

      toast({
        title: "Success",
        description: `Your account is now ${isPublic ? "public" : "private"}`,
      })
    } catch (error) {
      console.error("Error updating privacy settings:", error)
      toast({
        title: "Error",
        description: "Failed to update privacy settings. Please try again.",
        variant: "destructive",
      })
      // Revert the switch if there was an error
      setIsPublic(!isPublic)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="border-primary/20 shadow-lg relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-background z-0"></div>
      <CardHeader className="relative z-10">
        <CardTitle className="flex items-center gap-2">
          <span className="text-primary">Privacy</span>
          <div className="h-px flex-1 bg-primary/20"></div>
        </CardTitle>
        <CardDescription className="flex items-center gap-2">
          <Shield className="h-4 w-4 text-primary" />
          Manage your privacy settings and control who can see your content
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6 relative z-10">
        <div className="p-4 bg-primary/5 rounded-lg border border-primary/10 mb-4">
          <h3 className="font-medium text-primary mb-2">Account Visibility</h3>
          <p className="text-sm text-muted-foreground">
            Control whether your profile and books are visible to other users on the platform.
          </p>
        </div>

        <div
          className="flex items-center justify-between space-x-4 p-4 rounded-lg border border-primary/20 transition-colors duration-300"
          style={{
            backgroundColor: isPublic ? "rgba(144, 238, 144, 0.1)" : "rgba(255, 99, 71, 0.05)",
          }}
        >
          <div className="space-y-1">
            <Label htmlFor="public-profile" className="text-lg font-medium flex items-center gap-2">
              {isPublic ? <Globe className="h-5 w-5 text-green-500" /> : <Lock className="h-5 w-5 text-red-500" />}
              <span>{isPublic ? "Public Account" : "Private Account"}</span>
            </Label>
            <p className="text-sm text-muted-foreground">
              {isPublic ? "Your profile and books are visible to everyone" : "Only you can see your profile and books"}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <motion.div
              animate={{
                x: isPublic ? [0, 5, 0] : 0,
                opacity: isPublic ? 1 : 0.5,
              }}
              transition={{ duration: 0.5 }}
            >
              {isPublic ? <Eye className="h-5 w-5 text-green-500" /> : <EyeOff className="h-5 w-5 text-red-500" />}
            </motion.div>
            <Switch
              id="public-profile"
              checked={isPublic}
              onCheckedChange={(checked) => {
                setIsPublic(checked)
              }}
              className="data-[state=checked]:bg-green-500 data-[state=unchecked]:bg-red-500"
            />
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="font-medium text-primary">What others can see when your account is public:</h3>
          <ul className="space-y-2 text-sm">
            <PrivacyItem icon={<BookIcon />} text="Your book titles and covers" isVisible={isPublic} />
            <PrivacyItem icon={<ProfileIcon />} text="Your profile information" isVisible={isPublic} />
            <PrivacyItem icon={<AchievementIcon />} text="Your writing achievements" isVisible={isPublic} />
            <PrivacyItem
              icon={<StatsIcon />}
              text="Your writing statistics"
              isVisible={false}
              note="(Always private)"
            />
          </ul>
        </div>
      </CardContent>
      <CardFooter className="relative z-10 flex justify-end">
        <Button
          onClick={handleUpdatePrivacy}
          disabled={isLoading}
          className="bg-primary hover:bg-primary/90 text-white"
        >
          {isLoading ? "Saving..." : "Save Privacy Settings"}
        </Button>
      </CardFooter>
    </Card>
  )
}

function BookIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
    </svg>
  )
}

function ProfileIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
      <circle cx="12" cy="7" r="4"></circle>
    </svg>
  )
}

function AchievementIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="8" r="7"></circle>
      <polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"></polyline>
    </svg>
  )
}

function StatsIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="18" y1="20" x2="18" y2="10"></line>
      <line x1="12" y1="20" x2="12" y2="4"></line>
      <line x1="6" y1="20" x2="6" y2="14"></line>
    </svg>
  )
}

interface PrivacyItemProps {
  icon: React.ReactNode
  text: string
  isVisible: boolean
  note?: string
}

function PrivacyItem({ icon, text, isVisible, note }: PrivacyItemProps) {
  return (
    <motion.li
      className="flex items-center gap-2"
      animate={{
        opacity: isVisible ? 1 : 0.5,
        x: isVisible ? [0, 5, 0] : 0,
      }}
      transition={{ duration: 0.5 }}
    >
      <span className={`${isVisible ? "text-green-500" : "text-red-500"}`}>{icon}</span>
      <span>{text}</span>
      {note && <span className="text-xs text-muted-foreground">{note}</span>}
      {isVisible ? (
        <Eye className="h-3 w-3 text-green-500 ml-auto" />
      ) : (
        <EyeOff className="h-3 w-3 text-red-500 ml-auto" />
      )}
    </motion.li>
  )
}
