"use client"

import type React from "react"
import type { User } from "next-auth"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { isBrowser } from "@/lib/mock-session"

interface ProfileSettingsProps {
  user?: User
}

export function ProfileSettings({ user }: ProfileSettingsProps) {
  const { toast } = useToast()
  const [username, setUsername] = useState(user?.name || "")
  const [isLoading, setIsLoading] = useState(false)
  const [avatarUrl, setAvatarUrl] = useState(user?.image || "")

  const handleUpdateUsername = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!username.trim()) {
      toast({
        title: "Error",
        description: "Username cannot be empty",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      // In browser preview, simulate success
      if (isBrowser()) {
        await new Promise((resolve) => setTimeout(resolve, 1000))
        toast({
          title: "Success",
          description: "Username updated successfully",
        })
        setIsLoading(false)
        return
      }

      const response = await fetch("/api/user/update-username", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username }),
      })

      if (!response.ok) {
        throw new Error("Failed to update username")
      }

      toast({
        title: "Success",
        description: "Username updated successfully",
      })
    } catch (error) {
      console.error("Error updating username:", error)
      toast({
        title: "Error",
        description: "Failed to update username. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // In a real app, you would upload this to a storage service
    // For now, we'll just create a local URL
    const reader = new FileReader()
    reader.onload = () => {
      setAvatarUrl(reader.result as string)
    }
    reader.readAsDataURL(file)

    toast({
      title: "Avatar updated",
      description: "Your profile picture has been updated",
    })
  }

  return (
    <Card className="border-primary/20 shadow-lg relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-background z-0"></div>
      <CardHeader className="relative z-10">
        <CardTitle className="flex items-center gap-2">
          <span className="text-primary">Profile</span>
          <div className="h-px flex-1 bg-primary/20"></div>
        </CardTitle>
        <CardDescription>Update your profile information and avatar</CardDescription>
      </CardHeader>
      <form onSubmit={handleUpdateUsername}>
        <CardContent className="space-y-6 relative z-10">
          <div className="flex flex-col sm:flex-row gap-6 items-center">
            <div className="relative group">
              <Avatar className="w-24 h-24 border-2 border-primary/50 group-hover:border-primary transition-all duration-300">
                <AvatarImage src={avatarUrl || "/placeholder.svg"} />
                <AvatarFallback className="text-2xl bg-primary/10 text-primary">
                  {username.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <label
                htmlFor="avatar-upload"
                className="absolute inset-0 rounded-full bg-black/50 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 cursor-pointer transition-opacity"
              >
                Change
              </label>
              <input
                id="avatar-upload"
                type="file"
                accept="image/*"
                className="sr-only"
                onChange={handleAvatarChange}
              />
            </div>
            <div className="space-y-4 flex-1">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-primary">
                  Username
                </Label>
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter your username"
                  className="border-primary/20 focus-visible:ring-primary"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email" className="text-primary">
                  Email
                </Label>
                <Input
                  id="email"
                  value={user?.email || ""}
                  disabled
                  placeholder="Your email address"
                  className="bg-primary/5 border-primary/20"
                />
                <p className="text-xs text-muted-foreground">Your email address cannot be changed</p>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="relative z-10 flex justify-end">
          <Button type="submit" disabled={isLoading} className="bg-primary hover:bg-primary/90 text-white">
            {isLoading ? "Updating..." : "Update Profile"}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
