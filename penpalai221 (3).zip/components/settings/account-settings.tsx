"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { isBrowser } from "@/lib/mock-session"
import { Lock, Unlock, Shield, AlertTriangle, CheckCircle } from "lucide-react"
import { Progress } from "@/components/ui/progress"

export function AccountSettings() {
  const { toast } = useToast()
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [passwordStrength, setPasswordStrength] = useState(0)

  const calculatePasswordStrength = (password: string) => {
    if (!password) return 0

    let strength = 0

    // Length check
    if (password.length >= 8) strength += 25

    // Contains lowercase
    if (/[a-z]/.test(password)) strength += 25

    // Contains uppercase
    if (/[A-Z]/.test(password)) strength += 25

    // Contains number or special char
    if (/[0-9!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password)) strength += 25

    return strength
  }

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const password = e.target.value
    setNewPassword(password)
    setPasswordStrength(calculatePasswordStrength(password))
  }

  const getStrengthColor = () => {
    if (passwordStrength < 50) return "bg-red-500"
    if (passwordStrength < 75) return "bg-yellow-500"
    return "bg-green-500"
  }

  const getStrengthText = () => {
    if (passwordStrength < 50) return "Weak"
    if (passwordStrength < 75) return "Medium"
    return "Strong"
  }

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!currentPassword || !newPassword || !confirmPassword) {
      toast({
        title: "Error",
        description: "All fields are required",
        variant: "destructive",
      })
      return
    }

    if (newPassword !== confirmPassword) {
      toast({
        title: "Error",
        description: "New passwords do not match",
        variant: "destructive",
      })
      return
    }

    if (newPassword.length < 8) {
      toast({
        title: "Error",
        description: "Password must be at least 8 characters long",
        variant: "destructive",
      })
      return
    }

    if (passwordStrength < 50) {
      toast({
        title: "Warning",
        description: "Your password is weak. Consider using a stronger password.",
        variant: "destructive",
      })
    }

    setIsLoading(true)

    try {
      // In browser preview, simulate success
      if (isBrowser()) {
        await new Promise((resolve) => setTimeout(resolve, 1000))
        toast({
          title: "Success",
          description: "Password updated successfully",
        })
        setCurrentPassword("")
        setNewPassword("")
        setConfirmPassword("")
        setPasswordStrength(0)
        setIsLoading(false)
        return
      }

      const response = await fetch("/api/user/update-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          currentPassword,
          newPassword,
        }),
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.message || "Failed to update password")
      }

      toast({
        title: "Success",
        description: "Password updated successfully",
      })

      // Clear form
      setCurrentPassword("")
      setNewPassword("")
      setConfirmPassword("")
      setPasswordStrength(0)
    } catch (error: any) {
      console.error("Error updating password:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to update password. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="border-primary/20 shadow-lg relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-background z-0"></div>
      <CardHeader className="relative z-10">
        <CardTitle className="flex items-center gap-2">
          <span className="text-primary">Account Security</span>
          <div className="h-px flex-1 bg-primary/20"></div>
        </CardTitle>
        <CardDescription className="flex items-center gap-2">
          <Shield className="h-4 w-4 text-primary" />
          Update your password and security settings
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleUpdatePassword}>
        <CardContent className="space-y-6 relative z-10">
          <div className="p-4 bg-primary/5 rounded-lg border border-primary/10 mb-4">
            <h3 className="font-medium text-primary mb-2 flex items-center gap-2">
              <Lock className="h-4 w-4" />
              Password Security Tips
            </h3>
            <ul className="text-sm space-y-1 text-muted-foreground">
              <li className="flex items-center gap-1">
                <CheckCircle className="h-3 w-3 text-green-500" />
                Use at least 8 characters
              </li>
              <li className="flex items-center gap-1">
                <CheckCircle className="h-3 w-3 text-green-500" />
                Include uppercase and lowercase letters
              </li>
              <li className="flex items-center gap-1">
                <CheckCircle className="h-3 w-3 text-green-500" />
                Include numbers and special characters
              </li>
              <li className="flex items-center gap-1">
                <AlertTriangle className="h-3 w-3 text-yellow-500" />
                Don't reuse passwords from other sites
              </li>
            </ul>
          </div>

          <div className="space-y-2">
            <Label htmlFor="current-password" className="text-primary flex items-center gap-2">
              <Lock className="h-4 w-4" />
              Current Password
            </Label>
            <div className="relative">
              <Input
                id="current-password"
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Enter your current password"
                className="border-primary/20 focus-visible:ring-primary pr-10"
              />
              <Lock className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="new-password" className="text-primary flex items-center gap-2">
              <Unlock className="h-4 w-4" />
              New Password
            </Label>
            <div className="relative">
              <Input
                id="new-password"
                type="password"
                value={newPassword}
                onChange={handlePasswordChange}
                placeholder="Enter your new password"
                className="border-primary/20 focus-visible:ring-primary pr-10"
              />
              <Unlock className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>

            {newPassword && (
              <div className="space-y-1 mt-2">
                <div className="flex justify-between text-xs">
                  <span>Password strength:</span>
                  <span
                    className={
                      passwordStrength >= 75
                        ? "text-green-500"
                        : passwordStrength >= 50
                          ? "text-yellow-500"
                          : "text-red-500"
                    }
                  >
                    {getStrengthText()}
                  </span>
                </div>
                <Progress value={passwordStrength} className="h-2" indicatorClassName={getStrengthColor()} />
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirm-password" className="text-primary flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              Confirm New Password
            </Label>
            <div className="relative">
              <Input
                id="confirm-password"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm your new password"
                className="border-primary/20 focus-visible:ring-primary pr-10"
              />
              <CheckCircle className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
            {confirmPassword && newPassword !== confirmPassword && (
              <p className="text-xs text-red-500 mt-1">Passwords do not match</p>
            )}
          </div>
        </CardContent>
        <CardFooter className="relative z-10 flex justify-end">
          <Button type="submit" disabled={isLoading} className="bg-primary hover:bg-primary/90 text-white">
            {isLoading ? "Updating..." : "Update Password"}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
