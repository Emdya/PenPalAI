"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useTheme } from "next-themes"
import { motion } from "framer-motion"
import { Sun, Moon, Laptop, Sparkles } from "lucide-react"

export function AppearanceSettings() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const [selectedTheme, setSelectedTheme] = useState<string | undefined>(undefined)

  // Avoid hydration mismatch
  useEffect(() => {
    setMounted(true)
    setSelectedTheme(theme)
  }, [theme])

  if (!mounted) {
    return null
  }

  const handleThemeChange = (value: string) => {
    setSelectedTheme(value)
    setTheme(value)
  }

  return (
    <Card className="border-primary/20 shadow-lg relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-background z-0"></div>
      <CardHeader className="relative z-10">
        <CardTitle className="flex items-center gap-2">
          <span className="text-primary">Appearance</span>
          <div className="h-px flex-1 bg-primary/20"></div>
        </CardTitle>
        <CardDescription>Customize the appearance of the application</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6 relative z-10">
        <div className="space-y-4">
          <Label className="text-lg font-medium text-primary flex items-center gap-2">
            <Sparkles className="h-4 w-4" />
            Theme
          </Label>
          <RadioGroup
            value={selectedTheme}
            onValueChange={handleThemeChange}
            className="grid grid-cols-1 md:grid-cols-3 gap-4"
          >
            <ThemeOption
              value="light"
              label="Light"
              icon={<Sun className="h-6 w-6" />}
              description="Bright and clear interface"
              isSelected={selectedTheme === "light"}
            />
            <ThemeOption
              value="dark"
              label="Dark"
              icon={<Moon className="h-6 w-6" />}
              description="Easy on the eyes at night"
              isSelected={selectedTheme === "dark"}
            />
            <ThemeOption
              value="system"
              label="System"
              icon={<Laptop className="h-6 w-6" />}
              description="Follows your system preference"
              isSelected={selectedTheme === "system"}
            />
          </RadioGroup>
        </div>
      </CardContent>
    </Card>
  )
}

interface ThemeOptionProps {
  value: string
  label: string
  icon: React.ReactNode
  description: string
  isSelected: boolean
}

function ThemeOption({ value, label, icon, description, isSelected }: ThemeOptionProps) {
  return (
    <div className="relative">
      <RadioGroupItem value={value} id={`theme-${value}`} className="peer sr-only" />
      <Label
        htmlFor={`theme-${value}`}
        className={`
          flex flex-col items-center justify-between rounded-md border-2 border-muted 
          p-4 hover:bg-accent hover:text-accent-foreground transition-all duration-300
          ${isSelected ? "border-primary" : "border-muted"}
        `}
      >
        <motion.div
          className={`mb-3 p-3 rounded-full ${isSelected ? "bg-primary text-primary-foreground" : "bg-muted"}`}
          animate={{ scale: isSelected ? [1, 1.2, 1] : 1 }}
          transition={{ duration: 0.5 }}
        >
          {icon}
        </motion.div>
        <div className="text-center">
          <div className="font-medium">{label}</div>
          <div className="text-xs text-muted-foreground mt-1">{description}</div>
        </div>
        {isSelected && (
          <motion.div
            className="absolute -top-1 -right-1 bg-primary text-white rounded-full p-1"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 500, damping: 30 }}
          >
            <Sparkles className="h-3 w-3" />
          </motion.div>
        )}
      </Label>
    </div>
  )
}
