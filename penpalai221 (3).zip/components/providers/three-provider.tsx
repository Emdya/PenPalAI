"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import dynamic from "next/dynamic"

// Context for Three.js availability
const ThreeContext = createContext<{
  isReady: boolean
  hasWebGL: boolean
  error: string | null
}>({
  isReady: false,
  hasWebGL: false,
  error: null,
})

export const useThree = () => useContext(ThreeContext)

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState({
    isReady: false,
    hasWebGL: false,
    error: null as string | null,
  })

  useEffect(() => {
    // Check if we're in the browser
    if (typeof window !== "undefined") {
      try {
        // Check for WebGL support
        const canvas = document.createElement("canvas")
        const gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl")

        if (!gl) {
          setState({
            isReady: true,
            hasWebGL: false,
            error: "WebGL is not supported in your browser",
          })
        } else {
          setState({
            isReady: true,
            hasWebGL: true,
            error: null,
          })
        }
      } catch (error) {
        setState({
          isReady: true,
          hasWebGL: false,
          error: "Error initializing WebGL",
        })
        console.error("WebGL initialization error:", error)
      }
    }
  }, [])

  return <ThreeContext.Provider value={state}>{children}</ThreeContext.Provider>
}

// Use this for dynamic imports of Three.js components
export const withThree = (Component: React.ComponentType<any>) => {
  return dynamic(() => Promise.resolve(Component), {
    ssr: false,
  })
}
