"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Sparkles, RefreshCw, Check, AlertCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export function CoverGenerator() {
  const [prompt, setPrompt] = useState("")
  const [title, setTitle] = useState("The Lost Kingdom")
  const [author, setAuthor] = useState("Your Name")
  const [genre, setGenre] = useState("Fantasy")
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedCovers, setGeneratedCovers] = useState<string[]>([])
  const [selectedCover, setSelectedCover] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const { toast } = useToast()

  const handleGenerate = async () => {
    if (!prompt.trim() || !title.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide a title and description for your cover.",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)
    setError(null)

    try {
      // Make the actual API call
      const response = await fetch("/api/ai/cover", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title,
          author,
          genre,
          prompt,
        }),
      })

      if (!response.ok) {
        throw new Error(`Failed to generate covers: ${response.statusText}`)
      }

      const data = await response.json()
      setGeneratedCovers(data.covers)
      setSelectedCover(data.covers[0])
    } catch (error) {
      console.error("Error generating covers:", error)
      setError("Failed to generate cover images. Please try again.")
      toast({
        title: "Error",
        description: "Failed to generate cover images. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleSelectCover = (cover: string) => {
    setSelectedCover(cover)
  }

  const handleSaveCover = async () => {
    if (!selectedCover) return

    toast({
      title: "Cover saved",
      description: "Your cover has been saved successfully.",
    })
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardContent className="p-6">
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault()
              handleGenerate()
            }}
          >
            <div className="space-y-2">
              <Label htmlFor="title">Book Title</Label>
              <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="author">Author Name</Label>
              <Input id="author" value={author} onChange={(e) => setAuthor(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="genre">Genre</Label>
              <Input id="genre" value={genre} onChange={(e) => setGenre(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="prompt">Description (for AI generation)</Label>
              <Textarea
                id="prompt"
                placeholder="Describe your book cover in detail..."
                className="min-h-[100px]"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              />
            </div>
            <Button type="submit" className="w-full" disabled={isGenerating || !prompt.trim()}>
              {isGenerating ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Generate Covers
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <div className="aspect-[2/3] rounded-lg border bg-muted flex items-center justify-center overflow-hidden">
          {selectedCover ? (
            <img
              src={selectedCover || "/placeholder.svg"}
              alt="Selected book cover"
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="text-center p-4">
              <Sparkles className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
              <p className="text-muted-foreground">Your generated cover will appear here</p>
            </div>
          )}
        </div>
        {selectedCover && (
          <div className="flex justify-center gap-2">
            <Button variant="outline" size="sm" onClick={handleGenerate} disabled={isGenerating}>
              <RefreshCw className="mr-2 h-4 w-4" />
              Regenerate
            </Button>
            <Button size="sm" onClick={handleSaveCover}>
              <Check className="mr-2 h-4 w-4" />
              Use This Cover
            </Button>
          </div>
        )}
      </div>

      {generatedCovers.length > 0 && (
        <div className="space-y-4 md:col-span-2">
          <h3 className="text-lg font-medium">Alternative Designs</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {generatedCovers.map((cover, index) => (
              <div
                key={index}
                className={`aspect-[2/3] rounded-lg border overflow-hidden cursor-pointer transition-all ${
                  selectedCover === cover ? "ring-2 ring-primary" : "hover:opacity-80"
                }`}
                onClick={() => handleSelectCover(cover)}
              >
                <img
                  src={cover || "/placeholder.svg"}
                  alt={`Alternative cover ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
