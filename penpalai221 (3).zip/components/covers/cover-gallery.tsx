import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Download, Edit, Trash2 } from "lucide-react"

export function CoverGallery() {
  const covers = [
    {
      id: 1,
      title: "The Lost Kingdom",
      image: "/placeholder.svg?height=600&width=400",
      date: "Apr 10, 2025",
    },
    {
      id: 2,
      title: "Midnight Secrets",
      image: "/placeholder.svg?height=600&width=400",
      date: "Apr 5, 2025",
    },
    {
      id: 3,
      title: "Beyond the Stars",
      image: "/placeholder.svg?height=600&width=400",
      date: "Mar 28, 2025",
    },
    {
      id: 4,
      title: "The Ancient Prophecy",
      image: "/placeholder.svg?height=600&width=400",
      date: "Mar 15, 2025",
    },
  ]

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {covers.map((cover) => (
          <Card key={cover.id} className="overflow-hidden">
            <div className="aspect-[2/3] relative group">
              <img src={cover.image || "/placeholder.svg"} alt={cover.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                <Button variant="outline" size="icon" className="h-8 w-8 bg-background/20 backdrop-blur-sm">
                  <Download className="h-4 w-4" />
                  <span className="sr-only">Download</span>
                </Button>
                <Button variant="outline" size="icon" className="h-8 w-8 bg-background/20 backdrop-blur-sm">
                  <Edit className="h-4 w-4" />
                  <span className="sr-only">Edit</span>
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8 bg-background/20 backdrop-blur-sm text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                  <span className="sr-only">Delete</span>
                </Button>
              </div>
            </div>
            <CardContent className="p-3">
              <div className="text-sm font-medium truncate">{cover.title}</div>
              <div className="text-xs text-muted-foreground">{cover.date}</div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
