"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Bold, Italic, AlignLeft, AlignCenter, AlignRight, Download } from "lucide-react"

export function CoverEditor() {
  const [title, setTitle] = useState("The Lost Kingdom")
  const [author, setAuthor] = useState("Your Name")
  const [fontSize, setFontSize] = useState(48)
  const [textColor, setTextColor] = useState("#ffffff")
  const [textAlign, setTextAlign] = useState("center")
  const [fontWeight, setFontWeight] = useState("bold")
  const [fontStyle, setFontStyle] = useState("normal")

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="space-y-4">
        <div className="aspect-[2/3] rounded-lg border bg-muted flex items-center justify-center overflow-hidden relative">
          <img
            src="/placeholder.svg?height=600&width=400"
            alt="Book cover preview"
            className="w-full h-full object-cover absolute inset-0"
          />
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6">
            <div
              className="text-center"
              style={{
                fontSize: `${fontSize}px`,
                color: textColor,
                textAlign: textAlign as any,
                fontWeight: fontWeight,
                fontStyle: fontStyle,
              }}
            >
              {title}
            </div>
            <div
              className="mt-4 text-center"
              style={{
                fontSize: `${fontSize / 2}px`,
                color: textColor,
                textAlign: textAlign as any,
              }}
            >
              {author}
            </div>
          </div>
        </div>
        <div className="flex justify-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Download
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="edit-title">Title</Label>
          <Input id="edit-title" value={title} onChange={(e) => setTitle(e.target.value)} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="edit-author">Author</Label>
          <Input id="edit-author" value={author} onChange={(e) => setAuthor(e.target.value)} />
        </div>
        <div className="space-y-2">
          <Label>Font Size</Label>
          <Slider value={[fontSize]} min={24} max={72} step={1} onValueChange={(value) => setFontSize(value[0])} />
        </div>
        <div className="space-y-2">
          <Label>Text Color</Label>
          <div className="flex items-center gap-2">
            <Input
              type="color"
              value={textColor}
              onChange={(e) => setTextColor(e.target.value)}
              className="w-12 h-8 p-1"
            />
            <Input value={textColor} onChange={(e) => setTextColor(e.target.value)} />
          </div>
        </div>
        <div className="space-y-2">
          <Label>Text Alignment</Label>
          <div className="flex gap-2">
            <Button
              variant={textAlign === "left" ? "default" : "outline"}
              size="icon"
              onClick={() => setTextAlign("left")}
            >
              <AlignLeft className="h-4 w-4" />
              <span className="sr-only">Align Left</span>
            </Button>
            <Button
              variant={textAlign === "center" ? "default" : "outline"}
              size="icon"
              onClick={() => setTextAlign("center")}
            >
              <AlignCenter className="h-4 w-4" />
              <span className="sr-only">Align Center</span>
            </Button>
            <Button
              variant={textAlign === "right" ? "default" : "outline"}
              size="icon"
              onClick={() => setTextAlign("right")}
            >
              <AlignRight className="h-4 w-4" />
              <span className="sr-only">Align Right</span>
            </Button>
          </div>
        </div>
        <div className="space-y-2">
          <Label>Text Style</Label>
          <div className="flex gap-2">
            <Button
              variant={fontWeight === "bold" ? "default" : "outline"}
              size="icon"
              onClick={() => setFontWeight(fontWeight === "bold" ? "normal" : "bold")}
            >
              <Bold className="h-4 w-4" />
              <span className="sr-only">Bold</span>
            </Button>
            <Button
              variant={fontStyle === "italic" ? "default" : "outline"}
              size="icon"
              onClick={() => setFontStyle(fontStyle === "italic" ? "normal" : "italic")}
            >
              <Italic className="h-4 w-4" />
              <span className="sr-only">Italic</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
