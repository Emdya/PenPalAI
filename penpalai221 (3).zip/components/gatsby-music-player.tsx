"use client"

import { useState, useEffect, useRef } from "react"
import { Volume2, VolumeX, Settings, Volume1, Volume, Play, Pause, Music, AlertCircle } from "lucide-react"
import { GatsbyButton } from "@/components/ui/gatsby-button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Slider } from "@/components/ui/slider"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"

export function GatsbyMusicPlayer() {
  const [isMuted, setIsMuted] = useState(false)
  const [volume, setVolume] = useState(0.5)
  const [isPlaying, setIsPlaying] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const { toast } = useToast()

  // Use a reliable external source that allows CORS
  const audioSource = "https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8e7a8db54.mp3"

  useEffect(() => {
    // Get reference to the audio element in the DOM
    const audioElement = document.getElementById("gatsby-audio") as HTMLAudioElement
    if (audioElement) {
      audioRef.current = audioElement
      audioElement.volume = volume

      // Remove any automatic play attempts
      // audioElement.play() - removing this

      // Add event listeners
      audioElement.addEventListener("play", () => setIsPlaying(true))
      audioElement.addEventListener("pause", () => setIsPlaying(false))
      audioElement.addEventListener("error", (e) => {
        console.error("Audio error details:", e)
        setError("Could not play audio. Your browser may not support this feature or requires user interaction first.")
        setIsPlaying(false)
      })

      return () => {
        audioElement.removeEventListener("play", () => setIsPlaying(true))
        audioElement.removeEventListener("pause", () => setIsPlaying(false))
        audioElement.removeEventListener("error", () => {})
      }
    }
  }, [toast])

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume
    }
  }, [volume, isMuted])

  const togglePlay = () => {
    if (!audioRef.current) return

    try {
      if (isPlaying) {
        audioRef.current.pause()
      } else {
        setError(null)
        const playPromise = audioRef.current.play()
        if (playPromise !== undefined) {
          playPromise.catch((error) => {
            console.error("Play error:", error)
            setError("Audio playback requires user interaction first. Please try clicking the play button again.")
            toast({
              title: "Audio Notice",
              description: "Audio playback requires user interaction. Click play again.",
              variant: "default",
            })
          })
        }
      }
    } catch (err) {
      console.error("Toggle play error:", err)
      setError("Playback error occurred. Try clicking play again.")
    }
  }

  const toggleMute = () => {
    setIsMuted(!isMuted)
    if (audioRef.current) {
      audioRef.current.volume = !isMuted ? 0 : volume
    }
  }

  const handleVolumeChange = (newVolume: number[]) => {
    const volumeValue = newVolume[0]
    setVolume(volumeValue)
    setIsMuted(volumeValue === 0)
    if (audioRef.current) {
      audioRef.current.volume = volumeValue
    }
  }

  // Function to get the appropriate volume icon based on current volume
  const getVolumeIcon = () => {
    if (isMuted || volume === 0) return <VolumeX className="h-4 w-4" />
    if (volume < 0.4) return <Volume className="h-4 w-4" />
    if (volume < 0.7) return <Volume1 className="h-4 w-4" />
    return <Volume2 className="h-4 w-4" />
  }

  return (
    <>
      {/* Actual audio element in the DOM */}
      <audio
        id="gatsby-audio"
        src={audioSource}
        loop
        preload="none"
        style={{ display: "none" }} // Hidden from view
      />

      {/* Settings button in top right corner */}
      <div className="fixed top-4 right-4 z-50">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <GatsbyButton
              variant="ghost"
              size="icon"
              shape="default"
              className="text-[#f8f0e3] bg-[#0a0a0a]/80 backdrop-blur-sm hover:bg-[#d4af37]/20"
            >
              <Settings className="h-4 w-4" />
              <span className="sr-only">Music settings</span>
            </GatsbyButton>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48 p-3">
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs gatsby-accent flex items-center gap-1">
                  <Music className="h-3 w-3" /> Jazz Music
                </span>
                <GatsbyButton
                  variant="ghost"
                  size="icon"
                  shape="default"
                  onClick={toggleMute}
                  className="h-6 w-6 text-[#0a0a0a] hover:bg-[#d4af37]/20"
                >
                  {getVolumeIcon()}
                </GatsbyButton>
              </div>
              <Slider value={[isMuted ? 0 : volume]} min={0} max={1} step={0.01} onValueChange={handleVolumeChange} />
              <div className="flex justify-between">
                <DropdownMenuItem onClick={toggleMute} className="cursor-pointer justify-center">
                  {isMuted ? "Unmute" : "Mute"}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={togglePlay} className="cursor-pointer justify-center">
                  {isPlaying ? "Pause" : "Play"}
                </DropdownMenuItem>
              </div>
            </div>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Play/Pause button (always visible) */}
      <div className="fixed bottom-4 right-4 z-50">
        <GatsbyButton
          onClick={togglePlay}
          className="flex items-center gap-2 bg-[#0a0a0a]/80 backdrop-blur-sm text-[#f8f0e3] hover:bg-[#d4af37]/20"
        >
          {isPlaying ? (
            <>
              <Pause className="h-4 w-4" />
              Pause Music
            </>
          ) : (
            <>
              <Play className="h-4 w-4" />
              Click to Play Music
            </>
          )}
        </GatsbyButton>
      </div>

      {/* Error message */}
      {error && (
        <div className="fixed bottom-4 left-4 z-50 max-w-xs">
          <Alert variant="default" className="bg-primary/10 border-primary/20">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        </div>
      )}
    </>
  )
}
