"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle, Database, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { isBrowser } from "@/lib/mock-session"

export function DbInitializer() {
  const [isChecking, setIsChecking] = useState(true)
  const [isInitializing, setIsInitializing] = useState(false)
  const [needsInitialization, setNeedsInitialization] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    checkDatabaseSchema()
  }, [])

  const checkDatabaseSchema = async () => {
    setIsChecking(true)
    setError(null)

    try {
      // In browser preview, simulate success
      if (isBrowser()) {
        await new Promise((resolve) => setTimeout(resolve, 1000))
        setIsChecking(false)
        setNeedsInitialization(false)
        setSuccess(true)
        return
      }

      const response = await fetch("/api/db/check-schema")
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Failed to check database schema")
      }

      setNeedsInitialization(!data.success)
    } catch (error) {
      console.error("Error checking database schema:", error)
      setError(error instanceof Error ? error.message : "Failed to check database schema")
    } finally {
      setIsChecking(false)
    }
  }

  const initializeDatabase = async () => {
    setIsInitializing(true)
    setError(null)

    try {
      // In browser preview, simulate success
      if (isBrowser()) {
        await new Promise((resolve) => setTimeout(resolve, 2000))
        setIsInitializing(false)
        setNeedsInitialization(false)
        setSuccess(true)
        toast({
          title: "Success",
          description: "Database initialized successfully",
        })
        return
      }

      const response = await fetch("/api/db/init", { method: "POST" })
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Failed to initialize database")
      }

      setSuccess(true)
      setNeedsInitialization(false)
      toast({
        title: "Success",
        description: "Database initialized successfully",
      })
    } catch (error) {
      console.error("Error initializing database:", error)
      setError(error instanceof Error ? error.message : "Failed to initialize database")
      toast({
        title: "Error",
        description: "Failed to initialize database. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsInitializing(false)
    }
  }

  if (isChecking) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5 text-primary" />
            Checking Database
          </CardTitle>
          <CardDescription>Verifying database schema...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center py-6">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
        <Button variant="outline" size="sm" onClick={checkDatabaseSchema} className="mt-2">
          Try Again
        </Button>
      </Alert>
    )
  }

  if (success) {
    return (
      <Alert variant="default" className="bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-900">
        <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
        <AlertTitle>Database Ready</AlertTitle>
        <AlertDescription>The database schema is properly initialized and ready to use.</AlertDescription>
      </Alert>
    )
  }

  if (needsInitialization) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5 text-primary" />
            Database Initialization Required
          </CardTitle>
          <CardDescription>
            The database schema needs to be initialized before you can use the application.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">This will create all the necessary tables in your database:</p>
          <ul className="mt-2 text-sm list-disc pl-5 space-y-1">
            <li>User accounts and authentication</li>
            <li>Books, chapters, and scenes</li>
            <li>Writing statistics and achievements</li>
            <li>Book covers and other assets</li>
          </ul>
        </CardContent>
        <CardFooter>
          <Button
            onClick={initializeDatabase}
            disabled={isInitializing}
            className="bg-primary hover:bg-primary/90 text-white"
          >
            {isInitializing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Initializing...
              </>
            ) : (
              "Initialize Database"
            )}
          </Button>
        </CardFooter>
      </Card>
    )
  }

  return null
}
