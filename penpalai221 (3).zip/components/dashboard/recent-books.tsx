"use client"

import Link from "next/link"
import { BookOpen } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

interface Book {
  id: string
  title: string
  description: string | null
  coverImage: string | null
  createdAt: string
  updatedAt: string
  userId: string
  genre: string | null
  wordCount: number
}

interface RecentBooksProps {
  books: Book[]
}

export function RecentBooks({ books }: RecentBooksProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Books</CardTitle>
        <CardDescription>Your most recently updated book projects</CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[300px]">
          <div className="p-4 space-y-4">
            {books.length > 0 ? (
              books.map((book) => (
                <div key={book.id} className="flex items-center justify-between">
                  <div>
                    <Link href={`/dashboard/editor?book=${book.id}`} className="font-medium hover:underline">
                      {book.title}
                    </Link>
                    <p className="text-sm text-muted-foreground truncate">{book.description || "No description"}</p>
                  </div>
                  <Link href={`/dashboard/editor?book=${book.id}`}>
                    <Button variant="outline" size="sm">
                      <BookOpen className="mr-2 h-4 w-4" />
                      Open
                    </Button>
                  </Link>
                </div>
              ))
            ) : (
              <div className="text-center text-muted-foreground">No books found.</div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
