"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  BookOpen,
  Home,
  Settings,
  FileText,
  Users,
  BarChart3,
  Award,
  Palette,
  Sparkles,
  Lightbulb,
  Zap,
  HelpCircle,
  Upload,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

const navItems = [
  {
    title: "Dashboard",
    href: "/dashboard",
    icon: Home,
    description: "Overview of your writing activity",
  },
  {
    title: "My Books",
    href: "/dashboard/books",
    icon: BookOpen,
    description: "Manage your book projects",
  },
  {
    title: "Editor",
    href: "/dashboard/editor",
    icon: FileText,
    description: "Write and edit your content",
  },
  {
    title: "AI Assistant",
    href: "/dashboard/assistant",
    icon: Sparkles,
    description: "Get AI-powered writing help",
    badge: "New",
  },
  {
    title: "Collaborators",
    href: "/dashboard/collaborators",
    icon: Users,
    description: "Manage your writing partners",
  },
  {
    title: "Cover Generator",
    href: "/dashboard/covers",
    icon: Palette,
    description: "Create book covers with AI",
  },
  {
    title: "Chapter Outlines",
    href: "/dashboard/outline",
    icon: Lightbulb,
    description: "Generate chapter outlines",
  },
  {
    title: "Analytics",
    href: "/dashboard/analytics",
    icon: BarChart3,
    description: "Track your writing progress",
  },
  {
    title: "Achievements",
    href: "/dashboard/achievements",
    icon: Award,
    description: "View your writing milestones",
  },
  {
    title: "Publishing",
    href: "/dashboard/publishing",
    icon: Upload,
    description: "Publish your book to major platforms",
    badge: "New",
  },
  {
    title: "Settings",
    href: "/dashboard/settings",
    icon: Settings,
    description: "Manage your account settings",
  },
]

export function DashboardNav() {
  const pathname = usePathname()

  return (
    <ScrollArea className="h-full py-6 pl-3 pr-6">
      <div className="flex flex-col gap-4">
        <div className="px-3 py-2">
          <h3 className="mb-2 text-xs font-medium text-muted-foreground">Main</h3>
          <div className="space-y-1">
            {navItems.slice(0, 4).map((item) => (
              <TooltipProvider key={item.href} delayDuration={0}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant={pathname === item.href ? "secondary" : "ghost"}
                      className={cn(
                        "w-full justify-start gap-2 transition-all",
                        pathname === item.href ? "bg-muted font-medium" : "",
                      )}
                      asChild
                    >
                      <Link href={item.href}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                        {item.badge && (
                          <span className="ml-auto flex h-5 items-center justify-center rounded-full bg-primary px-2 text-[10px] font-medium text-primary-foreground">
                            {item.badge}
                          </span>
                        )}
                      </Link>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="right" className="text-xs">
                    {item.description}
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            ))}
          </div>
        </div>

        <div className="px-3 py-2">
          <h3 className="mb-2 text-xs font-medium text-muted-foreground">Tools</h3>
          <div className="space-y-1">
            {navItems.slice(4, 8).map((item) => (
              <TooltipProvider key={item.href} delayDuration={0}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant={pathname === item.href ? "secondary" : "ghost"}
                      className={cn(
                        "w-full justify-start gap-2 transition-all",
                        pathname === item.href ? "bg-muted font-medium" : "",
                      )}
                      asChild
                    >
                      <Link href={item.href}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                        {item.badge && (
                          <span className="ml-auto flex h-5 items-center justify-center rounded-full bg-primary px-2 text-[10px] font-medium text-primary-foreground">
                            {item.badge}
                          </span>
                        )}
                      </Link>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="right" className="text-xs">
                    {item.description}
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            ))}
          </div>
        </div>

        <div className="px-3 py-2">
          <h3 className="mb-2 text-xs font-medium text-muted-foreground">Other</h3>
          <div className="space-y-1">
            {navItems.slice(8).map((item) => (
              <TooltipProvider key={item.href} delayDuration={0}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant={pathname === item.href ? "secondary" : "ghost"}
                      className={cn(
                        "w-full justify-start gap-2 transition-all",
                        pathname === item.href ? "bg-muted font-medium" : "",
                      )}
                      asChild
                    >
                      <Link href={item.href}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                        {item.badge && (
                          <span className="ml-auto flex h-5 items-center justify-center rounded-full bg-primary px-2 text-[10px] font-medium text-primary-foreground">
                            {item.badge}
                          </span>
                        )}
                      </Link>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="right" className="text-xs">
                    {item.description}
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            ))}
          </div>
        </div>

        <div className="mt-auto px-3">
          <div className="rounded-lg border bg-card p-3">
            <div className="flex items-center gap-3">
              <div className="rounded-full bg-primary/10 p-2">
                <Zap className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h4 className="text-sm font-medium">Need help?</h4>
                <p className="text-xs text-muted-foreground">Check our documentation</p>
              </div>
            </div>
            <Button variant="outline" size="sm" className="mt-3 w-full text-xs" asChild>
              <Link href="#">
                <HelpCircle className="mr-2 h-3 w-3" />
                View Documentation
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </ScrollArea>
  )
}
