"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, LineChart } from "@/components/ui/charts"

export function WritingStats() {
  // Sample data for the charts
  const weeklyData = {
    labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    datasets: [
      {
        label: "Words Written",
        data: [520, 350, 700, 210, 630, 850, 690],
        backgroundColor: "hsl(var(--primary) / 0.5)",
        borderColor: "hsl(var(--primary))",
        borderWidth: 2,
      },
    ],
  }

  const monthlyData = {
    labels: ["Week 1", "Week 2", "Week 3", "Week 4"],
    datasets: [
      {
        label: "Words Written",
        data: [2450, 3200, 2800, 3500],
        backgroundColor: "hsl(var(--primary) / 0.5)",
        borderColor: "hsl(var(--primary))",
        borderWidth: 2,
      },
    ],
  }

  const timeData = {
    labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    datasets: [
      {
        label: "Writing Time (minutes)",
        data: [45, 30, 60, 20, 50, 75, 55],
        borderColor: "hsl(var(--primary))",
        backgroundColor: "transparent",
        tension: 0.3,
      },
    ],
  }

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Word Count</CardTitle>
          <CardDescription>Your writing productivity over time</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="weekly">
            <TabsList className="mb-4">
              <TabsTrigger value="weekly">Weekly</TabsTrigger>
              <TabsTrigger value="monthly">Monthly</TabsTrigger>
            </TabsList>
            <TabsContent value="weekly">
              <BarChart data={weeklyData} height={300} />
            </TabsContent>
            <TabsContent value="monthly">
              <BarChart data={monthlyData} height={300} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Writing Time</CardTitle>
          <CardDescription>Hours spent writing each day</CardDescription>
        </CardHeader>
        <CardContent>
          <LineChart data={timeData} height={300} />
        </CardContent>
      </Card>
    </div>
  )
}
