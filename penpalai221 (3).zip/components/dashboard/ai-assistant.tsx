"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AIChat } from "@/components/editor/ai-chat"
import { ToneAnalyzer } from "@/components/editor/tone-analyzer"
import { ConsistencyChecker } from "@/components/editor/consistency-checker"
import { ChapterOutlineGenerator } from "@/components/editor/chapter-outline-generator"
import { MessageSquare, AlertTriangle, CheckCircle, Lightbulb, Sparkles } from "lucide-react"

interface AIAssistantProps {
  defaultTab?: "chat" | "tone" | "consistency" | "outline"
  className?: string
}

export function AIAssistant({ defaultTab = "chat", className }: AIAssistantProps) {
  const [content, setContent] = useState(
    `It was a cold winter morning when Sarah first discovered the ancient artifact. The small, metallic object seemed to pulse with an energy that defied explanation. As she held it in her palm, a warm sensation traveled up her arm, and for a brief moment, she thought she heard whispers—distant voices speaking in a language she couldn't understand.

"What are you?" she murmured, turning the artifact over to examine its intricate engravings.

The artifact had been buried beneath the old oak tree behind her grandmother's house. Sarah had been digging there on a whim, guided by a recurring dream that had plagued her for weeks. In the dream, she always found something important beneath that tree, something that would change everything.`,
  )

  return (
    <Tabs defaultValue={defaultTab} className={`space-y-4 ${className}`}>
      <TabsList>
        <TabsTrigger value="chat" className="flex items-center gap-2">
          <MessageSquare className="h-4 w-4" />
          AI Chat
        </TabsTrigger>
        <TabsTrigger value="tone" className="flex items-center gap-2">
          <AlertTriangle className="h-4 w-4" />
          Tone Analyzer
        </TabsTrigger>
        <TabsTrigger value="consistency" className="flex items-center gap-2">
          <CheckCircle className="h-4 w-4" />
          Consistency Checker
        </TabsTrigger>
        <TabsTrigger value="outline" className="flex items-center gap-2">
          <Lightbulb className="h-4 w-4" />
          Chapter Outline
        </TabsTrigger>
      </TabsList>

      <TabsContent value="chat" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              AI Writing Assistant
            </CardTitle>
            <CardDescription>
              Chat with our AI assistant to get help with your writing, brainstorm ideas, or overcome writer's block.
            </CardDescription>
          </CardHeader>
          <CardContent className="h-[600px]">
            <AIChat />
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="tone" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-primary" />
              Tone Analyzer
            </CardTitle>
            <CardDescription>
              Analyze the tone and emotional consistency of your writing to ensure it matches your intended style.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full min-h-[200px] p-3 border rounded-md resize-none focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="Paste your text here to analyze its tone..."
              />
            </div>
            <ToneAnalyzer content={content} />
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="consistency" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-primary" />
              Consistency Checker
            </CardTitle>
            <CardDescription>
              Check for inconsistencies in character names, plot points, and settings throughout your manuscript.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full min-h-[200px] p-3 border rounded-md resize-none focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="Paste your text here to check for consistency issues..."
              />
            </div>
            <ConsistencyChecker content={content} />
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="outline" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lightbulb className="h-5 w-5 text-primary" />
              Chapter Outline Generator
            </CardTitle>
            <CardDescription>
              Generate detailed chapter outlines for your book based on genre and title.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ChapterOutlineGenerator />
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  )
}
