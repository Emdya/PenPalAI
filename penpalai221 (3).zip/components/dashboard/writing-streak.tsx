import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Award, Calendar, Check, Trophy } from "lucide-react"

export function WritingStreak() {
  // Sample data for the calendar
  const today = new Date()
  const currentMonth = today.getMonth()
  const currentYear = today.getFullYear()

  // Generate days for the current month
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate()
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay()

  // Sample writing days (for demo purposes)
  const writingDays = [1, 2, 3, 5, 6, 10, 11, 12, 13, 14, 18, 19, 20, 21, 22, 23, 24, 25]

  // Sample achievements
  const achievements = [
    {
      title: "5-Day Streak",
      description: "Write for 5 consecutive days",
      icon: Award,
      earned: true,
      date: "Apr 25, 2025",
    },
    {
      title: "10K Words",
      description: "Write 10,000 words total",
      icon: Trophy,
      earned: true,
      date: "Apr 20, 2025",
    },
    {
      title: "First Chapter",
      description: "Complete your first chapter",
      icon: Check,
      earned: true,
      date: "Apr 15, 2025",
    },
    {
      title: "Consistent Writer",
      description: "Write for 20 days in a month",
      icon: Calendar,
      earned: false,
      progress: 18,
      total: 20,
    },
  ]

  // Generate calendar days
  const calendarDays = []
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

  // Add empty cells for days before the first day of the month
  for (let i = 0; i < firstDayOfMonth; i++) {
    calendarDays.push(null)
  }

  // Add days of the month
  for (let i = 1; i <= daysInMonth; i++) {
    calendarDays.push(i)
  }

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Writing Calendar</CardTitle>
          <CardDescription>Your writing activity this month</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2 text-center">
            {dayNames.map((day) => (
              <div key={day} className="text-xs font-medium text-muted-foreground py-1">
                {day}
              </div>
            ))}
            {calendarDays.map((day, index) => (
              <div
                key={index}
                className={`
                  aspect-square flex items-center justify-center rounded-md text-sm
                  ${!day ? "invisible" : ""}
                  ${writingDays.includes(day) ? "bg-primary text-primary-foreground" : "border"}
                  ${day === today.getDate() && !writingDays.includes(day) ? "border-primary" : ""}
                `}
              >
                {day}
              </div>
            ))}
          </div>
          <div className="mt-4 flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-sm bg-primary"></div>
              <span>Writing day</span>
            </div>
            <div>
              <span className="font-medium">{writingDays.length}</span> days this month
            </div>
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Achievements</CardTitle>
          <CardDescription>Milestones in your writing journey</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {achievements.map((achievement, index) => (
              <div key={index} className="flex items-start gap-3">
                <div
                  className={`rounded-full p-2 ${achievement.earned ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}
                >
                  <achievement.icon className="h-4 w-4" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">{achievement.title}</h4>
                    {achievement.earned ? (
                      <Badge variant="outline" className="text-xs">
                        Earned
                      </Badge>
                    ) : (
                      <span className="text-xs text-muted-foreground">In progress</span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{achievement.description}</p>
                  {achievement.earned ? (
                    <p className="text-xs text-muted-foreground mt-1">Earned on {achievement.date}</p>
                  ) : (
                    <div className="mt-1 flex items-center gap-2">
                      <div className="h-1.5 flex-1 rounded-full bg-muted">
                        <div
                          className="h-full rounded-full bg-primary"
                          style={{ width: `${(achievement.progress / achievement.total) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {achievement.progress}/{achievement.total}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
