import { cn } from "@/lib/utils"

export function GatsbyDivider({ className }: { className?: string }) {
  return <div className={cn("gatsby-divider", className)} />
}

export function GatsbyCorner({
  position = "top-left",
  className,
}: { position?: "top-left" | "top-right" | "bottom-left" | "bottom-right"; className?: string }) {
  const positionClasses = {
    "top-left": "top-0 left-0",
    "top-right": "top-0 right-0 rotate-90",
    "bottom-left": "bottom-0 left-0 -rotate-90",
    "bottom-right": "bottom-0 right-0 rotate-180",
  }

  return (
    <div className={cn("absolute w-12 h-12 pointer-events-none", positionClasses[position], className)}>
      <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0 0H24V2H2V24H0V0Z" fill="#d4af37" />
        <path d="M48 0H32V2H46V16H48V0Z" fill="#d4af37" />
        <path d="M0 48H16V46H2V32H0V48Z" fill="#d4af37" />
        <path d="M48 48H24V46H46V24H48V48Z" fill="#d4af37" />
      </svg>
    </div>
  )
}

export function GatsbyOrnament({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center justify-center my-4", className)}>
      <svg width="120" height="20" viewBox="0 0 120 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0 10H40" stroke="#d4af37" strokeWidth="1" />
        <path d="M80 10H120" stroke="#d4af37" strokeWidth="1" />
        <path d="M50 0L60 10L50 20M70 0L60 10L70 20" stroke="#d4af37" strokeWidth="1" />
        <circle cx="60" cy="10" r="4" fill="#d4af37" />
        <circle cx="40" cy="10" r="2" fill="#d4af37" />
        <circle cx="80" cy="10" r="2" fill="#d4af37" />
      </svg>
    </div>
  )
}
