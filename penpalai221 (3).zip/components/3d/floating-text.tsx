"use client"

import { useRef, useState, useEffect } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { Text, Float } from "@react-three/drei"
import type { Group } from "three"

function FloatingWord({ text, position, color = "#d4af37", ...props }: any) {
  const group = useRef<Group>(null)

  useFrame((state) => {
    if (!group.current) return
    const t = state.clock.getElapsedTime()
    group.current.position.y = position[1] + Math.sin(t + position[0]) / 10
  })

  return (
    <group ref={group} position={position} {...props}>
      <Text color={color} fontSize={0.5} font="/fonts/PlayfairDisplay-Bold.ttf" letterSpacing={0.1}>
        {text}
      </Text>
    </group>
  )
}

export function FloatingTextEffect() {
  const [mounted, setMounted] = useState(false)
  const words = ["Create", "Write", "Imagine", "Publish", "Dream", "Inspire"]

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="h-[200px] w-full absolute top-20 left-0 right-0 pointer-events-none">
      <Canvas camera={{ position: [0, 0, 5], fov: 75 }}>
        <ambientLight intensity={0.5} />
        <Float rotationIntensity={0.2} floatIntensity={2}>
          {words.map((word, i) => (
            <FloatingWord key={word} text={word} position={[((i % 3) - 1) * 2, Math.floor(i / 3) - 0.5, 0]} />
          ))}
        </Float>
      </Canvas>
    </div>
  )
}
