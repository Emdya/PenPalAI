"use client"

import { useRef, useState } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { PresentationControls, Environment, Float, ContactShadows, Box } from "@react-three/drei"
import { useSpring, animated } from "@react-spring/three"
import type { Group } from "three"
import { useBrowserEnvironment } from "@/lib/3d-utils"

// Animated Book component with opening functionality
function FallbackBook(props: any) {
  const group = useRef<Group>(null)
  const [isOpen, setIsOpen] = useState(false)
  const [hovered, setHovered] = useState(false)

  // Spring animation for book opening
  const { coverRotation, pagesRotation } = useSpring({
    coverRotation: isOpen ? Math.PI * 0.8 : 0,
    pagesRotation: isOpen ? Math.PI * 0.7 : 0,
    config: { mass: 4, tension: 400, friction: 50 },
  })

  // Continuous rotation animation
  useFrame((state) => {
    if (!group.current) return

    // Base continuous rotation
    group.current.rotation.y += 0.005

    // Additional subtle animations
    const t = state.clock.getElapsedTime()
    group.current.rotation.z = Math.sin(t / 4) / 20
    group.current.position.y = Math.sin(t / 2) / 10
  })

  return (
    <group
      ref={group}
      {...props}
      dispose={null}
      onClick={() => setIsOpen(!isOpen)}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      {/* Book back cover */}
      <Box args={[1.5, 2, 0.05]} position={[0, 0, -0.1]}>
        <meshStandardMaterial color="#D4AF37" metalness={0.4} roughness={0.6} />
      </Box>

      {/* Book spine */}
      <Box args={[0.2, 2, 0.2]} position={[-0.65, 0, 0]}>
        <meshStandardMaterial color="#D4AF37" metalness={0.4} roughness={0.6} />
      </Box>

      {/* Book pages */}
      <animated.group rotation-x={pagesRotation}>
        <Box args={[1.4, 1.9, 0.3]} position={[0.05, 0, 0]}>
          <meshStandardMaterial color="#f8f0e3" metalness={0.1} roughness={0.9} />
        </Box>
      </animated.group>

      {/* Book front cover */}
      <animated.group rotation-x={coverRotation} position={[0, 0, 0.2]}>
        <Box args={[1.5, 2, 0.05]} position={[0, 0, 0]}>
          <meshStandardMaterial color={hovered ? "#E5C158" : "#D4AF37"} metalness={0.4} roughness={0.6} />
        </Box>

        {/* Book title */}
        <Box args={[1, 0.3, 0.01]} position={[0, 0, 0.03]}>
          <meshStandardMaterial color="#4169E1" metalness={0.3} roughness={0.7} />
        </Box>
      </animated.group>
    </group>
  )
}

function Book(props: any) {
  return <FallbackBook {...props} />
}

export function BookModel() {
  const isBrowser = useBrowserEnvironment()

  if (!isBrowser) return null

  return (
    <div className="h-[400px] w-full cursor-pointer">
      <Canvas shadows camera={{ position: [0, 0, 4], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} castShadow />
        <PresentationControls
          global
          rotation={[0, 0, 0]}
          polar={[Number.NEGATIVE_INFINITY, Number.POSITIVE_INFINITY]}
          azimuth={[Number.NEGATIVE_INFINITY, Number.POSITIVE_INFINITY]}
          config={{ mass: 2, tension: 400 }}
          snap={false}
        >
          <Float rotationIntensity={0.2} floatIntensity={0.5}>
            <Book position={[0, 0.25, 0]} scale={0.8} />
          </Float>
        </PresentationControls>
        <ContactShadows position={[0, -1.4, 0]} opacity={0.75} scale={10} blur={2.5} far={4} />
        <Environment preset="city" />
      </Canvas>
    </div>
  )
}
