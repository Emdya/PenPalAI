"use client"

import { useRef } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { PresentationControls, Environment, Float, ContactShadows, Cylinder, Box } from "@react-three/drei"
import type { Group } from "three"
import { useBrowserEnvironment } from "@/lib/3d-utils"

// Fallback component when model can't be loaded
function FallbackQuill(props: any) {
  const group = useRef<Group>(null)

  // Animate the quill
  useFrame((state) => {
    if (!group.current) return

    // Continuous rotation
    group.current.rotation.y += 0.01

    // Additional animations
    const t = state.clock.getElapsedTime()
    group.current.rotation.z = Math.sin(t / 3) / 8
    group.current.position.y = Math.sin(t / 1.5) / 15
  })

  return (
    <group ref={group} {...props} dispose={null} rotation={[0, 0, Math.PI / 4]}>
      {/* Quill shaft */}
      <Cylinder args={[0.05, 0.02, 2, 8]} position={[0, 0, 0]}>
        <meshStandardMaterial color="#f8f0e3" metalness={0.1} roughness={0.9} />
      </Cylinder>
      {/* Quill tip */}
      <Box args={[0.1, 0.02, 0.3]} position={[0, -1.1, 0]}>
        <meshStandardMaterial color="#D4AF37" metalness={0.6} roughness={0.3} />
      </Box>
      {/* Decorative element */}
      <Box args={[0.08, 0.08, 0.08]} position={[0, 0.9, 0]}>
        <meshStandardMaterial color="#4169E1" metalness={0.4} roughness={0.6} />
      </Box>
    </group>
  )
}

function QuillPen(props: any) {
  // Always use the fallback since we know the model doesn't exist
  return <FallbackQuill {...props} />
}

export function QuillPenModel() {
  const isBrowser = useBrowserEnvironment()

  if (!isBrowser) return null

  return (
    <div className="h-[300px] w-full">
      <Canvas shadows camera={{ position: [0, 0, 4], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} castShadow />
        <PresentationControls
          global
          rotation={[0, 0, 0]}
          polar={[Number.NEGATIVE_INFINITY, Number.POSITIVE_INFINITY]}
          azimuth={[Number.NEGATIVE_INFINITY, Number.POSITIVE_INFINITY]}
          config={{ mass: 2, tension: 400 }}
          snap={false}
        >
          <Float rotationIntensity={0.4}>
            <QuillPen position={[0, 0.25, 0]} scale={0.8} />
          </Float>
        </PresentationControls>
        <ContactShadows position={[0, -1.4, 0]} opacity={0.75} scale={10} blur={2.5} far={4} />
        <Environment preset="sunset" />
      </Canvas>
    </div>
  )
}
