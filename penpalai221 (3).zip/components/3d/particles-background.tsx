"use client"

import { useRef, useMemo, useState, useEffect } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { PointMaterial } from "@react-three/drei"
import type * as THREE from "three"
import { useSpring, animated } from "@react-spring/three"

function Particles({ count = 2000 }) {
  const mesh = useRef<THREE.Points>(null)

  // Generate random positions for particles
  const particles = useMemo(() => {
    const temp = []
    for (let i = 0; i < count; i++) {
      const x = (Math.random() - 0.5) * 15
      const y = (Math.random() - 0.5) * 15
      const z = (Math.random() - 0.5) * 5
      temp.push({ x, y, z })
    }
    return temp
  }, [count])

  // Create positions array for Three.js
  const positions = useMemo(() => {
    const temp = new Float32Array(count * 3)
    particles.forEach(({ x, y, z }, i) => {
      temp[i * 3] = x
      temp[i * 3 + 1] = y
      temp[i * 3 + 2] = z
    })
    return temp
  }, [particles, count])

  useFrame((state) => {
    if (!mesh.current) return
    const t = state.clock.getElapsedTime() / 10
    mesh.current.rotation.x = Math.sin(t) * 0.2
    mesh.current.rotation.y = Math.cos(t) * 0.2
  })

  const [spring, api] = useSpring(() => ({
    scale: 1,
    config: { mass: 5, tension: 350, friction: 40 },
  }))

  useEffect(() => {
    const interval = setInterval(() => {
      api.start({ scale: Math.random() * 0.3 + 0.8 })
    }, 2000)
    return () => clearInterval(interval)
  }, [api])

  // Create two particle systems with different colors
  return (
    <>
      <animated.points ref={mesh} scale={spring.scale}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" count={positions.length / 3} array={positions} itemSize={3} />
        </bufferGeometry>
        <PointMaterial transparent color="#D4AF37" size={0.02} sizeAttenuation={true} depthWrite={false} />
      </animated.points>

      <animated.points scale={spring.scale}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={positions.length / 3}
            array={positions.map((v, i) => (i % 3 === 1 ? v + 0.5 : v))}
            itemSize={3}
          />
        </bufferGeometry>
        <PointMaterial transparent color="#4169E1" size={0.015} sizeAttenuation={true} depthWrite={false} />
      </animated.points>
    </>
  )
}

export function ParticlesBackground() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="fixed inset-0 -z-10">
      <Canvas camera={{ position: [0, 0, 5], fov: 75 }}>
        <Particles />
      </Canvas>
    </div>
  )
}
