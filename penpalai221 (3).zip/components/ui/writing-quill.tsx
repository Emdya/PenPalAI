"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { Feather } from "lucide-react"

export function WritingQuill() {
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [isWriting, setIsWriting] = useState(false)

  useEffect(() => {
    // Start writing animation
    const interval = setInterval(() => {
      setIsWriting((prev) => !prev)
    }, 3000)

    // Move quill around
    const moveInterval = setInterval(() => {
      setPosition({
        x: Math.random() * 80 + 10,
        y: Math.random() * 80 + 10,
      })
    }, 8000)

    return () => {
      clearInterval(interval)
      clearInterval(moveInterval)
    }
  }, [])

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      <motion.div
        className="absolute text-primary"
        style={{
          left: `${position.x}%`,
          top: `${position.y}%`,
        }}
        animate={{
          x: isWriting ? [0, 5, -3, 4, -2, 0] : 0,
          y: isWriting ? [0, 2, -2, 1, -1, 0] : 0,
          rotate: [0, 5, -3, 2, -1, 0],
        }}
        transition={{
          duration: isWriting ? 3 : 0.5,
          ease: "easeInOut",
        }}
      >
        <Feather size={32} />
        {isWriting && (
          <motion.div
            className="absolute -bottom-2 -right-2 w-1 h-1 bg-primary rounded-full"
            animate={{
              opacity: [0, 1, 0],
              y: [0, 10],
              x: [0, 5],
            }}
            transition={{
              duration: 0.5,
              repeat: 5,
              repeatType: "loop",
            }}
          />
        )}
      </motion.div>
    </div>
  )
}
