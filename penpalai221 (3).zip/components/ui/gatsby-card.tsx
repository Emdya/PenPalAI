import * as React from "react"
import { cn } from "@/lib/utils"

const GatsbyCard = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("gatsby-card rounded-lg p-6 animate-[slideUp_0.5s_ease-out]", className)} {...props} />
  ),
)
GatsbyCard.displayName = "GatsbyCard"

const GatsbyCardHeader = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("flex flex-col space-y-1.5 pb-4", className)} {...props} />
  ),
)
GatsbyCardHeader.displayName = "GatsbyCardHeader"

const GatsbyCardTitle = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLHeadingElement>>(
  ({ className, ...props }, ref) => (
    <h3
      ref={ref}
      className={cn("gatsby-heading text-2xl font-semibold leading-none tracking-tight text-[#0f2137]", className)}
      {...props}
    />
  ),
)
GatsbyCardTitle.displayName = "GatsbyCardTitle"

const GatsbyCardDescription = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLParagraphElement>>(
  ({ className, ...props }, ref) => <p ref={ref} className={cn("text-sm text-[#0f2137]/80", className)} {...props} />,
)
GatsbyCardDescription.displayName = "GatsbyCardDescription"

const GatsbyCardContent = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => <div ref={ref} className={cn("pt-0", className)} {...props} />,
)
GatsbyCardContent.displayName = "GatsbyCardContent"

const GatsbyCardFooter = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => <div ref={ref} className={cn("flex items-center pt-4", className)} {...props} />,
)
GatsbyCardFooter.displayName = "GatsbyCardFooter"

export { GatsbyCard, GatsbyCardHeader, GatsbyCardFooter, GatsbyCardTitle, GatsbyCardDescription, GatsbyCardContent }
