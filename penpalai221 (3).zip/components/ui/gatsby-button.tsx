import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "gatsby-button inline-flex items-center justify-center whitespace-nowrap text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "bg-[#d4af37] text-[#0a0a0a] hover:bg-[#b8860b]",
        outline: "border border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37]/10",
        secondary: "bg-[#0f2137] text-[#f8f0e3] hover:bg-[#0f2137]/80",
        ghost: "text-[#d4af37] hover:bg-[#d4af37]/10",
        link: "text-[#d4af37] underline-offset-4 hover:underline",
        destructive: "bg-[#800020] text-[#f8f0e3] hover:bg-[#800020]/90",
      },
      shape: {
        default: "rounded-md",
        diamond: "gatsby-button-diamond",
        hexagon: "gatsby-button-hexagon",
        scalloped: "gatsby-button-scalloped rounded-full",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 px-3",
        lg: "h-11 px-8",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      shape: "default",
      size: "default",
    },
  },
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const GatsbyButton = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, shape, size, asChild = false, ...props }, ref) => {
    return <button className={cn(buttonVariants({ variant, shape, size, className }))} ref={ref} {...props} />
  },
)
GatsbyButton.displayName = "GatsbyButton"

export { GatsbyButton, buttonVariants }
