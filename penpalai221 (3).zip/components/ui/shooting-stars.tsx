"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

interface Star {
  id: number
  size: number
  duration: number
  delay: number
  top: number
  left: number
}

export function ShootingStars() {
  const [stars, setStars] = useState<Star[]>([])

  useEffect(() => {
    // Generate random stars
    const newStars = Array.from({ length: 15 }, (_, i) => ({
      id: i,
      size: Math.random() * 2 + 1,
      duration: Math.random() * 2 + 1,
      delay: Math.random() * 5,
      top: Math.random() * 100,
      left: Math.random() * 100,
    }))

    setStars(newStars)

    // Regenerate stars periodically
    const interval = setInterval(() => {
      setStars((prevStars) => {
        const updatedStars = [...prevStars]
        const randomIndex = Math.floor(Math.random() * updatedStars.length)
        updatedStars[randomIndex] = {
          ...updatedStars[randomIndex],
          delay: 0,
          top: Math.random() * 100,
          left: Math.random() * 100,
        }
        return updatedStars
      })
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {stars.map((star) => (
        <motion.div
          key={star.id}
          className="absolute bg-yellow-300 rounded-full z-0"
          style={{
            width: star.size,
            height: star.size,
            top: `${star.top}%`,
            left: `${star.left}%`,
            boxShadow: `0 0 ${star.size * 2}px ${star.size}px rgba(255, 255, 0, 0.7)`,
          }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{
            opacity: [0, 1, 0],
            scale: [0, 1, 0],
            x: [0, Math.random() * 200 - 100],
            y: [0, Math.random() * 200 - 100],
          }}
          transition={{
            duration: star.duration,
            delay: star.delay,
            repeat: Number.POSITIVE_INFINITY,
            repeatDelay: Math.random() * 10 + 5,
          }}
        />
      ))}
    </div>
  )
}
