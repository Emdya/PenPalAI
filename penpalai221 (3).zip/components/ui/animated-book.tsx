"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Sparkles } from "lucide-react"
import { cn } from "@/lib/utils"

interface AnimatedBookProps {
  className?: string
  autoAnimate?: boolean
  interval?: number
  onOpen?: () => void
  onClose?: () => void
}

export function AnimatedBook({ className, autoAnimate = false, interval = 5000, onOpen, onClose }: AnimatedBookProps) {
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    if (!autoAnimate) return

    const timer = setInterval(() => {
      setIsOpen((prev) => !prev)
      if (!isOpen) {
        onOpen?.()
      } else {
        onClose?.()
      }
    }, interval)

    return () => clearInterval(timer)
  }, [autoAnimate, interval, isOpen, onOpen, onClose])

  const handleClick = () => {
    setIsOpen((prev) => !prev)
    if (!isOpen) {
      onOpen?.()
    } else {
      onClose?.()
    }
  }

  return (
    <div
      className={cn("relative w-[300px] h-[400px] cursor-pointer select-none mx-auto", className)}
      onClick={handleClick}
    >
      {/* Book spine */}
      <div className="absolute left-1/2 top-0 h-full w-4 -ml-2 bg-primary rounded-sm z-10" />

      {/* Left page (back cover) */}
      <motion.div
        className="absolute left-0 top-0 w-[150px] h-full bg-gradient-to-r from-primary/90 to-primary rounded-l-lg shadow-lg flex items-center justify-center"
        animate={{
          rotateY: isOpen ? -180 : 0,
          boxShadow: isOpen ? "0px 10px 15px -3px rgba(0, 0, 0, 0.1)" : "0px 4px 6px -1px rgba(0, 0, 0, 0.1)",
        }}
        transition={{ duration: 0.8, ease: "easeInOut" }}
        style={{ transformOrigin: "right center", backfaceVisibility: "hidden" }}
      >
        <div
          className="text-primary-foreground text-center p-6 transform rotate-180"
          style={{ writingMode: "vertical-lr" }}
        >
          <h3 className="text-xl font-bold mb-2">PenPal AI</h3>
          <p className="text-sm">Your AI writing companion</p>
        </div>
      </motion.div>

      {/* Left page (inside) */}
      <motion.div
        className="absolute left-0 top-0 w-[150px] h-full bg-background border-r border-primary/20 rounded-l-lg flex items-center justify-center"
        initial={{ rotateY: 180 }}
        animate={{
          rotateY: isOpen ? 0 : 180,
          boxShadow: isOpen ? "0px 4px 6px -1px rgba(0, 0, 0, 0.1)" : "none",
        }}
        transition={{ duration: 0.8, ease: "easeInOut" }}
        style={{ transformOrigin: "right center", backfaceVisibility: "hidden" }}
      >
        <div className="p-4 text-sm">
          <h4 className="font-medium mb-2 flex items-center gap-1">
            <Sparkles className="h-3 w-3 text-primary" /> AI Features
          </h4>
          <ul className="space-y-1 text-xs text-muted-foreground">
            <li>• Real-time suggestions</li>
            <li>• Chapter outlines</li>
            <li>• Character development</li>
            <li>• Plot assistance</li>
            <li>• Tone analysis</li>
            <li>• Consistency checking</li>
          </ul>
        </div>
      </motion.div>

      {/* Right page (inside) */}
      <motion.div
        className="absolute right-0 top-0 w-[150px] h-full bg-background border-l border-primary/20 rounded-r-lg flex items-center justify-center"
        animate={{
          rotateY: isOpen ? 0 : -180,
          boxShadow: isOpen ? "0px 4px 6px -1px rgba(0, 0, 0, 0.1)" : "none",
        }}
        transition={{ duration: 0.8, ease: "easeInOut" }}
        style={{ transformOrigin: "left center", backfaceVisibility: "hidden" }}
      >
        <div className="p-4 text-sm">
          <h4 className="font-medium mb-2">Writing Tools</h4>
          <div className="space-y-2 text-xs text-muted-foreground">
            <p>Start your writing journey with powerful AI-assisted tools designed for authors.</p>
            <p>Track progress, collaborate with others, and publish with ease.</p>
          </div>
        </div>
      </motion.div>

      {/* Right page (front cover) */}
      <motion.div
        className="absolute right-0 top-0 w-[150px] h-full bg-gradient-to-l from-primary/90 to-primary rounded-r-lg shadow-lg flex items-center justify-center overflow-hidden"
        initial={{ rotateY: 0 }}
        animate={{
          rotateY: isOpen ? 180 : 0,
          boxShadow: isOpen ? "none" : "0px 10px 15px -3px rgba(0, 0, 0, 0.1)",
        }}
        transition={{ duration: 0.8, ease: "easeInOut" }}
        style={{ transformOrigin: "left center", backfaceVisibility: "hidden" }}
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-primary-foreground text-center p-6">
            <Sparkles className="h-10 w-10 mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">PenPal AI</h3>
            <p className="text-sm">Click to open</p>
          </div>
        </div>
      </motion.div>

      {/* Hint text */}
      <div className="absolute -bottom-8 left-0 right-0 text-center text-xs text-muted-foreground">
        {isOpen ? "Click to close the book" : "Click to open the book"}
      </div>
    </div>
  )
}
