"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

interface FloatingBooksProps {
  count?: number
}

export function FloatingBooks({ count = 3 }: FloatingBooksProps) {
  const [books, setBooks] = useState<
    { id: number; x: number; y: number; rotation: number; scale: number; delay: number }[]
  >([])

  useEffect(() => {
    const newBooks = Array.from({ length: count }).map((_, index) => ({
      id: index,
      x: Math.random() * 100,
      y: Math.random() * 100,
      rotation: Math.random() * 20 - 10,
      scale: 0.5 + Math.random() * 0.5,
      delay: Math.random() * 5,
    }))
    setBooks(newBooks)
  }, [count])

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {books.map((book) => (
        <motion.div
          key={book.id}
          className="absolute"
          style={{
            left: `${book.x}%`,
            top: `${book.y}%`,
            zIndex: -1,
          }}
          initial={{ y: 20, opacity: 0, rotate: book.rotation, scale: book.scale }}
          animate={{
            y: [20, -20, 20],
            opacity: [0, 1, 0],
            rotate: [book.rotation, book.rotation + 5, book.rotation],
          }}
          transition={{
            duration: 15 + Math.random() * 10,
            repeat: Number.POSITIVE_INFINITY,
            delay: book.delay,
            ease: "easeInOut",
          }}
        >
          <BookIcon className="w-16 h-16 text-amber-200/30" />
        </motion.div>
      ))}
    </div>
  )
}

function BookIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="currentColor"
      stroke="none"
    >
      <path d="M19 2H6c-1.206 0-3 0.799-3 3v14c0 2.201 1.794 3 3 3h15v-2H6.012C5.55 19.988 5 19.806 5 19s0.55-0.988 1.012-1H21V4c0-1.103-0.897-2-2-2zm0 14H5V5c0-0.806 0.55-1 1-1h13v12z" />
    </svg>
  )
}
