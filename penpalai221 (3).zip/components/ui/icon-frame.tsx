import { cn } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"

interface IconFrameProps {
  icon: LucideIcon
  className?: string
}

export function IconFrame({ icon: Icon, className }: IconFrameProps) {
  return (
    <div className={cn("relative flex items-center justify-center w-24 h-24", className)}>
      {/* Decorative frame */}
      <div className="absolute w-20 h-20">
        <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-[#D4AF37]"></div>
        <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-[#D4AF37]"></div>
        <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-[#D4AF37]"></div>
        <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-[#D4AF37]"></div>
      </div>
      {/* Icon */}
      <Icon className="h-12 w-12 text-[#D4AF37]/40 group-hover:text-[#D4AF37]/60 transition-all duration-500 z-10" />
    </div>
  )
}
