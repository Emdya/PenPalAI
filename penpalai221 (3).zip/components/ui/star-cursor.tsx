"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"

interface SparkleProps {
  x: number
  y: number
  size: number
  color: string
  delay: number
  duration: number
}

const Sparkle = ({ x, y, size, color, delay, duration }: SparkleProps) => {
  return (
    <motion.div
      className="absolute pointer-events-none"
      style={{
        left: x,
        top: y,
        width: size,
        height: size,
        backgroundColor: color,
        borderRadius: "50%",
      }}
      initial={{ opacity: 0.8, scale: 0 }}
      animate={{ opacity: 0, scale: 1 }}
      transition={{ delay, duration }}
    />
  )
}

export function StarCursor() {
  const [mousePosition, setMousePosition] = useState({ x: -100, y: -100 })
  const [sparkles, setSparkles] = useState<SparkleProps[]>([])
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    // Show cursor after a short delay to prevent initial flash
    const timer = setTimeout(() => setIsVisible(true), 500)

    const updateMousePosition = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })

      // Add a new sparkle with random properties
      if (Math.random() > 0.6) {
        const newSparkle = {
          id: Date.now(),
          x: e.clientX + (Math.random() * 10 - 5),
          y: e.clientY + (Math.random() * 10 - 5),
          size: Math.random() * 6 + 2,
          color: Math.random() > 0.5 ? "#D4AF37" : "#FFD700",
          delay: 0,
          duration: Math.random() * 0.8 + 0.2,
        }

        setSparkles((prev) => [...prev.slice(-15), newSparkle])
      }
    }

    window.addEventListener("mousemove", updateMousePosition)

    return () => {
      window.removeEventListener("mousemove", updateMousePosition)
      clearTimeout(timer)
    }
  }, [])

  // Clean up old sparkles
  useEffect(() => {
    const interval = setInterval(() => {
      setSparkles((prev) => prev.slice(-15))
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  if (!isVisible) return null

  return (
    <div className="fixed inset-0 pointer-events-none z-50">
      {/* Star cursor */}
      <div
        className="absolute pointer-events-none"
        style={{
          left: mousePosition.x - 12,
          top: mousePosition.y - 12,
          width: 24,
          height: 24,
          transform: "translate(-50%, -50%)",
          zIndex: 9999,
        }}
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M12 0L14.59 8.26L23.41 8.26L16.41 13.48L19.03 21.74L12 16.52L4.97 21.74L7.59 13.48L0.59 8.26L9.41 8.26L12 0Z"
            fill="#D4AF37"
          />
        </svg>
      </div>

      {/* Sparkle trail */}
      <AnimatePresence>
        {sparkles.map((sparkle, i) => (
          <Sparkle key={i} {...sparkle} />
        ))}
      </AnimatePresence>
    </div>
  )
}
