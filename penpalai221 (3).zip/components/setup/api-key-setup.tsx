"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, AlertCircle, Key, Sparkles, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface ApiKey {
  name: string
  key: string
  description: string
  isSet: boolean
  isRequired: boolean
  placeholder: string
  link: string
}

export function ApiKeySetup() {
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([
    {
      name: "OPENAI_API_KEY",
      key: "",
      description: "Required for AI writing assistance, tone analysis, and chapter generation",
      isSet: false,
      isRequired: true,
      placeholder: "sk-...",
      link: "https://platform.openai.com/account/api-keys",
    },
    {
      name: "NEXTAUTH_SECRET",
      key: "",
      description: "Required for secure user authentication",
      isSet: false,
      isRequired: true,
      placeholder: "Generate a random string",
      link: "https://next-auth.js.org/configuration/options#secret",
    },
  ])

  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    checkApiKeys()
  }, [])

  const checkApiKeys = async () => {
    setIsLoading(true)

    try {
      // In a real app, you would fetch this from an API endpoint
      // For now, we'll simulate it
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Simulate checking environment variables
      const updatedKeys = [...apiKeys]
      updatedKeys[0].isSet = process.env.NEXT_PUBLIC_DEMO_MODE === "true" || !!process.env.OPENAI_API_KEY
      updatedKeys[1].isSet = process.env.NEXT_PUBLIC_DEMO_MODE === "true" || !!process.env.NEXTAUTH_SECRET

      setApiKeys(updatedKeys)
    } catch (error) {
      console.error("Error checking API keys:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSaveApiKeys = async () => {
    setIsSaving(true)

    try {
      // In a real app, you would send this to an API endpoint
      // For now, we'll simulate it
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Simulate saving environment variables
      const updatedKeys = apiKeys.map((key) => ({
        ...key,
        isSet: key.key.trim() !== "" || key.isSet,
      }))

      setApiKeys(updatedKeys)

      toast({
        title: "API keys saved",
        description: "Your API keys have been saved successfully",
      })
    } catch (error) {
      console.error("Error saving API keys:", error)
      toast({
        title: "Error",
        description: "Failed to save API keys. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleGenerateSecret = () => {
    // Generate a random string for NEXTAUTH_SECRET
    const randomSecret = Array.from(crypto.getRandomValues(new Uint8Array(32)))
      .map((byte) => byte.toString(16).padStart(2, "0"))
      .join("")

    const updatedKeys = [...apiKeys]
    const secretKeyIndex = updatedKeys.findIndex((key) => key.name === "NEXTAUTH_SECRET")

    if (secretKeyIndex !== -1) {
      updatedKeys[secretKeyIndex].key = randomSecret
      setApiKeys(updatedKeys)
    }
  }

  const handleInputChange = (index: number, value: string) => {
    const updatedKeys = [...apiKeys]
    updatedKeys[index].key = value
    setApiKeys(updatedKeys)
  }

  if (isLoading) {
    return (
      <div className="flex justify-center py-6">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  const allRequired = apiKeys.filter((key) => key.isRequired)
  const allRequiredSet = allRequired.every((key) => key.isSet)

  return (
    <div className="space-y-6">
      {allRequiredSet ? (
        <Alert className="bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-900">
          <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
          <AlertTitle>All required API keys are set</AlertTitle>
          <AlertDescription>Your application is ready to use all AI features</AlertDescription>
        </Alert>
      ) : (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Missing required API keys</AlertTitle>
          <AlertDescription>
            Some required API keys are not set. Please add them below to enable all features.
          </AlertDescription>
        </Alert>
      )}

      <div className="space-y-4">
        {apiKeys.map((apiKey, index) => (
          <div key={apiKey.name} className="space-y-2 p-4 rounded-lg border">
            <div className="flex items-center justify-between">
              <Label htmlFor={apiKey.name} className="text-base font-medium flex items-center gap-2">
                <Key className="h-4 w-4 text-primary" />
                {apiKey.name}
                {apiKey.isRequired && <span className="text-red-500">*</span>}
              </Label>
              {apiKey.isSet && (
                <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full flex items-center gap-1">
                  <CheckCircle className="h-3 w-3" />
                  Set
                </span>
              )}
            </div>
            <p className="text-sm text-muted-foreground">{apiKey.description}</p>
            <div className="flex gap-2">
              <div className="flex-1">
                <Input
                  id={apiKey.name}
                  type="password"
                  placeholder={apiKey.placeholder}
                  value={apiKey.key}
                  onChange={(e) => handleInputChange(index, e.target.value)}
                  className="font-mono"
                />
              </div>
              {apiKey.name === "NEXTAUTH_SECRET" && (
                <Button type="button" variant="outline" onClick={handleGenerateSecret} className="whitespace-nowrap">
                  Generate
                </Button>
              )}
            </div>
            <div className="text-xs text-muted-foreground">
              <a
                href={apiKey.link}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:underline flex items-center gap-1"
              >
                <Sparkles className="h-3 w-3" />
                Get {apiKey.name}
              </a>
            </div>
          </div>
        ))}
      </div>

      <Button onClick={handleSaveApiKeys} disabled={isSaving || apiKeys.every((key) => !key.key)} className="w-full">
        {isSaving ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Saving...
          </>
        ) : (
          "Save API Keys"
        )}
      </Button>
    </div>
  )
}
