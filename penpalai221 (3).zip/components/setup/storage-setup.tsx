"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, HardDrive, Upload, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

export function StorageSetup() {
  const [storageType, setStorageType] = useState<"local" | "s3" | "vercel-blob">("local")
  const [isConfigured, setIsConfigured] = useState(false)
  const [isChecking, setIsChecking] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    checkStorageConfiguration()
  }, [])

  const checkStorageConfiguration = async () => {
    setIsChecking(true)

    try {
      // In a real app, you would fetch this from an API endpoint
      // For now, we'll simulate it
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Simulate checking storage configuration
      const isConfigured = process.env.NEXT_PUBLIC_DEMO_MODE === "true"

      setIsConfigured(isConfigured)
    } catch (error) {
      console.error("Error checking storage configuration:", error)
    } finally {
      setIsChecking(false)
    }
  }

  const handleSaveConfiguration = async () => {
    setIsSaving(true)

    try {
      // In a real app, you would send this to an API endpoint
      // For now, we'll simulate it
      await new Promise((resolve) => setTimeout(resolve, 1500))

      setIsConfigured(true)

      toast({
        title: "Storage configured",
        description: `Storage configured successfully using ${storageType} storage`,
      })
    } catch (error) {
      console.error("Error saving storage configuration:", error)
      toast({
        title: "Error",
        description: "Failed to save storage configuration. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleTestUpload = async () => {
    try {
      toast({
        title: "Upload test",
        description: "Testing file upload...",
      })

      // In a real app, you would test the upload
      // For now, we'll simulate it
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "Upload successful",
        description: "Test file uploaded successfully",
      })
    } catch (error) {
      console.error("Error testing upload:", error)
      toast({
        title: "Error",
        description: "Failed to test upload. Please check your configuration.",
        variant: "destructive",
      })
    }
  }

  if (isChecking) {
    return (
      <div className="flex justify-center py-6">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {isConfigured ? (
        <Alert className="bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-900">
          <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
          <AlertTitle>Storage Configured</AlertTitle>
          <AlertDescription>
            Your storage is configured and ready to use
            <div className="mt-2">
              <Button variant="outline" size="sm" onClick={handleTestUpload} className="flex items-center gap-1">
                <Upload className="h-3 w-3" />
                Test Upload
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      ) : (
        <Alert
          variant="default"
          className="bg-yellow-50 border-yellow-200 dark:bg-yellow-900/20 dark:border-yellow-900"
        >
          <HardDrive className="h-4 w-4 text-yellow-600 dark:text-yellow-400" />
          <AlertTitle>Storage Configuration Required</AlertTitle>
          <AlertDescription>Configure storage for book covers and user uploads</AlertDescription>
        </Alert>
      )}

      <div className="space-y-4">
        <div>
          <Label className="text-base font-medium">Storage Type</Label>
          <RadioGroup
            value={storageType}
            onValueChange={(value) => setStorageType(value as "local" | "s3" | "vercel-blob")}
            className="grid grid-cols-3 gap-4 mt-2"
          >
            <div>
              <RadioGroupItem value="local" id="local" className="peer sr-only" />
              <Label
                htmlFor="local"
                className="flex flex-col items-center justify-between rounded-md border-2 border-muted p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary"
              >
                <HardDrive className="mb-3 h-6 w-6" />
                <span className="text-center font-medium">Local Storage</span>
              </Label>
            </div>
            <div>
              <RadioGroupItem value="s3" id="s3" className="peer sr-only" />
              <Label
                htmlFor="s3"
                className="flex flex-col items-center justify-between rounded-md border-2 border-muted p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary"
              >
                <svg className="mb-3 h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M12 4L3 9L12 14L21 9L12 4Z"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M3 14L12 19L21 14"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                <span className="text-center font-medium">Amazon S3</span>
              </Label>
            </div>
            <div>
              <RadioGroupItem value="vercel-blob" id="vercel-blob" className="peer sr-only" />
              <Label
                htmlFor="vercel-blob"
                className="flex flex-col items-center justify-between rounded-md border-2 border-muted p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary"
              >
                <svg className="mb-3 h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M12 22L2 12L12 2L22 12L12 22Z"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                <span className="text-center font-medium">Vercel Blob</span>
              </Label>
            </div>
          </RadioGroup>
        </div>

        {storageType === "s3" && (
          <div className="space-y-4 p-4 rounded-lg border">
            <div className="space-y-2">
              <Label htmlFor="aws-access-key">AWS Access Key</Label>
              <Input id="aws-access-key" type="password" placeholder="AWS Access Key" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="aws-secret-key">AWS Secret Key</Label>
              <Input id="aws-secret-key" type="password" placeholder="AWS Secret Key" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="aws-bucket">S3 Bucket Name</Label>
              <Input id="aws-bucket" placeholder="my-bucket" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="aws-region">AWS Region</Label>
              <Input id="aws-region" placeholder="us-east-1" />
            </div>
          </div>
        )}

        {storageType === "vercel-blob" && (
          <div className="space-y-4 p-4 rounded-lg border">
            <div className="space-y-2">
              <Label htmlFor="blob-read-key">Vercel Blob Read API Key</Label>
              <Input id="blob-read-key" type="password" placeholder="Vercel Blob Read API Key" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="blob-write-key">Vercel Blob Write API Key</Label>
              <Input id="blob-write-key" type="password" placeholder="Vercel Blob Write API Key" />
            </div>
          </div>
        )}

        {storageType === "local" && (
          <div className="p-4 rounded-lg border">
            <p className="text-sm text-muted-foreground">
              Local storage will save files to the server's filesystem. This is suitable for development but not
              recommended for production.
            </p>
          </div>
        )}

        <Button onClick={handleSaveConfiguration} disabled={isSaving} className="w-full">
          {isSaving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            "Save Storage Configuration"
          )}
        </Button>
      </div>
    </div>
  )
}
