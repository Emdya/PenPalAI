"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, AlertCircle, Database, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export function DatabaseSetup() {
  const [isChecking, setIsChecking] = useState(true)
  const [isConnected, setIsConnected] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    checkDatabaseConnection()
  }, [])

  const checkDatabaseConnection = async () => {
    setIsChecking(true)
    setError(null)

    try {
      // In a real app, you would fetch this from an API endpoint
      // For now, we'll simulate it
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Simulate checking database connection
      const isConnected = process.env.NEXT_PUBLIC_DEMO_MODE === "true" || !!process.env.DATABASE_URL

      setIsConnected(isConnected)

      if (isConnected) {
        toast({
          title: "Database connected",
          description: "Successfully connected to the database",
        })
      }
    } catch (error) {
      console.error("Error checking database connection:", error)
      setError(error instanceof Error ? error.message : "Failed to check database connection")
      toast({
        title: "Error",
        description: "Failed to connect to the database. Please check your connection string.",
        variant: "destructive",
      })
    } finally {
      setIsChecking(false)
    }
  }

  if (isChecking) {
    return (
      <div className="flex items-center justify-center py-6">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Checking database connection...</span>
      </div>
    )
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Connection Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
        <Button variant="outline" size="sm" onClick={checkDatabaseConnection} className="mt-2">
          Try Again
        </Button>
      </Alert>
    )
  }

  if (isConnected) {
    return (
      <Alert className="bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-900">
        <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
        <AlertTitle>Database Connected</AlertTitle>
        <AlertDescription>Successfully connected to the database. You can now initialize the schema.</AlertDescription>
      </Alert>
    )
  }

  return (
    <Alert variant="default" className="bg-yellow-50 border-yellow-200 dark:bg-yellow-900/20 dark:border-yellow-900">
      <Database className="h-4 w-4 text-yellow-600 dark:text-yellow-400" />
      <AlertTitle>Database Configuration Required</AlertTitle>
      <AlertDescription>
        Please add your DATABASE_URL environment variable to connect to your database.
        <div className="mt-2">
          <Button variant="outline" size="sm" onClick={checkDatabaseConnection}>
            Check Connection
          </Button>
        </div>
      </AlertDescription>
    </Alert>
  )
}
