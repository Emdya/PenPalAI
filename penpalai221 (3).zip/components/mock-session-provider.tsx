"use client"

import { createContext, useContext, useState, useEffect } from "react"
import type React from "react"

// Define the session type
type Session = {
  user: {
    id: string
    name: string
    email: string
  }
}

// Create a context for the mock session
const MockSessionContext = createContext<{
  session: Session | null
  status: "loading" | "authenticated" | "unauthenticated"
}>({
  session: null,
  status: "loading",
})

// Hook to use the mock session
export const useMockSession = () => useContext(MockSessionContext)

// Mock session provider component
export function MockSessionProvider({ children }: { children: React.ReactNode }) {
  const [status, setStatus] = useState<"loading" | "authenticated" | "unauthenticated">("loading")
  const [session, setSession] = useState<Session | null>(null)

  useEffect(() => {
    // Simulate loading the session
    const timer = setTimeout(() => {
      // For development, always provide a mock session
      setSession({
        user: {
          id: "1",
          name: "Demo User",
          email: "demo@example.com",
        },
      })
      setStatus("authenticated")
    }, 500)

    return () => clearTimeout(timer)
  }, [])

  return <MockSessionContext.Provider value={{ session, status }}>{children}</MockSessionContext.Provider>
}
