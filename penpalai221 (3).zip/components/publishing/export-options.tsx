"use client"

import { useState } from "react"
import { FileText, Download, Settings, CheckCircle } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { GatsbyButton } from "@/components/ui/gatsby-button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface ExportOptionsProps {
  selectedBook: string
}

export function ExportOptions({ selectedBook }: ExportOptionsProps) {
  const [exportFormat, setExportFormat] = useState("epub")
  const [includeCovers, setIncludeCovers] = useState(true)
  const [includeTOC, setIncludeTOC] = useState(true)
  const [pageSize, setPageSize] = useState("6x9")
  const [fontFamily, setFontFamily] = useState("garamond")
  const [fontSize, setFontSize] = useState("12")
  const [lineSpacing, setLineSpacing] = useState("1.5")
  const [margins, setMargins] = useState("normal")
  const [isExporting, setIsExporting] = useState(false)
  const [exportComplete, setExportComplete] = useState(false)

  const handleExport = () => {
    setIsExporting(true)
    // Simulate export process
    setTimeout(() => {
      setIsExporting(false)
      setExportComplete(true)
      setTimeout(() => setExportComplete(false), 3000)
    }, 2000)
  }

  return (
    <Card className="h-full border-none bg-gradient-to-br from-blue-50/50 to-purple-50/50 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Download className="h-5 w-5 text-purple-600" />
          Export Options
        </CardTitle>
        <CardDescription>Configure export settings for "{selectedBook}"</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="format" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="format" className="text-sm">
              <FileText className="w-4 h-4 mr-2" />
              Format Options
            </TabsTrigger>
            <TabsTrigger value="advanced" className="text-sm">
              <Settings className="w-4 h-4 mr-2" />
              Advanced Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="format" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="export-format">Export Format</Label>
                <Select value={exportFormat} onValueChange={setExportFormat}>
                  <SelectTrigger id="export-format">
                    <SelectValue placeholder="Select format" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="epub">EPUB (E-book)</SelectItem>
                    <SelectItem value="pdf">PDF (Print-ready)</SelectItem>
                    <SelectItem value="mobi">MOBI (Kindle)</SelectItem>
                    <SelectItem value="docx">DOCX (Word)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="page-size">Page Size</Label>
                <Select value={pageSize} onValueChange={setPageSize}>
                  <SelectTrigger id="page-size">
                    <SelectValue placeholder="Select page size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5x8">5" x 8" (Pocket)</SelectItem>
                    <SelectItem value="6x9">6" x 9" (Standard)</SelectItem>
                    <SelectItem value="7x10">7" x 10" (Large)</SelectItem>
                    <SelectItem value="8.5x11">8.5" x 11" (Letter)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-4 bg-white/70 p-4 rounded-lg border border-purple-100">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="include-covers">Include Cover Images</Label>
                  <p className="text-xs text-muted-foreground">Front and back covers will be included</p>
                </div>
                <Switch id="include-covers" checked={includeCovers} onCheckedChange={setIncludeCovers} />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="include-toc">Include Table of Contents</Label>
                  <p className="text-xs text-muted-foreground">Generate a linked table of contents</p>
                </div>
                <Switch id="include-toc" checked={includeTOC} onCheckedChange={setIncludeTOC} />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="advanced" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="font-family">Font Family</Label>
                <Select value={fontFamily} onValueChange={setFontFamily}>
                  <SelectTrigger id="font-family">
                    <SelectValue placeholder="Select font" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="times">Times New Roman</SelectItem>
                    <SelectItem value="garamond">Garamond</SelectItem>
                    <SelectItem value="georgia">Georgia</SelectItem>
                    <SelectItem value="baskerville">Baskerville</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="font-size">Font Size</Label>
                <Select value={fontSize} onValueChange={setFontSize}>
                  <SelectTrigger id="font-size">
                    <SelectValue placeholder="Select size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10pt</SelectItem>
                    <SelectItem value="11">11pt</SelectItem>
                    <SelectItem value="12">12pt</SelectItem>
                    <SelectItem value="14">14pt</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="line-spacing">Line Spacing</Label>
                <Select value={lineSpacing} onValueChange={setLineSpacing}>
                  <SelectTrigger id="line-spacing">
                    <SelectValue placeholder="Select spacing" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Single (1.0)</SelectItem>
                    <SelectItem value="1.15">Narrow (1.15)</SelectItem>
                    <SelectItem value="1.5">Medium (1.5)</SelectItem>
                    <SelectItem value="2">Double (2.0)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="margins">Margins</Label>
                <Select value={margins} onValueChange={setMargins}>
                  <SelectTrigger id="margins">
                    <SelectValue placeholder="Select margins" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="narrow">Narrow (0.5")</SelectItem>
                    <SelectItem value="normal">Normal (1")</SelectItem>
                    <SelectItem value="wide">Wide (1.5")</SelectItem>
                    <SelectItem value="mirrored">Mirrored</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2 bg-white/70 p-4 rounded-lg border border-purple-100">
              <h3 className="text-sm font-medium">Additional Options</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="page-numbers">Include Page Numbers</Label>
                  <Switch id="page-numbers" defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="chapter-breaks">Chapter Page Breaks</Label>
                  <Switch id="chapter-breaks" defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="hyphenation">Enable Hyphenation</Label>
                  <Switch id="hyphenation" />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="justified-text">Justified Text</Label>
                  <Switch id="justified-text" defaultChecked />
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter>
        <GatsbyButton className="w-full relative" onClick={handleExport} disabled={isExporting}>
          {isExporting ? (
            <span className="flex items-center">
              <svg
                className="animate-spin -ml-1 mr-3 h-4 w-4 text-white"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                ></path>
              </svg>
              Exporting...
            </span>
          ) : (
            <span className="flex items-center">
              {exportComplete ? (
                <>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Export Complete!
                </>
              ) : (
                <>
                  <Download className="mr-2 h-4 w-4" />
                  Export {selectedBook}
                </>
              )}
            </span>
          )}
        </GatsbyButton>
      </CardFooter>
    </Card>
  )
}
