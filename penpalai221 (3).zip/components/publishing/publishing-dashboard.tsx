"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { BookOpen, Download, FileText, Upload, BookMarked, Sparkles, CheckCircle2 } from "lucide-react"
import { GatsbyButton } from "@/components/ui/gatsby-button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PublishingPlatformCard } from "@/components/publishing/publishing-platform-card"
import { ExportOptions } from "@/components/publishing/export-options"
import { PublishingChecklist } from "@/components/publishing/publishing-checklist"
import { BookPreview } from "@/components/publishing/book-preview"
import { StarCursor } from "@/components/ui/star-cursor"
import { FloatingBooks } from "@/components/ui/floating-books"

export default function PublishingDashboard() {
  const [selectedBook, setSelectedBook] = useState<string>("The Great Adventure")

  // Mock books data
  const books = [
    {
      id: "1",
      title: "The Great Adventure",
      chapters: 12,
      wordCount: 45000,
      coverImage: "/placeholder.svg?height=300&width=200",
    },
    {
      id: "2",
      title: "Mystery of the Lost Key",
      chapters: 8,
      wordCount: 32000,
      coverImage: "/placeholder.svg?height=300&width=200",
    },
    {
      id: "3",
      title: "Echoes of Tomorrow",
      chapters: 15,
      wordCount: 62000,
      coverImage: "/placeholder.svg?height=300&width=200",
    },
  ]

  return (
    <div className="container relative mx-auto py-6">
      <StarCursor />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <FloatingBooks count={5} />
      </div>

      <div className="flex flex-col gap-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col gap-2"
        >
          <h1 className="text-4xl font-bold tracking-tight">Publishing Dashboard</h1>
          <p className="text-muted-foreground">Prepare your manuscript and publish to major platforms</p>
        </motion.div>

        <Tabs defaultValue="export" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="export" className="text-sm">
              <FileText className="w-4 h-4 mr-2" />
              Export Options
            </TabsTrigger>
            <TabsTrigger value="platforms" className="text-sm">
              <Upload className="w-4 h-4 mr-2" />
              Publishing Platforms
            </TabsTrigger>
            <TabsTrigger value="checklist" className="text-sm">
              <CheckCircle2 className="w-4 h-4 mr-2" />
              Publishing Checklist
            </TabsTrigger>
          </TabsList>

          <TabsContent value="export" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-1">
                <Card className="h-full border-none bg-gradient-to-br from-amber-50/50 to-amber-100/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BookOpen className="h-5 w-5 text-amber-700" />
                      Select Book
                    </CardTitle>
                    <CardDescription>Choose a book to export</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {books.map((book) => (
                      <div
                        key={book.id}
                        onClick={() => setSelectedBook(book.title)}
                        className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all ${
                          selectedBook === book.title
                            ? "bg-amber-100 border border-amber-200"
                            : "bg-white/50 hover:bg-white/80 border border-transparent"
                        }`}
                      >
                        <div className="w-12 h-16 rounded overflow-hidden shadow-sm">
                          <img
                            src={book.coverImage || "/placeholder.svg"}
                            alt={book.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <h3 className="font-medium text-sm">{book.title}</h3>
                          <p className="text-xs text-muted-foreground">
                            {book.chapters} chapters • {book.wordCount.toLocaleString()} words
                          </p>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>

              <div className="md:col-span-2">
                <ExportOptions selectedBook={selectedBook} />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <BookPreview selectedBook={selectedBook} />

              <Card className="border-none bg-gradient-to-br from-blue-50/50 to-purple-50/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-purple-600" />
                    Publishing Tips
                  </CardTitle>
                  <CardDescription>Make your book stand out</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-white/70 rounded-lg p-4 border border-purple-100">
                    <h3 className="font-medium text-sm mb-2">Professional Formatting</h3>
                    <p className="text-xs text-muted-foreground">
                      Ensure consistent formatting throughout your manuscript. Use standard fonts like Times New Roman
                      or Garamond for fiction.
                    </p>
                  </div>
                  <div className="bg-white/70 rounded-lg p-4 border border-purple-100">
                    <h3 className="font-medium text-sm mb-2">Eye-Catching Cover</h3>
                    <p className="text-xs text-muted-foreground">
                      Your cover is your first marketing tool. Use our AI Cover Generator to create professional designs
                      that attract readers.
                    </p>
                  </div>
                  <div className="bg-white/70 rounded-lg p-4 border border-purple-100">
                    <h3 className="font-medium text-sm mb-2">Compelling Description</h3>
                    <p className="text-xs text-muted-foreground">
                      Write a captivating book description that hooks potential readers. Focus on the main conflict and
                      what makes your story unique.
                    </p>
                  </div>
                </CardContent>
                <CardFooter>
                  <GatsbyButton className="w-full">
                    <BookMarked className="mr-2 h-4 w-4" />
                    Get Full Publishing Guide
                  </GatsbyButton>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="platforms" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <PublishingPlatformCard
                name="Amazon Kindle Direct Publishing"
                logo="/placeholder.svg?height=60&width=180"
                description="The world's largest e-book retailer. Publish once and reach millions of readers on Amazon Kindle devices and Kindle apps."
                features={[
                  "Up to 70% royalty on sales",
                  "Global distribution",
                  "Print-on-demand options",
                  "Marketing tools included",
                ]}
                url="https://kdp.amazon.com"
                buttonText="Publish on Amazon KDP"
              />

              <PublishingPlatformCard
                name="Barnes & Noble Press"
                logo="/placeholder.svg?height=60&width=180"
                description="Reach millions of readers on the world's largest bookstore chain. Publish e-books and print books with B&N Press."
                features={[
                  "Up to 65% royalty on e-books",
                  "Premium print quality",
                  "Free ISBN provided",
                  "In-store promotion opportunities",
                ]}
                url="https://press.barnesandnoble.com"
                buttonText="Publish on B&N Press"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <PublishingPlatformCard
                name="Apple Books"
                logo="/placeholder.svg?height=60&width=180"
                description="Publish your book on Apple Books and reach millions of readers on iPhone, iPad, and Mac."
                features={[
                  "70% royalty rate",
                  "Global distribution",
                  "Beautiful reading experience",
                  "Apple Books marketing opportunities",
                ]}
                url="https://authors.apple.com"
                buttonText="Publish on Apple Books"
                compact
              />

              <PublishingPlatformCard
                name="Kobo Writing Life"
                logo="/placeholder.svg?height=60&width=180"
                description="Publish globally with Kobo and reach readers in over 190 countries."
                features={[
                  "Up to 70% royalty",
                  "International focus",
                  "Promotional opportunities",
                  "User-friendly dashboard",
                ]}
                url="https://www.kobo.com/writinglife"
                buttonText="Publish on Kobo"
                compact
              />

              <PublishingPlatformCard
                name="Google Play Books"
                logo="/placeholder.svg?height=60&width=180"
                description="Publish your books on Google Play and reach billions of potential readers."
                features={[
                  "70% royalty rate",
                  "Global reach",
                  "Android device integration",
                  "Google search visibility",
                ]}
                url="https://play.google.com/books/publish"
                buttonText="Publish on Google Play"
                compact
              />
            </div>

            <Card className="border-none bg-gradient-to-br from-amber-50/50 to-amber-100/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Download className="h-5 w-5 text-amber-700" />
                  Export for Publishing
                </CardTitle>
                <CardDescription>Prepare your files for upload to publishing platforms</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-white/70 rounded-lg p-4 border border-amber-100 flex flex-col items-center text-center">
                    <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center mb-3">
                      <FileText className="h-8 w-8 text-amber-700" />
                    </div>
                    <h3 className="font-medium text-sm mb-1">EPUB Format</h3>
                    <p className="text-xs text-muted-foreground mb-3">Standard e-book format for most platforms</p>
                    <GatsbyButton variant="outline" size="sm" className="mt-auto">
                      Export EPUB
                    </GatsbyButton>
                  </div>

                  <div className="bg-white/70 rounded-lg p-4 border border-amber-100 flex flex-col items-center text-center">
                    <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center mb-3">
                      <BookOpen className="h-8 w-8 text-amber-700" />
                    </div>
                    <h3 className="font-medium text-sm mb-1">Print-Ready PDF</h3>
                    <p className="text-xs text-muted-foreground mb-3">Formatted for print publishing</p>
                    <GatsbyButton variant="outline" size="sm" className="mt-auto">
                      Export PDF
                    </GatsbyButton>
                  </div>

                  <div className="bg-white/70 rounded-lg p-4 border border-amber-100 flex flex-col items-center text-center">
                    <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center mb-3">
                      <BookMarked className="h-8 w-8 text-amber-700" />
                    </div>
                    <h3 className="font-medium text-sm mb-1">MOBI Format</h3>
                    <p className="text-xs text-muted-foreground mb-3">For Amazon Kindle publishing</p>
                    <GatsbyButton variant="outline" size="sm" className="mt-auto">
                      Export MOBI
                    </GatsbyButton>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="checklist" className="space-y-6">
            <PublishingChecklist selectedBook={selectedBook} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
