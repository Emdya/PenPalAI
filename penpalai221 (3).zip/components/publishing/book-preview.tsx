"use client"

import type React from "react"

import { useState } from "react"
import { ChevronLeft, ChevronRight, Maximize2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { GatsbyButton } from "@/components/ui/gatsby-button"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"

interface BookPreviewProps {
  selectedBook: string
}

export function BookPreview({ selectedBook }: BookPreviewProps) {
  const [currentPage, setCurrentPage] = useState(1)
  const totalPages = 5

  const handlePrevPage = () => {
    setCurrentPage((prev) => Math.max(prev - 1, 1))
  }

  const handleNextPage = () => {
    setCurrentPage((prev) => Math.min(prev + 1, totalPages))
  }

  return (
    <Card className="border-none bg-gradient-to-br from-amber-50/50 to-amber-100/50 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BookPreviewIcon className="h-5 w-5 text-amber-700" />
          Book Preview
        </CardTitle>
        <CardDescription>Preview how your book will look when exported</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative bg-white rounded-lg shadow-md p-4 aspect-[3/4] flex items-center justify-center">
          <Dialog>
            <DialogTrigger asChild>
              <button className="absolute top-2 right-2 p-1 rounded-full bg-amber-100 hover:bg-amber-200 transition-colors">
                <Maximize2 className="h-4 w-4 text-amber-700" />
              </button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl">
              <div className="bg-white rounded-lg shadow-md p-8 aspect-[3/4] flex items-center justify-center">
                <BookPageContent page={currentPage} bookTitle={selectedBook} />
              </div>
            </DialogContent>
          </Dialog>

          <BookPageContent page={currentPage} bookTitle={selectedBook} />

          <div className="absolute bottom-4 left-0 right-0 flex items-center justify-center gap-4">
            <GatsbyButton variant="outline" size="sm" onClick={handlePrevPage} disabled={currentPage === 1}>
              <ChevronLeft className="h-4 w-4" />
            </GatsbyButton>
            <span className="text-xs font-medium">
              Page {currentPage} of {totalPages}
            </span>
            <GatsbyButton variant="outline" size="sm" onClick={handleNextPage} disabled={currentPage === totalPages}>
              <ChevronRight className="h-4 w-4" />
            </GatsbyButton>
          </div>
        </div>

        <div className="grid grid-cols-5 gap-2">
          {[1, 2, 3, 4, 5].map((page) => (
            <button
              key={page}
              onClick={() => setCurrentPage(page)}
              className={`aspect-[3/4] rounded border ${
                currentPage === page ? "border-amber-400 bg-amber-50" : "border-gray-200 bg-white hover:bg-gray-50"
              }`}
            >
              <div className="w-full h-full flex items-center justify-center">
                <span className="text-xs font-medium">{page}</span>
              </div>
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

function BookPreviewIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
      <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
    </svg>
  )
}

function BookPageContent({ page, bookTitle }: { page: number; bookTitle: string }) {
  // Mock content for different pages
  const pageContents = {
    1: {
      type: "title",
      content: bookTitle,
      author: "Your Name",
    },
    2: {
      type: "toc",
      chapters: [
        "Chapter 1: The Beginning",
        "Chapter 2: The Journey",
        "Chapter 3: The Challenge",
        "Chapter 4: The Resolution",
      ],
    },
    3: {
      type: "chapter",
      title: "Chapter 1: The Beginning",
      content:
        "It was a bright cold day in April, and the clocks were striking thirteen. Winston Smith, his chin nuzzled into his breast in an effort to escape the vile wind, slipped quickly through the glass doors of Victory Mansions, though not quickly enough to prevent a swirl of gritty dust from entering along with him.",
    },
    4: {
      type: "chapter",
      title: "Chapter 2: The Journey",
      content:
        "The journey began at dawn, when the first rays of sunlight crept over the horizon. The road ahead stretched endlessly, winding through valleys and mountains, promising adventure and discovery at every turn. With each step, the weight of the past seemed to lighten, replaced by the anticipation of what lay ahead.",
    },
    5: {
      type: "chapter",
      title: "Chapter 3: The Challenge",
      content:
        "Facing the challenge head-on required courage and determination. The obstacles seemed insurmountable at first, towering like giants in the path. But with each small victory, confidence grew, and what once appeared impossible slowly revealed itself to be within reach.",
    },
  }

  const content = pageContents[page as keyof typeof pageContents]

  if (content.type === "title") {
    return (
      <div className="text-center space-y-8">
        <h1 className="text-2xl font-bold">{content.content}</h1>
        <div className="w-16 h-1 bg-amber-300 mx-auto"></div>
        <p className="text-sm">By {content.author}</p>
      </div>
    )
  }

  if (content.type === "toc") {
    return (
      <div className="space-y-6 w-full max-w-xs">
        <h2 className="text-lg font-bold text-center">Table of Contents</h2>
        <div className="space-y-4">
          {content.chapters.map((chapter, index) => (
            <div key={index} className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-amber-400"></div>
              <span className="text-sm">{chapter}</span>
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4 w-full max-w-xs">
      <h2 className="text-lg font-bold">{content.title}</h2>
      <p className="text-sm leading-relaxed">{content.content}</p>
    </div>
  )
}
