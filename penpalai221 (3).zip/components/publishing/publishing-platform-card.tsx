"use client"

import { motion } from "framer-motion"
import { ExternalLink } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { GatsbyButton } from "@/components/ui/gatsby-button"

interface PublishingPlatformCardProps {
  name: string
  logo: string
  description: string
  features: string[]
  url: string
  buttonText: string
  compact?: boolean
}

export function PublishingPlatformCard({
  name,
  logo,
  description,
  features,
  url,
  buttonText,
  compact = false,
}: PublishingPlatformCardProps) {
  return (
    <motion.div whileHover={{ y: -5, transition: { duration: 0.2 } }} className="h-full">
      <Card className="h-full border-none bg-gradient-to-br from-amber-50/50 to-amber-100/50 backdrop-blur-sm overflow-hidden">
        <CardHeader className={compact ? "pb-2" : ""}>
          <div className="flex items-center justify-between">
            <div className="h-12 flex items-center">
              <img src={logo || "/placeholder.svg"} alt={name} className="max-h-full" />
            </div>
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-amber-100">
              <ExternalLink className="h-4 w-4 text-amber-700" />
            </div>
          </div>
          <CardTitle className={`text-lg ${compact ? "text-base" : ""}`}>{name}</CardTitle>
          <CardDescription className={compact ? "text-xs" : ""}>{description}</CardDescription>
        </CardHeader>
        <CardContent className={compact ? "pb-2" : ""}>
          <div className="space-y-2">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center gap-2 bg-white/70 p-2 rounded border border-amber-100">
                <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                <span className={`text-sm ${compact ? "text-xs" : ""}`}>{feature}</span>
              </div>
            ))}
          </div>
        </CardContent>
        <CardFooter>
          <GatsbyButton className="w-full" size={compact ? "sm" : "default"} onClick={() => window.open(url, "_blank")}>
            {buttonText}
          </GatsbyButton>
        </CardFooter>
      </Card>
    </motion.div>
  )
}
