"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { CheckCircle, Circle, AlertCircle } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { GatsbyButton } from "@/components/ui/gatsby-button"
import { Progress } from "@/components/ui/progress"

interface PublishingChecklistProps {
  selectedBook: string
}

export function PublishingChecklist({ selectedBook }: PublishingChecklistProps) {
  const [completedItems, setCompletedItems] = useState<string[]>(["manuscript", "editing", "formatting"])

  const checklistItems = [
    {
      id: "manuscript",
      title: "Complete Manuscript",
      description: "Finish writing all chapters of your book",
      status: completedItems.includes("manuscript") ? "complete" : "incomplete",
    },
    {
      id: "editing",
      title: "Editing & Proofreading",
      description: "Review and correct grammar, spelling, and consistency",
      status: completedItems.includes("editing") ? "complete" : "incomplete",
    },
    {
      id: "formatting",
      title: "Formatting",
      description: "Format your book according to publishing standards",
      status: completedItems.includes("formatting") ? "complete" : "incomplete",
    },
    {
      id: "cover",
      title: "Book Cover Design",
      description: "Create an eye-catching cover for your book",
      status: completedItems.includes("cover") ? "complete" : "incomplete",
    },
    {
      id: "description",
      title: "Book Description",
      description: "Write a compelling description for marketing",
      status: completedItems.includes("description") ? "complete" : "incomplete",
    },
    {
      id: "isbn",
      title: "ISBN Acquisition",
      description: "Obtain an ISBN for your book",
      status: completedItems.includes("isbn") ? "complete" : "incomplete",
    },
    {
      id: "copyright",
      title: "Copyright Registration",
      description: "Register copyright for your work",
      status: completedItems.includes("copyright") ? "complete" : "incomplete",
    },
    {
      id: "pricing",
      title: "Pricing Strategy",
      description: "Determine pricing for different formats",
      status: completedItems.includes("pricing") ? "complete" : "incomplete",
    },
    {
      id: "marketing",
      title: "Marketing Plan",
      description: "Create a plan to promote your book",
      status: completedItems.includes("marketing") ? "complete" : "incomplete",
    },
    {
      id: "export",
      title: "File Export",
      description: "Export your book in required formats",
      status: completedItems.includes("export") ? "complete" : "incomplete",
    },
  ]

  const toggleItem = (id: string) => {
    if (completedItems.includes(id)) {
      setCompletedItems((prev) => prev.filter((item) => item !== id))
    } else {
      setCompletedItems((prev) => [...prev, id])
    }
  }

  const progress = Math.round((completedItems.length / checklistItems.length) * 100)

  return (
    <div className="space-y-6">
      <Card className="border-none bg-gradient-to-br from-blue-50/50 to-purple-50/50 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-purple-600" />
            Publishing Checklist
          </CardTitle>
          <CardDescription>Track your progress for "{selectedBook}"</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Publishing Progress</span>
              <span className="text-sm font-medium">{progress}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          <div className="space-y-3">
            {checklistItems.map((item) => (
              <motion.div
                key={item.id}
                whileHover={{ x: 5 }}
                className={`flex items-start gap-3 p-3 rounded-lg cursor-pointer transition-colors ${
                  item.status === "complete"
                    ? "bg-green-50 border border-green-100"
                    : "bg-white/70 border border-gray-100 hover:bg-gray-50/80"
                }`}
                onClick={() => toggleItem(item.id)}
              >
                <div className="mt-0.5">
                  {item.status === "complete" ? (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  ) : (
                    <Circle className="h-5 w-5 text-gray-300" />
                  )}
                </div>
                <div>
                  <h3 className="font-medium text-sm">{item.title}</h3>
                  <p className="text-xs text-muted-foreground">{item.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
        <CardFooter>
          <div className="w-full flex flex-col gap-2">
            <GatsbyButton className="w-full">Generate Publishing Report</GatsbyButton>
            <p className="text-xs text-center text-muted-foreground">
              Complete all items to ensure your book is ready for publishing
            </p>
          </div>
        </CardFooter>
      </Card>

      <Card className="border-none bg-gradient-to-br from-amber-50/50 to-amber-100/50 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-amber-700" />
            Publishing Tips
          </CardTitle>
          <CardDescription>Important considerations before publishing</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="bg-white/70 rounded-lg p-3 border border-amber-100">
            <h3 className="font-medium text-sm mb-1">ISBN Requirements</h3>
            <p className="text-xs text-muted-foreground">
              Different platforms have different ISBN requirements. Amazon KDP provides free ISBNs, while other
              platforms may require you to purchase your own.
            </p>
          </div>

          <div className="bg-white/70 rounded-lg p-3 border border-amber-100">
            <h3 className="font-medium text-sm mb-1">Pricing Strategy</h3>
            <p className="text-xs text-muted-foreground">
              Research competitive pricing in your genre. Consider pricing e-books between $2.99 and $9.99 to maximize
              royalties on most platforms.
            </p>
          </div>

          <div className="bg-white/70 rounded-lg p-3 border border-amber-100">
            <h3 className="font-medium text-sm mb-1">Exclusivity Considerations</h3>
            <p className="text-xs text-muted-foreground">
              Some programs like Amazon KDP Select require exclusivity. Consider the benefits and limitations before
              enrolling.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
