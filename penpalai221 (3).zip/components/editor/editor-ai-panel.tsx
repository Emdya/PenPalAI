"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChevronRight, Sparkles, Lightbulb, Check, RefreshCw, X, CheckCircle, AlertCircle } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { AIChat } from "@/components/editor/ai-chat"
import { Badge } from "@/components/ui/badge"

export function EditorAIPanel() {
  const [isOpen, setIsOpen] = useState(true)
  const [isGeneratingSuggestions, setIsGeneratingSuggestions] = useState(false)

  if (!isOpen) {
    return (
      <div className="border-l bg-background flex flex-col items-center py-4">
        <Button variant="ghost" size="icon" onClick={() => setIsOpen(true)} className="h-8 w-8">
          <ChevronRight className="h-4 w-4" />
          <span className="sr-only">Open AI panel</span>
        </Button>
      </div>
    )
  }

  return (
    <div className="w-80 border-l bg-background flex flex-col">
      <div className="border-b p-4 flex items-center justify-between">
        <h3 className="font-medium flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          AI Assistant
        </h3>
        <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="h-8 w-8">
          <X className="h-4 w-4" />
          <span className="sr-only">Close AI panel</span>
        </Button>
      </div>
      <Tabs defaultValue="chat" className="flex-1 flex flex-col">
        <TabsList className="grid grid-cols-4 px-4 py-2">
          <TabsTrigger value="chat">Chat</TabsTrigger>
          <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
          <TabsTrigger value="outline">Outline</TabsTrigger>
          <TabsTrigger value="analysis">Analysis</TabsTrigger>
        </TabsList>
        <TabsContent value="chat" className="flex-1 flex flex-col p-0 m-0">
          <AIChat />
        </TabsContent>
        <TabsContent value="suggestions" className="flex-1 overflow-auto p-4 space-y-4 m-0">
          <div className="flex justify-between items-center mb-2">
            <h4 className="text-sm font-medium">Writing Suggestions</h4>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsGeneratingSuggestions(true)}
              disabled={isGeneratingSuggestions}
            >
              {isGeneratingSuggestions ? (
                <>
                  <RefreshCw className="mr-2 h-3 w-3 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-3 w-3" />
                  Refresh
                </>
              )}
            </Button>
          </div>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger className="text-sm">Add more sensory details</AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground mb-2">
                  Consider adding more sensory details about the artifact to build intrigue.
                </p>
                <div className="bg-muted/50 p-2 rounded-md text-sm">
                  The small, metallic object seemed to pulse with an energy that defied explanation.{" "}
                  <span className="text-primary">
                    Its surface was cool to the touch, yet it radiated a strange warmth. The intricate engravings caught
                    the light, shifting like liquid silver as she turned it in her hands. A faint, sweet scent
                    reminiscent of ancient incense emanated from it.
                  </span>
                </div>
                <div className="flex justify-between items-center mt-2">
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Check className="mr-2 h-3 w-3" />
                      Apply
                    </Button>
                    <Button variant="ghost" size="sm">
                      <RefreshCw className="mr-2 h-3 w-3" />
                      Regenerate
                    </Button>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    <Sparkles className="h-3 w-3 mr-1" />
                    AI Generated
                  </Badge>
                </div>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-2">
              <AccordionTrigger className="text-sm">Enhance the mysterious atmosphere</AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground mb-2">
                  Strengthen the sense of mystery and foreboding in the scene.
                </p>
                <div className="bg-muted/50 p-2 rounded-md text-sm">
                  As she approached the house, Sarah couldn't shake the feeling that she was being watched.{" "}
                  <span className="text-primary">
                    The shadows between the trees seemed to shift and move with purpose. A sudden gust of wind carried
                    whispers that sounded almost like her name. The artifact in her pocket grew warmer, as if responding
                    to some unseen presence.
                  </span>
                </div>
                <div className="flex justify-between items-center mt-2">
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Check className="mr-2 h-3 w-3" />
                      Apply
                    </Button>
                    <Button variant="ghost" size="sm">
                      <RefreshCw className="mr-2 h-3 w-3" />
                      Regenerate
                    </Button>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    <Sparkles className="h-3 w-3 mr-1" />
                    AI Generated
                  </Badge>
                </div>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-3">
              <AccordionTrigger className="text-sm">Develop Sarah's character</AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground mb-2">
                  Add more depth to Sarah's character through her reactions.
                </p>
                <div className="bg-muted/50 p-2 rounded-md text-sm">
                  "What are you?" she murmured, turning the artifact over to examine its intricate engravings.{" "}
                  <span className="text-primary">
                    Sarah had always been drawn to ancient mysteries, spending countless hours in the university library
                    researching forgotten civilizations while her peers attended parties. This discovery felt like
                    validation of her academic passion, yet also triggered an inexplicable anxiety she couldn't
                    rationalize.
                  </span>
                </div>
                <div className="flex justify-between items-center mt-2">
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Check className="mr-2 h-3 w-3" />
                      Apply
                    </Button>
                    <Button variant="ghost" size="sm">
                      <RefreshCw className="mr-2 h-3 w-3" />
                      Regenerate
                    </Button>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    <Sparkles className="h-3 w-3 mr-1" />
                    AI Generated
                  </Badge>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </TabsContent>
        <TabsContent value="outline" className="flex-1 overflow-auto p-4 space-y-4 m-0">
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-medium mb-2">Chapter Outline</h4>
              <div className="space-y-2">
                <div className="bg-muted p-3 rounded-md">
                  <h5 className="text-sm font-medium">Chapter 1: The Discovery</h5>
                  <ul className="mt-1 text-xs space-y-1 text-muted-foreground">
                    <li>• Sarah finds the artifact under the oak tree</li>
                    <li>• First connection with the artifact's energy</li>
                    <li>• Return to grandmother's house with a feeling of being watched</li>
                    <li>• Foreshadowing of the larger conflict</li>
                  </ul>
                </div>
                <div className="bg-muted p-3 rounded-md">
                  <h5 className="text-sm font-medium">Chapter 2: Family Secrets</h5>
                  <ul className="mt-1 text-xs space-y-1 text-muted-foreground">
                    <li>• Grandmother reveals partial knowledge of the artifact</li>
                    <li>• Sarah learns about her family's connection to ancient guardians</li>
                    <li>• First encounter with antagonistic forces</li>
                    <li>• Decision to seek more information</li>
                  </ul>
                </div>
                <div className="bg-muted p-3 rounded-md">
                  <h5 className="text-sm font-medium">Chapter 3: The Scholar</h5>
                  <ul className="mt-1 text-xs space-y-1 text-muted-foreground">
                    <li>• Sarah visits Professor Harlow at the university</li>
                    <li>• Translation of the artifact's engravings</li>
                    <li>• Discovery of the artifact's purpose</li>
                    <li>• Realization of the danger Sarah is now in</li>
                  </ul>
                </div>
              </div>
              <Button className="w-full mt-4" size="sm">
                <Lightbulb className="mr-2 h-4 w-4" />
                Generate More Chapters
              </Button>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-2">Character Development</h4>
              <div className="space-y-2">
                <div className="bg-muted p-3 rounded-md">
                  <h5 className="text-sm font-medium">Sarah</h5>
                  <ul className="mt-1 text-xs space-y-1 text-muted-foreground">
                    <li>• Curious and academically-minded</li>
                    <li>• Intuitive connection to ancient mysteries</li>
                    <li>• Unaware of her family's true history</li>
                    <li>• Character arc: Reluctant hero to confident guardian</li>
                  </ul>
                </div>
                <div className="bg-muted p-3 rounded-md">
                  <h5 className="text-sm font-medium">Grandmother Eleanor</h5>
                  <ul className="mt-1 text-xs space-y-1 text-muted-foreground">
                    <li>• Keeper of family secrets</li>
                    <li>• Former guardian who retired from active duty</li>
                    <li>• Protective of Sarah but knows she must face her destiny</li>
                    <li>• Provides wisdom and historical context</li>
                  </ul>
                </div>
              </div>
              <Button className="w-full mt-4" size="sm">
                <Lightbulb className="mr-2 h-4 w-4" />
                Generate More Characters
              </Button>
            </div>
          </div>
        </TabsContent>
        <TabsContent value="analysis" className="flex-1 overflow-auto p-4 space-y-4 m-0">
          <div className="space-y-4">
            <div className="flex justify-between items-center mb-2">
              <h4 className="text-sm font-medium">ML Analysis</h4>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  // This will be handled by the EditorContent component
                  window.dispatchEvent(new CustomEvent("analyze-full-text"))
                }}
              >
                <RefreshCw className="mr-2 h-3 w-3" />
                Analyze Text
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">
              Select text in the editor and use the "Analyze Selection" button for targeted feedback, or analyze your
              entire text for comprehensive insights.
            </p>
            <div className="bg-muted/50 p-3 rounded-md">
              <h5 className="text-sm font-medium flex items-center text-green-600">
                <CheckCircle className="h-4 w-4 mr-2" />
                How ML Analysis Works
              </h5>
              <ul className="mt-1 text-xs space-y-1">
                <li>• Our ML algorithms analyze your writing patterns and style</li>
                <li>• We identify strengths and areas for improvement</li>
                <li>• Get specific, actionable suggestions to enhance your writing</li>
                <li>• For highlighted text, we provide context-aware feedback</li>
                <li>• The system learns from your writing over time</li>
              </ul>
            </div>
            <div className="bg-muted/50 p-3 rounded-md">
              <h5 className="text-sm font-medium flex items-center text-blue-600">
                <AlertCircle className="h-4 w-4 mr-2" />
                Analysis Features
              </h5>
              <ul className="mt-1 text-xs space-y-1">
                <li>• Character development assessment</li>
                <li>• Plot coherence and pacing analysis</li>
                <li>• Dialogue effectiveness evaluation</li>
                <li>• Setting and world-building feedback</li>
                <li>• Style and tone consistency check</li>
                <li>• Suggested text improvements with one-click application</li>
              </ul>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
