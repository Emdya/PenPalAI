"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Sparkles, MessageSquare, AlertTriangle, CheckCircle, X, RefreshCw, AlertCircle } from "lucide-react"
import { AIChat } from "./ai-chat"
import { ToneAnalyzer } from "./tone-analyzer"
import { ConsistencyChecker } from "./consistency-checker"
import { useToast } from "@/hooks/use-toast"
import { TextAnalyzer } from "./text-analyzer"

export function EditorContent() {
  const [content, setContent] = useState(
    `It was a cold winter morning when Sarah first discovered the ancient artifact. The small, metallic object seemed to pulse with an energy that defied explanation. As she held it in her palm, a warm sensation traveled up her arm, and for a brief moment, she thought she heard whispers—distant voices speaking in a language she couldn't understand.

"What are you?" she murmured, turning the artifact over to examine its intricate engravings.

The artifact had been buried beneath the old oak tree behind her grandmother's house. Sarah had been digging there on a whim, guided by a recurring dream that had plagued her for weeks. In the dream, she always found something important beneath that tree, something that would change everything.

And now, here it was. But what exactly was it? And why did she feel so strongly connected to it?

Sarah carefully placed the artifact in her pocket and headed back to the house. Her grandmother might know something about it. After all, the old woman had lived in this valley her entire life and knew all its secrets.

As she approached the house, Sarah couldn't shake the feeling that she was being watched. She turned around, scanning the tree line at the edge of the property, but saw nothing unusual. Still, the sensation persisted, raising goosebumps on her skin despite the warm sunlight.

Little did she know that this discovery would set in motion a chain of events that would not only reveal the truth about her family's mysterious past but also thrust her into an ancient conflict that had been simmering beneath the surface of the world for centuries.`,
  )

  const [wordCount, setWordCount] = useState(0)
  const [showAIPanel, setShowAIPanel] = useState(false)
  const [aiTab, setAITab] = useState("chat")
  const { toast } = useToast()
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const [highlightedText, setHighlightedText] = useState("")
  const [highlightedRange, setHighlightedRange] = useState<{ start: number; end: number } | null>(null)
  const [analysisType, setAnalysisType] = useState<"full" | "highlighted" | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysis, setAnalysis] = useState<{
    strengths: string[]
    weaknesses: string[]
    suggestions: string[]
  } | null>(null)

  useEffect(() => {
    const words = content.trim().split(/\s+/).length
    setWordCount(words)
  }, [content])

  const toggleAIPanel = () => {
    setShowAIPanel(!showAIPanel)
    if (!showAIPanel) {
      setAITab("analysis")
    }
  }

  const handleError = (message: string) => {
    toast({
      title: "Error",
      description: message,
      variant: "destructive",
    })
  }

  const handleTextSelection = () => {
    if (textareaRef.current) {
      const start = textareaRef.current.selectionStart
      const end = textareaRef.current.selectionEnd

      if (start !== end) {
        const selectedText = content.substring(start, end)
        setHighlightedText(selectedText)
        setHighlightedRange({ start, end })
      } else {
        setHighlightedText("")
        setHighlightedRange(null)
      }
    }
  }

  const requestAnalysis = async (type: "full" | "highlighted") => {
    setIsAnalyzing(true)
    setAnalysisType(type)
    setAnalysis(null)

    try {
      const textToAnalyze = type === "full" ? content : highlightedText

      if (!textToAnalyze || textToAnalyze.trim().length === 0) {
        throw new Error(type === "full" ? "No content to analyze" : "No text selected for analysis")
      }

      const response = await fetch("/api/ai/analyze", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content: textToAnalyze,
          type,
          context:
            type === "highlighted"
              ? {
                  fullText: content,
                  selectionStart: highlightedRange?.start,
                  selectionEnd: highlightedRange?.end,
                }
              : undefined,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(errorData.error || "Failed to analyze text")
      }

      const data = await response.json()
      setAnalysis(data)

      // If analysis was successful, show the AI panel with the analysis tab
      if (!showAIPanel) {
        setShowAIPanel(true)
      }
      setAITab("analysis")

      toast({
        title: "Analysis Complete",
        description: `Successfully analyzed your ${type === "full" ? "full text" : "selected text"}`,
        variant: "default",
      })
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to analyze text"
      toast({
        title: "Analysis Error",
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setIsAnalyzing(false)
    }
  }

  const applyTextSuggestion = (suggestion: string) => {
    if (!highlightedRange) return

    const newContent =
      content.substring(0, highlightedRange.start) + suggestion + content.substring(highlightedRange.end)

    setContent(newContent)

    toast({
      title: "Suggestion Applied",
      description: "The suggested text has been applied to your document",
      variant: "default",
    })
  }

  return (
    <div className="flex-1 overflow-auto bg-background">
      <div className="max-w-3xl mx-auto p-8">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-semibold">Chapter 1: The Beginning</h3>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs">
              {wordCount} words
            </Badge>
            <Button variant="outline" size="sm" onClick={toggleAIPanel}>
              <Sparkles className="mr-2 h-4 w-4" />
              AI Assistance
            </Button>
          </div>
        </div>
        <div className="prose prose-sm max-w-none">
          <textarea
            ref={textareaRef}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onMouseUp={handleTextSelection}
            onKeyUp={handleTextSelection}
            className="w-full min-h-[calc(100vh-12rem)] resize-none border-none bg-transparent p-0 focus:outline-none focus:ring-0"
            placeholder="Start writing your story..."
          />
        </div>

        {highlightedText && (
          <div className="fixed bottom-24 right-24 z-20">
            <Button
              onClick={() => requestAnalysis("highlighted")}
              className="rounded-full shadow-lg"
              disabled={isAnalyzing}
            >
              {isAnalyzing && analysisType === "highlighted" ? (
                <span className="flex items-center">
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Analyzing...
                </span>
              ) : (
                <span className="flex items-center">
                  <Sparkles className="mr-2 h-4 w-4" />
                  Analyze Selection
                </span>
              )}
            </Button>
          </div>
        )}

        {showAIPanel && (
          <div className="fixed inset-y-0 right-0 w-80 bg-background border-l shadow-lg z-10 flex flex-col">
            <div className="p-4 border-b flex items-center justify-between">
              <h3 className="font-medium">AI Assistance</h3>
              <Button variant="ghost" size="sm" onClick={toggleAIPanel}>
                <X className="h-4 w-4" />
                <span className="sr-only">Close</span>
              </Button>
            </div>
            <Tabs value={aiTab} onValueChange={setAITab} className="flex-1 flex flex-col">
              <TabsList className="grid grid-cols-4 px-4 py-2">
                <TabsTrigger value="chat">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Chat
                </TabsTrigger>
                <TabsTrigger value="tone">
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  Tone
                </TabsTrigger>
                <TabsTrigger value="consistency">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Consistency
                </TabsTrigger>
                <TabsTrigger value="analysis">
                  <AlertCircle className="h-4 w-4 mr-2" />
                  Analysis
                </TabsTrigger>
              </TabsList>
              <TabsContent value="chat" className="flex-1 p-0 m-0">
                <AIChat />
              </TabsContent>
              <TabsContent value="tone" className="flex-1 overflow-auto p-4 m-0">
                <ToneAnalyzer content={content} />
              </TabsContent>
              <TabsContent value="consistency" className="flex-1 overflow-auto p-4 m-0">
                <ConsistencyChecker content={content} />
              </TabsContent>
              <TabsContent value="analysis" className="flex-1 overflow-auto p-4 m-0">
                <TextAnalyzer
                  content={content}
                  highlightedText={highlightedText}
                  analysis={analysis}
                  isAnalyzing={isAnalyzing}
                  analysisType={analysisType}
                  onAnalyze={requestAnalysis}
                  onApplySuggestion={applyTextSuggestion}
                />
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>
    </div>
  )
}
