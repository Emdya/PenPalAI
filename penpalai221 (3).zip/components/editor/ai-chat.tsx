"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Sparkles, Send, RefreshCw, User, AlertCircle, Cpu } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"

type Message = {
  role: "user" | "assistant" | "system"
  content: string
  provider?: string
}

export function AIChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hello! I'm your AI writing assistant. How can I help with your writing today?",
      provider: "openai",
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const { toast } = useToast()

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const userMessage = input.trim()
    setInput("")
    setIsLoading(true)
    setError(null)

    // Add user message to chat
    setMessages((prev) => [...prev, { role: "user", content: userMessage }])

    try {
      // Call the API directly
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [...messages, { role: "user", content: userMessage }].filter(
            (m) => m.role !== "system", // Filter out system messages
          ),
        }),
      })

      if (!response.ok) {
        throw new Error(`API responded with status: ${response.status}`)
      }

      const data = await response.json()

      // Add the assistant's response to the chat
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: data.content,
          provider: "openai",
        },
      ])
    } catch (error) {
      console.error("Error calling AI chat API:", error)
      setError("Failed to get a response. Please try again.")
      toast({
        title: "Error",
        description: "Failed to generate a response. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const retryLastMessage = async () => {
    if (messages.length < 2 || isLoading) return

    setIsLoading(true)
    setError(null)

    // Get all messages except the last assistant message
    const messagesToSend = messages.slice(0, -1)
    const lastUserMessage = messagesToSend.filter((m) => m.role === "user").pop()

    if (!lastUserMessage) {
      setIsLoading(false)
      return
    }

    try {
      // Call the API directly
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: messagesToSend.filter(
            (m) => m.role !== "system", // Filter out system messages
          ),
        }),
      })

      if (!response.ok) {
        throw new Error(`API responded with status: ${response.status}`)
      }

      const data = await response.json()

      // Update the messages with the new response
      setMessages([
        ...messagesToSend,
        {
          role: "assistant",
          content: data.content,
          provider: "openai",
        },
      ])
    } catch (error) {
      console.error("Error retrying AI chat:", error)
      setError("Failed to get a response. Please try again.")
      toast({
        title: "Error",
        description: "Failed to generate a response. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message, index) => (
          <div key={index} className="flex gap-2">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                message.role === "assistant" ? "bg-primary/20" : "bg-muted"
              }`}
            >
              {message.role === "assistant" ? (
                <Sparkles className="h-4 w-4 text-primary" />
              ) : (
                <User className="h-4 w-4 text-muted-foreground" />
              )}
            </div>
            <div className="flex-1">
              <div className={`rounded-lg p-3 text-sm ${message.role === "assistant" ? "bg-muted" : "bg-primary/10"}`}>
                <div className="whitespace-pre-wrap">{message.content}</div>
              </div>
              {message.provider && message.role === "assistant" && message.provider !== "system" && (
                <div className="mt-1 flex justify-end">
                  <Badge variant="outline" className="text-xs">
                    <Cpu className="h-3 w-3 mr-1" />
                    {message.provider}
                  </Badge>
                </div>
              )}
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex gap-2">
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
              <Sparkles className="h-4 w-4 text-primary animate-pulse" />
            </div>
            <div className="flex-1">
              <div className="rounded-lg p-3 text-sm bg-muted">
                <div className="whitespace-pre-wrap">Thinking...</div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {error && (
        <Alert variant="default" className="mx-4 my-2 bg-primary/10 border-primary/20">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Notice</AlertTitle>
          <AlertDescription>
            {error}
            <Button variant="outline" size="sm" className="ml-2" onClick={retryLastMessage}>
              Retry
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit} className="border-t p-4 flex gap-2">
        <Textarea
          placeholder="Ask the AI assistant..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="min-h-[60px] resize-none"
          disabled={isLoading}
        />
        <Button type="submit" size="icon" disabled={isLoading || !input.trim()}>
          {isLoading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          <span className="sr-only">Send</span>
        </Button>
      </form>
    </div>
  )
}
