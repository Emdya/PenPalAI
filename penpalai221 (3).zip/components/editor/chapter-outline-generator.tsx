"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { RefreshCw, AlertCircle, Download, Sparkles } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"

const GENRES = [
  "Fantasy",
  "Science Fiction",
  "Mystery",
  "Thriller",
  "Romance",
  "Historical Fiction",
  "Literary Fiction",
  "Horror",
  "Young Adult",
  "Memoir",
]

// Mock outline for preview environment
const MOCK_OUTLINE = `# The Lost Kingdom - Fantasy Novel Outline

## Chapter 1: The Discovery
- Sarah discovers an ancient artifact buried beneath an old oak tree
- First connection with the artifact's mysterious energy
- Introduction to Sarah's grandmother and her secluded house
- Foreshadowing of being watched by unknown entities

## Chapter 2: Family Secrets
- Grandmother reveals partial knowledge of the artifact
- Sarah learns about her family's connection to ancient guardians
- First encounter with antagonistic forces
- Decision to seek more information from a scholar

## Chapter 3: The Scholar
- Meeting with Professor Harlow at the university
- Translation of the artifact's engravings
- Discovery of the artifact's purpose as a key to a hidden realm
- Realization of the danger Sarah is now in

## Chapter 4: Pursuit
- Antagonists attack Sarah and the professor
- Narrow escape using the artifact's power for the first time
- Journey to find the hidden temple mentioned in the engravings
- Meeting a mysterious ally who offers guidance

## Chapter 5: The Temple
- Arrival at the ancient temple deep in the forest
- Solving puzzles to gain entry
- Discovery of a portal to the lost kingdom
- Climactic confrontation with the main antagonist
- Cliffhanger as Sarah is pulled through the portal

## Chapter 6: The Lost Kingdom
- Sarah awakens in a strange, beautiful realm
- Meeting the inhabitants who have been waiting for "the guardian"
- Learning about the kingdom's history and its connection to our world
- Understanding her destiny as the new guardian of the realm

## Chapter 7: Return and Resolution
- Sarah must make a choice between worlds
- Final battle with antagonists who followed her through the portal
- Resolution of family legacy
- Sarah's decision and its consequences
- Epilogue showing the new balance between worlds`

export function ChapterOutlineGenerator() {
  const [title, setTitle] = useState("The Lost Kingdom")
  const [genre, setGenre] = useState("Fantasy")
  const [outline, setOutline] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isPreviewMode, setIsPreviewMode] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    // Check if we're in a preview environment
    const isPreview =
      window.location.hostname.includes("vercel.app") ||
      window.location.hostname === "localhost" ||
      window.location.hostname === "127.0.0.1"
    setIsPreviewMode(isPreview)

    if (isPreview) {
      console.log("Running in preview mode - using mock AI responses")
    }
  }, [])

  const handleGenerate = async () => {
    if (!title.trim() || !genre || isLoading) return

    setIsLoading(true)
    setError(null)

    try {
      // For preview environment, use mock data directly without API call
      if (isPreviewMode) {
        // Simulate API delay
        await new Promise((resolve) => setTimeout(resolve, 1000))
        setOutline(MOCK_OUTLINE.replace("The Lost Kingdom", title))
        setIsLoading(false)
        return
      }

      // Real API call
      const response = await fetch("/api/ai/chapter-outline", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ title, genre }),
      })

      // First get the text response to check for errors
      const responseText = await response.text()

      let data
      try {
        // Try to parse the response as JSON
        data = JSON.parse(responseText)
      } catch (parseError) {
        console.error("Failed to parse response as JSON:", responseText)
        throw new Error(`Invalid JSON response: ${responseText.substring(0, 50)}...`)
      }

      if (!response.ok) {
        throw new Error(data.error || `Failed to generate outline: ${response.statusText}`)
      }

      setOutline(data.outline)
    } catch (error) {
      console.error("Outline generation error:", error)

      // Fallback to mock response
      setOutline(MOCK_OUTLINE.replace("The Lost Kingdom", title))

      setError("Using fallback outline due to an error")
      toast({
        title: "Notice",
        description: "Using simulated chapter outline due to an error.",
        variant: "default",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDownload = () => {
    if (!outline) return

    const element = document.createElement("a")
    const file = new Blob([`# Chapter Outline for "${title}"\n\n${outline}`], { type: "text/plain" })
    element.href = URL.createObjectURL(file)
    element.download = `${title.replace(/[^a-z0-9]/gi, "-").toLowerCase()}-outline.txt`
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  return (
    <div className="space-y-4">
      {isPreviewMode && !outline && (
        <Alert variant="default" className="bg-primary/10 border-primary/20">
          <Sparkles className="h-4 w-4" />
          <AlertTitle>Preview Mode</AlertTitle>
          <AlertDescription>
            Using simulated chapter outlines in preview mode. Connect an OpenAI API key in production for real
            AI-generated outlines.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="book-title">Book Title</Label>
          <Input
            id="book-title"
            placeholder="Enter your book title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            disabled={isLoading}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="book-genre">Genre</Label>
          <Select value={genre} onValueChange={setGenre} disabled={isLoading}>
            <SelectTrigger id="book-genre">
              <SelectValue placeholder="Select a genre" />
            </SelectTrigger>
            <SelectContent>
              {GENRES.map((g) => (
                <SelectItem key={g} value={g}>
                  {g}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex justify-end">
        <Button onClick={handleGenerate} disabled={!title.trim() || !genre || isLoading}>
          {isLoading ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              Generating...
            </>
          ) : (
            "Generate Outline"
          )}
        </Button>
      </div>

      {error && (
        <Alert variant="default" className="bg-primary/10 border-primary/20">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Notice</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {outline && (
        <div className="mt-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold">Chapter Outline</h3>
            <Button onClick={handleDownload} variant="outline" size="sm">
              <Download className="mr-2 h-4 w-4" />
              Download
            </Button>
          </div>
          <div className="prose max-w-none whitespace-pre-wrap">{outline}</div>
        </div>
      )}
    </div>
  )
}
