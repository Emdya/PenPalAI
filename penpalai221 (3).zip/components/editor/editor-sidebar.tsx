"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronRight, Plus, Trash2, Edit2, GripVertical } from "lucide-react"
import { ContextMenu, ContextMenuContent, ContextMenuItem, ContextMenuTrigger } from "@/components/ui/context-menu"

export function EditorSidebar() {
  const [chapters, setChapters] = useState([
    {
      id: 1,
      title: "Chapter 1: The Beginning",
      expanded: true,
      scenes: [
        { id: 1, title: "The Discovery" },
        { id: 2, title: "Meeting the Mentor" },
      ],
    },
    {
      id: 2,
      title: "Chapter 2: The Journey",
      expanded: false,
      scenes: [
        { id: 3, title: "Leaving Home" },
        { id: 4, title: "First Challenge" },
      ],
    },
    {
      id: 3,
      title: "Chapter 3: The Conflict",
      expanded: false,
      scenes: [
        { id: 5, title: "Confrontation" },
        { id: 6, title: "Setback" },
      ],
    },
  ])

  const toggleChapter = (id: number) => {
    setChapters(chapters.map((chapter) => (chapter.id === id ? { ...chapter, expanded: !chapter.expanded } : chapter)))
  }

  return (
    <div className="w-64 border-r bg-muted/40 overflow-y-auto">
      <div className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-medium">Chapters</h3>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <Plus className="h-4 w-4" />
            <span className="sr-only">Add chapter</span>
          </Button>
        </div>
        <div className="space-y-1">
          {chapters.map((chapter) => (
            <div key={chapter.id} className="space-y-1">
              <ContextMenu>
                <ContextMenuTrigger>
                  <div
                    className="flex items-center gap-1 rounded-md px-2 py-1.5 hover:bg-muted cursor-pointer"
                    onClick={() => toggleChapter(chapter.id)}
                  >
                    <Button variant="ghost" size="icon" className="h-5 w-5">
                      {chapter.expanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                    </Button>
                    <span className="text-sm">{chapter.title}</span>
                  </div>
                </ContextMenuTrigger>
                <ContextMenuContent>
                  <ContextMenuItem>
                    <Edit2 className="mr-2 h-4 w-4" />
                    Rename
                  </ContextMenuItem>
                  <ContextMenuItem>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Scene
                  </ContextMenuItem>
                  <ContextMenuItem className="text-destructive">
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete
                  </ContextMenuItem>
                </ContextMenuContent>
              </ContextMenu>
              {chapter.expanded && (
                <div className="ml-6 space-y-1">
                  {chapter.scenes.map((scene) => (
                    <ContextMenu key={scene.id}>
                      <ContextMenuTrigger>
                        <div className="flex items-center gap-1 rounded-md px-2 py-1.5 hover:bg-muted cursor-pointer">
                          <GripVertical className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{scene.title}</span>
                        </div>
                      </ContextMenuTrigger>
                      <ContextMenuContent>
                        <ContextMenuItem>
                          <Edit2 className="mr-2 h-4 w-4" />
                          Rename
                        </ContextMenuItem>
                        <ContextMenuItem className="text-destructive">
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </ContextMenuItem>
                      </ContextMenuContent>
                    </ContextMenu>
                  ))}
                  <Button variant="ghost" size="sm" className="w-full justify-start text-xs text-muted-foreground">
                    <Plus className="mr-2 h-3 w-3" />
                    Add Scene
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
        <Button variant="outline" size="sm" className="w-full">
          <Plus className="mr-2 h-4 w-4" />
          Add Chapter
        </Button>
      </div>
    </div>
  )
}
