"use client"

import { useState, useEffect } from "react"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { RefreshCw, AlertCircle, Sparkles } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"

// Mock analysis response for preview environment
const MOCK_TONE_ANALYSIS = `# Tone Analysis

## Primary Emotional Tone
The text has a **mysterious and intriguing** tone. There's an element of wonder and discovery, with undertones of slight apprehension or caution.

## Level of Formality
The writing style is **somewhat casual** with a literary quality. It uses first-person narrative and natural dialogue that feels conversational while maintaining a polished storytelling approach.

## Tone Consistency
The tone is generally consistent throughout the passage, effectively maintaining the sense of mystery and discovery from beginning to end.

## Notable Elements
- Strong use of sensory details ("cold winter morning", "warm sensation")
- Effective balance between description and internal monologue
- Good establishment of intrigue through the artifact's mysterious properties
- Subtle foreshadowing creates tension ("feeling that she was being watched")

## Suggestions
To enhance the tone further, consider:
1. Adding more specific emotional reactions from Sarah to deepen the reader's connection
2. Expanding slightly on the whispers she hears to increase the mystical quality
3. Maintaining this tone as the story progresses to keep readers engaged in the mystery`

export function ToneAnalyzer({ content = "" }) {
  const [text, setText] = useState(content)
  const [analysis, setAnalysis] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isPreviewMode, setIsPreviewMode] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    // Check if we're in a preview environment
    const isPreview =
      window.location.hostname.includes("vercel.app") ||
      window.location.hostname === "localhost" ||
      window.location.hostname === "127.0.0.1"
    setIsPreviewMode(isPreview)

    if (isPreview) {
      console.log("Running in preview mode - using mock AI responses")
    }
  }, [])

  const handleAnalyze = async () => {
    if (!text.trim() || isLoading) return

    setIsLoading(true)
    setError(null)

    try {
      // For preview environment, use mock data directly
      if (isPreviewMode) {
        // Simulate API delay
        await new Promise((resolve) => setTimeout(resolve, 1000))
        setAnalysis(MOCK_TONE_ANALYSIS)
        setIsLoading(false)
        return
      }

      // Real API call
      const response = await fetch("/api/ai/tone", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ content: text }),
      })

      if (!response.ok) {
        // Handle HTTP error status
        let errorMessage = `Failed to analyze tone: ${response.statusText}`
        try {
          const errorData = await response.text()
          // Try to parse as JSON, but don't fail if it's not JSON
          try {
            const jsonError = JSON.parse(errorData)
            errorMessage = jsonError.error || errorMessage
          } catch {
            // If it's not JSON, use the text as is if it exists
            if (errorData) errorMessage = errorData
          }
        } catch (e) {
          // If we can't read the response, just use the status text
          console.error("Error reading error response:", e)
        }
        throw new Error(errorMessage)
      }

      // Try to parse the response as JSON
      let data
      try {
        const textData = await response.text()
        data = JSON.parse(textData)
      } catch (e) {
        console.error("Error parsing response:", e)
        throw new Error("Invalid response format from server")
      }

      if (!data || !data.analysis) {
        throw new Error("Invalid response format from server")
      }

      setAnalysis(data.analysis)
    } catch (error) {
      console.error("Tone analysis error:", error)

      // Fallback to mock response
      setAnalysis(MOCK_TONE_ANALYSIS)

      setError("Using fallback analysis due to an error")
      toast({
        title: "Notice",
        description: "Using simulated tone analysis due to an error.",
        variant: "default",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      {isPreviewMode && !analysis && (
        <Alert variant="default" className="bg-primary/10 border-primary/20">
          <Sparkles className="h-4 w-4" />
          <AlertTitle>Preview Mode</AlertTitle>
          <AlertDescription>
            Using simulated tone analysis in preview mode. Connect an OpenAI API key in production for real AI analysis.
          </AlertDescription>
        </Alert>
      )}

      <div className="space-y-2">
        <label htmlFor="text-to-analyze" className="block text-sm font-medium">
          Enter text to analyze
        </label>
        <Textarea
          id="text-to-analyze"
          placeholder="Paste your text here (minimum 100 words for best results)..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="min-h-[200px]"
          disabled={isLoading}
        />
      </div>

      <div className="flex justify-end">
        <Button onClick={handleAnalyze} disabled={!text.trim() || isLoading}>
          {isLoading ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              Analyzing...
            </>
          ) : (
            "Analyze Tone"
          )}
        </Button>
      </div>

      {error && (
        <Alert variant="default" className="bg-primary/10 border-primary/20">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Notice</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {analysis && (
        <div className="mt-4">
          <div className="prose max-w-none">
            <div className="whitespace-pre-wrap">{analysis}</div>
          </div>
        </div>
      )}
    </div>
  )
}
