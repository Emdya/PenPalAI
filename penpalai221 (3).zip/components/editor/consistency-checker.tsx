"use client"

import { useState, useEffect } from "react"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { RefreshCw, AlertCircle, Sparkles } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"

// Mock consistency analysis for preview environment
const MOCK_CONSISTENCY_ANALYSIS = `# Consistency Analysis

## Overall Assessment
The text is generally consistent for the excerpt provided. There are no major inconsistencies in character descriptions, plot elements, or setting details.

## Character Consistency
**Sarah**: The character is consistently portrayed as curious and drawn to the mysterious artifact. Her reactions remain consistent throughout the passage.

## Setting Consistency
The setting transitions from the oak tree where Sarah finds the artifact to her grandmother's house. The descriptions maintain consistency with the "old oak tree" and "grandmother's house" references.

## Plot Elements
The discovery of the artifact and Sarah's reaction to it are consistently described throughout the passage. The mysterious energy and whispers are mentioned early and reinforced later.

## Strengths
- Strong establishment of the artifact's mysterious properties
- Consistent characterization of Sarah as curious but cautious
- Clear sense of setting and movement between locations

## Recommendations
As you continue writing, maintain consistency by:
1. Keeping a record of the artifact's described properties
2. Tracking Sarah's knowledge about the artifact and her family history
3. Maintaining the established tone of mystery and subtle tension`

export function ConsistencyChecker({ content = "" }) {
  const [text, setText] = useState(content)
  const [analysis, setAnalysis] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isPreviewMode, setIsPreviewMode] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    // Check if we're in a preview environment
    const isPreview =
      window.location.hostname.includes("vercel.app") ||
      window.location.hostname === "localhost" ||
      window.location.hostname === "127.0.0.1"
    setIsPreviewMode(isPreview)

    if (isPreview) {
      console.log("Running in preview mode - using mock AI responses")
    }
  }, [])

  const handleCheck = async () => {
    if (!text.trim() || isLoading) return

    setIsLoading(true)
    setError(null)

    try {
      // For preview environment, use mock data directly without API call
      if (isPreviewMode) {
        // Simulate API delay
        await new Promise((resolve) => setTimeout(resolve, 1000))
        setAnalysis(MOCK_CONSISTENCY_ANALYSIS)
        return
      }

      // Real API call
      const response = await fetch("/api/ai/consistency", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ content: text }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || `Failed to check consistency: ${response.statusText}`)
      }

      const data = await response.json()
      setAnalysis(data.analysis)
    } catch (error) {
      console.error("Consistency check error:", error)

      // Fallback to mock response
      setAnalysis(MOCK_CONSISTENCY_ANALYSIS)

      setError("Using fallback analysis due to an error")
      toast({
        title: "Notice",
        description: "Using simulated consistency analysis due to an error.",
        variant: "default",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      {isPreviewMode && !analysis && (
        <Alert variant="default" className="bg-primary/10 border-primary/20">
          <Sparkles className="h-4 w-4" />
          <AlertTitle>Preview Mode</AlertTitle>
          <AlertDescription>
            Using simulated consistency analysis in preview mode. Connect an OpenAI API key in production for real AI
            analysis.
          </AlertDescription>
        </Alert>
      )}

      <div className="space-y-2">
        <label htmlFor="text-to-check" className="block text-sm font-medium">
          Enter text to check for inconsistencies
        </label>
        <Textarea
          id="text-to-check"
          placeholder="Paste your text here (minimum 200 words for best results)..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="min-h-[200px]"
          disabled={isLoading}
        />
      </div>

      <div className="flex justify-end">
        <Button onClick={handleCheck} disabled={!text.trim() || isLoading}>
          {isLoading ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              Checking...
            </>
          ) : (
            "Check Consistency"
          )}
        </Button>
      </div>

      {error && (
        <Alert variant="default" className="bg-primary/10 border-primary/20">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Notice</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {analysis && (
        <div className="mt-4">
          <div className="prose max-w-none">
            <div className="whitespace-pre-wrap">{analysis}</div>
          </div>
        </div>
      )}
    </div>
  )
}
