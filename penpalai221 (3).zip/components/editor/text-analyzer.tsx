"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { CheckCircle, AlertTriangle, Lightbulb, RefreshCw, Sparkles, ArrowRight } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"

interface TextAnalyzerProps {
  content: string
  highlightedText: string
  analysis: {
    strengths: string[]
    weaknesses: string[]
    suggestions: string[]
  } | null
  isAnalyzing: boolean
  analysisType: "full" | "highlighted" | null
  onAnalyze: (type: "full" | "highlighted") => void
  onApplySuggestion?: (suggestion: string) => void
}

export function TextAnalyzer({
  content,
  highlightedText,
  analysis,
  isAnalyzing,
  analysisType,
  onAnalyze,
  onApplySuggestion,
}: TextAnalyzerProps) {
  const [expandedSuggestion, setExpandedSuggestion] = useState<string | null>(null)
  const [generatedText, setGeneratedText] = useState<{ [key: string]: string }>({})
  const [isGenerating, setIsGenerating] = useState<{ [key: string]: boolean }>({})

  const generateImprovedText = async (originalText: string, suggestionIndex: number) => {
    const suggestionKey = `suggestion-${suggestionIndex}`

    if (isGenerating[suggestionKey]) return

    setIsGenerating((prev) => ({ ...prev, [suggestionKey]: true }))

    try {
      const response = await fetch("/api/ai/improve-text", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          originalText: highlightedText || originalText,
          suggestion: analysis?.suggestions[suggestionIndex] || "",
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate improved text")
      }

      const data = await response.json()
      setGeneratedText((prev) => ({ ...prev, [suggestionKey]: data.improvedText }))
      setExpandedSuggestion(suggestionKey)
    } catch (error) {
      console.error("Error generating improved text:", error)
    } finally {
      setIsGenerating((prev) => ({ ...prev, [suggestionKey]: false }))
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h4 className="text-sm font-medium">ML Analysis</h4>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onAnalyze("highlighted")}
            disabled={isAnalyzing || !highlightedText}
            title={!highlightedText ? "Select text to analyze" : "Analyze selected text"}
          >
            {isAnalyzing && analysisType === "highlighted" ? (
              <>
                <RefreshCw className="mr-2 h-3 w-3 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-3 w-3" />
                Selection
              </>
            )}
          </Button>
          <Button variant="outline" size="sm" onClick={() => onAnalyze("full")} disabled={isAnalyzing}>
            {isAnalyzing && analysisType === "full" ? (
              <>
                <RefreshCw className="mr-2 h-3 w-3 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-3 w-3" />
                Full Text
              </>
            )}
          </Button>
        </div>
      </div>

      {analysis ? (
        <div className="space-y-4">
          <div className="bg-muted/50 p-3 rounded-md">
            <h5 className="text-sm font-medium text-green-600 flex items-center">
              <CheckCircle className="h-4 w-4 mr-2" />
              Strengths
            </h5>
            <ul className="mt-2 space-y-2">
              {analysis.strengths.map((strength, index) => (
                <li key={index} className="text-sm">
                  • {strength}
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-muted/50 p-3 rounded-md">
            <h5 className="text-sm font-medium text-amber-600 flex items-center">
              <AlertTriangle className="h-4 w-4 mr-2" />
              Areas for Improvement
            </h5>
            <ul className="mt-2 space-y-2">
              {analysis.weaknesses.map((weakness, index) => (
                <li key={index} className="text-sm">
                  • {weakness}
                </li>
              ))}
            </ul>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <h5 className="text-sm font-medium text-blue-600 flex items-center mb-2">
              <Lightbulb className="h-4 w-4 mr-2" />
              Suggestions
            </h5>
            {analysis.suggestions.map((suggestion, index) => (
              <AccordionItem key={index} value={`suggestion-${index}`}>
                <AccordionTrigger className="text-sm py-2">
                  {suggestion.length > 60 ? `${suggestion.substring(0, 60)}...` : suggestion}
                </AccordionTrigger>
                <AccordionContent>
                  <p className="text-sm text-muted-foreground mb-2">{suggestion}</p>

                  {highlightedText && (
                    <div className="mt-3 flex justify-between">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => generateImprovedText(highlightedText, index)}
                        disabled={isGenerating[`suggestion-${index}`]}
                      >
                        {isGenerating[`suggestion-${index}`] ? (
                          <>
                            <RefreshCw className="mr-2 h-3 w-3 animate-spin" />
                            Generating...
                          </>
                        ) : (
                          <>
                            <Sparkles className="mr-2 h-3 w-3" />
                            Generate Improved Text
                          </>
                        )}
                      </Button>
                    </div>
                  )}

                  {generatedText[`suggestion-${index}`] && (
                    <div className="mt-3">
                      <div className="bg-muted/50 p-2 rounded-md text-sm">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-xs font-medium">Improved Version:</span>
                          <Badge variant="outline" className="text-xs">
                            <Sparkles className="h-3 w-3 mr-1" />
                            AI Generated
                          </Badge>
                        </div>
                        <p>{generatedText[`suggestion-${index}`]}</p>
                      </div>

                      {onApplySuggestion && (
                        <Button
                          className="mt-2 w-full"
                          size="sm"
                          onClick={() => onApplySuggestion(generatedText[`suggestion-${index}`])}
                        >
                          <ArrowRight className="mr-2 h-3 w-3" />
                          Apply This Text
                        </Button>
                      )}
                    </div>
                  )}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center h-64 text-center text-muted-foreground">
          {isAnalyzing ? (
            <>
              <RefreshCw className="h-8 w-8 animate-spin mb-4" />
              <p>Analyzing your writing with ML algorithms...</p>
              <p className="text-xs mt-2">This may take a moment</p>
            </>
          ) : (
            <>
              <Sparkles className="h-8 w-8 mb-4" />
              <p>Click "Full Text" to analyze your entire document</p>
              <p className="text-xs mt-2">Or highlight specific text and click "Selection" for targeted analysis</p>
            </>
          )}
        </div>
      )}
    </div>
  )
}
