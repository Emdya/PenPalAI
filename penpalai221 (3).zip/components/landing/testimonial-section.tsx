import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"

export function TestimonialSection() {
  const testimonials = [
    {
      quote:
        "PenPal AI helped me finish my first novel in half the time it would have taken me otherwise. The AI suggestions were incredibly helpful.",
      author: "Emily Johnson",
      role: "Fiction Author",
      avatar: "EJ",
    },
    {
      quote:
        "The collaboration features made it easy to work with my editor. We could comment on specific sections and track changes efficiently.",
      author: "Michael Chen",
      role: "Non-fiction Writer",
      avatar: "MC",
    },
    {
      quote:
        "As someone who struggles with consistency in my writing, the tone analyzer and consistency checker were game-changers for me.",
      author: "Sarah Williams",
      role: "Fantasy Writer",
      avatar: "SW",
    },
  ]

  return (
    <section id="testimonials" className="py-16">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">What Our Writers Say</h2>
            <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
              Join thousands of authors who have transformed their writing process with PenPal AI.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3 lg:gap-8 mt-12">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="border bg-background">
              <CardContent className="p-6">
                <div className="flex flex-col gap-4">
                  <p className="text-muted-foreground italic">"{testimonial.quote}"</p>
                  <div className="flex items-center gap-4">
                    <Avatar>
                      <AvatarFallback>{testimonial.avatar}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{testimonial.author}</p>
                      <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
