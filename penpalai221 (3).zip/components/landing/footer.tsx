import Link from "next/link"
import { Feather } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t py-6 md:py-0">
      <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
        <div className="flex items-center gap-2">
          <Feather className="h-5 w-5 text-primary" />
          <p className="text-sm font-medium">PenPal AI</p>
        </div>
        <div className="flex items-center gap-4 md:gap-6">
          <Link href="#" className="text-xs md:text-sm text-muted-foreground hover:text-foreground">
            Terms of Service
          </Link>
          <Link href="#" className="text-xs md:text-sm text-muted-foreground hover:text-foreground">
            Privacy Policy
          </Link>
          <Link href="#" className="text-xs md:text-sm text-muted-foreground hover:text-foreground">
            Contact
          </Link>
        </div>
        <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} PenPal AI. All rights reserved.</p>
      </div>
    </footer>
  )
}
