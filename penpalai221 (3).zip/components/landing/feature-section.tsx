import Link from "next/link"
import {
  BookOpen,
  MessageSquare,
  LineChart,
  Users,
  Palette,
  FileText,
  Sparkles,
  Brain,
  Award,
  ArrowRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"

export function FeatureSection() {
  const features = [
    {
      icon: <MessageSquare className="h-6 w-6" />,
      title: "AI Chatbot Editor",
      description: "Get real-time editing and writing suggestions from our AI assistant.",
    },
    {
      icon: <BookOpen className="h-6 w-6" />,
      title: "Chapter Outlines",
      description: "Generate chapter outlines and scene ideas based on your chosen genre.",
    },
    {
      icon: <LineChart className="h-6 w-6" />,
      title: "Word Count Tracking",
      description: "Track word count per session and visualize your writing progress.",
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: "Real-time Collaboration",
      description: "Share your drafts and collaborate with others in real-time.",
    },
    {
      icon: <Brain className="h-6 w-6" />,
      title: "Tone & Consistency",
      description: "Analyze tone and check for consistency in characters and plot points.",
    },
    {
      icon: <Palette className="h-6 w-6" />,
      title: "AI Cover Generator",
      description: "Generate book covers based on your story with AI image generation.",
    },
    {
      icon: <FileText className="h-6 w-6" />,
      title: "Export Options",
      description: "Export your book in PDF, EPUB, and pre-formatted DOCX formats.",
    },
    {
      icon: <Award className="h-6 w-6" />,
      title: "Publishing Guidance",
      description: "Step-by-step guidance for publishing on major platforms.",
    },
    {
      icon: <Sparkles className="h-6 w-6" />,
      title: "Writing Streaks",
      description: "Track your writing streaks and earn badges for milestones.",
    },
  ]

  return (
    <section id="features" className="py-16 bg-muted/50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              Powerful Features for Writers
            </h2>
            <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
              Everything you need to write, edit, and publish your book in one place.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 mt-12">
          {features.map((feature, index) => (
            <div key={index} className="flex flex-col items-start gap-2 rounded-lg border bg-background p-6 shadow-sm">
              <div className="rounded-full bg-primary/10 p-2 text-primary">{feature.icon}</div>
              <h3 className="text-lg font-semibold">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
        <div className="mt-12 text-center">
          <Link href="/features">
            <Button size="lg" className="gap-2">
              Explore All Features <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
