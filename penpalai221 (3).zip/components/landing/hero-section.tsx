import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Sparkles } from "lucide-react"

export function HeroSection() {
  return (
    <section className="py-20 md:py-28">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                Write Your Book with AI Assistance
              </h1>
              <p className="max-w-[600px] text-gray-500 md:text-xl dark:text-gray-400">
                PenPal AI helps you write, edit, and publish your book with AI-powered tools and guidance.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/signup">
                <Button size="lg" className="gap-1.5">
                  Start Writing <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link href="/features">
                <Button size="lg" variant="outline">
                  Explore Features
                </Button>
              </Link>
            </div>
          </div>
          <div className="flex items-center justify-center">
            <div className="relative w-full h-[400px] overflow-hidden rounded-lg border bg-background shadow-xl">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-background p-8">
                <div className="h-full w-full rounded-md border bg-background/80 backdrop-blur-sm p-4 shadow-sm">
                  <div className="flex items-center gap-2 mb-4">
                    <Sparkles className="h-5 w-5 text-primary" />
                    <h3 className="font-medium">AI Writing Assistant</h3>
                  </div>
                  <div className="space-y-4">
                    <p className="text-sm text-muted-foreground">Chapter 1: The Beginning</p>
                    <div className="h-32 w-full rounded-md border p-2 text-sm">
                      It was a cold winter morning when Sarah first discovered the ancient artifact. The small, metallic
                      object seemed to pulse with an energy that defied explanation. As she held it in her palm, a warm
                      sensation traveled up her arm...
                    </div>
                    <div className="flex items-center gap-2 p-2 rounded-md bg-primary/10 border border-primary/20">
                      <Sparkles className="h-4 w-4 text-primary" />
                      <p className="text-xs">
                        <span className="font-medium">AI Suggestion:</span> Consider adding more sensory details about
                        the artifact to build intrigue.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
