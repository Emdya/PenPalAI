"use client"

import dynamic from "next/dynamic"
import type { ReactNode } from "react"

// Dynamically import 3D components with no SSR
const BookModel = dynamic(() => import("@/components/3d/book-model").then((mod) => mod.BookModel), { ssr: false })
const QuillPenModel = dynamic(() => import("@/components/3d/quill-pen").then((mod) => mod.QuillPenModel), {
  ssr: false,
})
const FloatingTextEffect = dynamic(
  () => import("@/components/3d/floating-text").then((mod) => mod.FloatingTextEffect),
  { ssr: false },
)
const ParticlesBackground = dynamic(
  () => import("@/components/3d/particles-background").then((mod) => mod.ParticlesBackground),
  { ssr: false },
)

export function DynamicBookModel() {
  return <BookModel />
}

export function DynamicQuillPenModel() {
  return <QuillPenModel />
}

export function DynamicFloatingTextEffect() {
  return <FloatingTextEffect />
}

export function DynamicParticlesBackground() {
  return <ParticlesBackground />
}

interface ClientWrapperProps {
  children: ReactNode
}

export function ClientWrapper({ children }: ClientWrapperProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-royalBlue via-royalBlue/80 to-gold/70 text-white">
      {/* Dynamically loaded 3D background */}
      <div className="fixed inset-0 -z-10">
        <DynamicParticlesBackground />
      </div>
      {children}
    </div>
  )
}
