"use client"

import { SessionProvider } from "next-auth/react"
import { MockSessionProvider } from "./mock-session-provider"
import type React from "react"

export function AuthProvider({ children }: { children: React.ReactNode }) {
  // In development, use the mock session provider to avoid API calls
  if (process.env.NODE_ENV === "development") {
    return <MockSessionProvider>{children}</MockSessionProvider>
  }

  // In production, use the real NextAuth session provider
  return (
    <SessionProvider refetchInterval={0} refetchOnWindowFocus={false}>
      {children}
    </SessionProvider>
  )
}
